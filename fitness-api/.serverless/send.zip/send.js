(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 20);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var http = __webpack_require__(4);
var https = __webpack_require__(10);
var path = __webpack_require__(9);

var utils = __webpack_require__(1);
var Error = __webpack_require__(3);
var Buffer = __webpack_require__(5).Buffer;

var hasOwn = {}.hasOwnProperty;

// Provide extension mechanism for Telnyx Resource Sub-Classes
TelnyxResource.extend = utils.protoExtend;
// Expose method-creator & prepared (basic) methods
TelnyxResource.method = __webpack_require__(16);
TelnyxResource.BASIC_METHODS = __webpack_require__(41);

TelnyxResource.MAX_BUFFERED_REQUEST_METRICS = 100;

/**
 * Encapsulates request logic for a Telnyx Resource
 */
function TelnyxResource(telnyx, urlData) {
  this._telnyx = telnyx;
  this._urlData = urlData || {};

  this.basePath = utils.makeURLInterpolator(this.basePath || telnyx.getApiField('basePath'));
  this.resourcePath = this.path;
  this.path = utils.makeURLInterpolator(this.path);

  if (this.includeBasic) {
    this.includeBasic.forEach(function(methodName) {
      this[methodName] = TelnyxResource.BASIC_METHODS[methodName];
    }, this);
  }

  if (this.nestedResources) {
    for (var resource in this.nestedResources) {
      this[utils.pascalToCamelCase(resource)] = new this.nestedResources[resource](telnyx);
    }
  }

  if (this.instanceMethods) {
    Object.assign(this, this.instanceMethods);
  }

  this.initialize.apply(this, arguments);
}

TelnyxResource.prototype = {

  path: '',

  // Methods that don't use the API's default '/v1' path can override it with this setting.
  basePath: null,

  initialize: function() {},

  // Function to override the default data processor. This allows full control
  // over how a TelnyxResource's request data will get converted into an HTTP
  // body. This is useful for non-standard HTTP requests. The function should
  // take method name, data, and headers as arguments.
  requestDataProcessor: null,

  // Function to add a validation checks before sending the request, errors should
  // be thrown, and they will be passed to the callback/promise.
  validateRequest: null,

  createFullPath: function(commandPath, urlData) {
    return path.join(
      this.basePath(urlData),
      this.path(urlData),
      typeof commandPath == 'function' ?
        commandPath(urlData) : commandPath
    ).replace(/\\/g, '/'); // ugly workaround for Windows
  },

  // Creates a relative resource path with symbols left in (unlike
  // createFullPath which takes some data to replace them with). For example it
  // might produce: /invoices/{id}
  createResourcePathWithSymbols: function(pathWithSymbols) {
    return '/' + path.join(
      this.resourcePath,
      pathWithSymbols || ''
    ).replace(/\\/g, '/'); // ugly workaround for Windows
  },

  createUrlData: function() {
    var urlData = {};
    // Merge in baseData
    for (var i in this._urlData) {
      if (hasOwn.call(this._urlData, i)) {
        urlData[i] = this._urlData[i];
      }
    }
    return urlData;
  },

  _timeoutHandler: function(timeout, req, callback) {
    var self = this;
    return function() {
      var timeoutErr = new Error('ETIMEDOUT');
      timeoutErr.code = 'ETIMEDOUT';

      req._isAborted = true;
      req.abort();

      callback.call(
        self,
        new Error.TelnyxConnectionError({
          message: 'Request aborted due to timeout being reached (' + timeout + 'ms)',
          detail: timeoutErr,
        }),
        null
      );
    }
  },

  _responseHandler: function(req, callback) {
    var self = this;
    return function(res) {
      var response = '';

      res.setEncoding('utf8');
      res.on('data', function(chunk) {
        response += chunk;
      });
      res.on('end', function() {
        var headers = res.headers || {};
        // NOTE: Telnyx responds with lowercase header names/keys.

        // For convenience, make Request-Id easily accessible on
        // lastResponse.
        res.requestId = headers['request-id'] || headers['x-request-id'] || '';

        var requestDurationMs = Date.now() - req._requestStart;

        var responseEvent = utils.removeEmpty({
          method: req._requestEvent.method,
          path: req._requestEvent.path,
          status: res.statusCode,
          request_id: res.requestId,
          elapsed: requestDurationMs,
        });

        self._telnyx._emitter.emit('response', responseEvent);

        try {
          response = utils.tryParseJSON(response);

          if (response.errors) {
            var error = {};

            error.errors = response.errors

            error.headers = headers;
            error.statusCode = res.statusCode;
            error.requestId = res.requestId;

            var err = self._buildError(error, res.statusCode);

            return callback.call(self, err, null);
          }
        } catch (e) {
          return callback.call(
            self,
            new Error.TelnyxAPIError({
              message: 'Invalid JSON received from the Telnyx API',
              response: response,
              exception: e,
              requestId: res.requestId,
            }),
            null
          );
        }

        // Expose res object
        Object.defineProperty(response, 'lastResponse', {
          enumerable: false,
          writable: false,
          value: res,
        });
        callback.call(self, null, response);
      });
    };
  },

  _buildError: function(error, statusCode) {
    var err;
    switch (statusCode) {
    case 400:
      err = new Error.TelnyxInvalidRequestError(error);
      break;
    case 401:
      err = new Error.TelnyxAuthenticationError(error);
      break;
    case 403:
      err = new Error.TelnyxPermissionError(error);
      break;
    case 404:
      err = new Error.TelnyxResourceNotFoundError(error);
      break;
    case 405:
      err = new Error.TelnyxMethodNotSupportedError(error);
      break;
    case 408:
      err = new Error.TelnyxTimeoutError(error);
      break;
    case 415:
      err = new Error.TelnyxUnsupportedMediaTypeError(error);
      break;
    case 422:
      err = new Error.TelnyxInvalidParametersError(error);
      break;
    case 429:
      err = new Error.TelnyxRateLimitError(error);
      break;
    case 500:
      err = new Error.TelnyxAPIError(error);
      break;
    case 503:
      err = new Error.TelnyxServiceUnavailableError(error);
      break;
    default:
      err = new Error.TelnyxAPIError(error);
    }

    return err;
  },

  _generateConnectionErrorMessage: function(requestRetries) {
    return 'An error occurred with our connection to Telnyx.' + (requestRetries > 0 ? ' Request was retried ' + requestRetries + ' times.' : '');
  },

  _errorHandler: function(req, requestRetries, callback) {
    var self = this;
    return function(error) {
      if (req._isAborted) {
        // already handled
        return;
      }
      callback.call(
        self,
        new Error.TelnyxConnectionError({
          message: self._generateConnectionErrorMessage(requestRetries),
          responseBody: error,
        }),
        null
      );
    }
  },

  _shouldRetry: function(res, numRetries) {
    // Do not retry if we are out of retries.
    if (numRetries >= this._telnyx.getMaxNetworkRetries()) {
      return false;
    }

    // Retry on connection error.
    if (!res) {
      return true;
    }

    // Retry on conflict and availability errors.
    if (res.statusCode === 409 || res.statusCode === 503) {
      return true;
    }

    // Retry on 5xx's, except POST's as that may not be safe.
    if (res.statusCode >= 500 && res.req._requestEvent.method !== 'POST') {
      return true;
    }

    return false;
  },

  _getSleepTimeInMS: function(numRetries) {
    var initialNetworkRetryDelay = this._telnyx.getInitialNetworkRetryDelay();
    var maxNetworkRetryDelay = this._telnyx.getMaxNetworkRetryDelay();

    // Apply exponential backoff with initialNetworkRetryDelay on the
    // number of numRetries so far as inputs. Do not allow the number to exceed
    // maxNetworkRetryDelay.
    var sleepSeconds = Math.min(
      initialNetworkRetryDelay * Math.pow(numRetries - 1, 2),
      maxNetworkRetryDelay
    );

    // Apply some jitter by randomizing the value in the range of
    // (sleepSeconds / 2) to (sleepSeconds).
    sleepSeconds *= 0.5 * (1 + Math.random());

    // But never sleep less than the base sleep seconds.
    sleepSeconds = Math.max(initialNetworkRetryDelay, sleepSeconds);

    return sleepSeconds * 1000;
  },

  _defaultHeaders: function(auth, requestData) {
    var userAgentString = 'Telnyx/v1 NodeBindings/' + this._telnyx.getConstant('PACKAGE_VERSION');

    if (this._telnyx._appInfo) {
      userAgentString += ' ' + this._telnyx.getAppInfoAsString();
    }

    var headers = {
      // Use specified auth token or use default from this telnyx instance:
      'Authorization': auth ?
        'Bearer ' + auth :
        this._telnyx.getApiField('auth'),
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(requestData),
      'User-Agent': userAgentString,
    };

    return headers;
  },

  _request: function(method, host, path, data, auth, options, callback) {
    var self = this;
    var requestData;

    function makeRequestWithData(error, data) {
      var headers;

      if (error) {
        return callback(error);
      }

      if (method == 'GET') {
        if (data != '' && data != null) {
          path = path + '?' + data;
          requestData = '';
        } else {
          requestData = '';
        }
      } else {
        requestData = data;
      }

      headers = self._defaultHeaders(auth, requestData);
      self._telnyx.getClientUserAgent(function(cua) {
        headers['X-Telnyx-Client-User-Agent'] = cua;

        if (options.headers) {
          Object.assign(headers, options.headers);
        }

        makeRequest(headers);
      });
    }

    if (self.requestDataProcessor) {
      self.requestDataProcessor(method, data, options.headers, makeRequestWithData);
    } else if (method == 'GET') {
      makeRequestWithData(null, data ? utils.stringifyRequestData(data) : '');
    } else if (method == 'DELETE') {
      makeRequestWithData(null, '');
    } else {
      makeRequestWithData(null, data ? JSON.stringify(data) : '');
    }

    function retryRequest(requestFn, headers, requestRetries) {
      requestRetries += 1;

      return setTimeout(
        requestFn,
        self._getSleepTimeInMS(requestRetries),
        headers,
        requestRetries
      );
    }

    function makeRequest(headers, numRetries) {
      var timeout = self._telnyx.getApiField('timeout');
      var isInsecureConnection = self._telnyx.getApiField('protocol') == 'http';
      var agent = isInsecureConnection ? self._telnyx.getApiField('http_agent') : self._telnyx.getApiField('https_agent');

      var req = (
        isInsecureConnection ? http : https
      ).request({
        host: host || self._telnyx.getApiField('host'),
        port: self._telnyx.getApiField('port'),
        path: path,
        method: method,
        agent: agent,
        headers: headers,
        ciphers: 'DEFAULT:!aNULL:!eNULL:!LOW:!EXPORT:!SSLv2:!MD5',
      });

      var requestEvent = utils.removeEmpty({
        method: method,
        path: path,
      });

      var requestRetries = numRetries || 0;

      req._requestEvent = requestEvent;

      req._requestStart = Date.now();

      self._telnyx._emitter.emit('request', requestEvent);

      req.setTimeout(timeout, self._timeoutHandler(timeout, req, callback));

      req.on('response', function(res) {
        if (self._shouldRetry(res, requestRetries)) {
          return retryRequest(makeRequest, headers, requestRetries);
        } else {
          return self._responseHandler(req, callback)(res);
        }
      });

      req.on('error', function(error) {
        if (self._shouldRetry(null, requestRetries)) {
          return retryRequest(makeRequest, headers, requestRetries);
        } else {
          return self._errorHandler(req, requestRetries, callback)(error);
        }
      });

      req.on('socket', function(socket) {
        if (socket.connecting) {
          socket.on((isInsecureConnection ? 'connect' : 'secureConnect'), function() {
            // Send payload; we're safe:
            req.write(requestData);
            req.end();
          });
        } else {
          // we're already connected
          req.write(requestData);
          req.end();
        }
      });
    }
  },
};

module.exports = TelnyxResource;


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var Buffer = __webpack_require__(5).Buffer;
var EventEmitter = __webpack_require__(11).EventEmitter;
var qs = __webpack_require__(36);
var crypto = __webpack_require__(14);

var hasOwn = {}.hasOwnProperty;
var isPlainObject = __webpack_require__(15);

var OPTIONS_KEYS = ['api_key'];

var utils = module.exports = {

  isAuthKey: function(key) {
    return typeof key == 'string' && /^KEY[A-Z0-9]{32}_[a-zA-Z0-9]{22}$/.test(key);
  },

  isOptionsHash: function(o) {
    return isPlainObject(o) && OPTIONS_KEYS.some(function(key) {
      return hasOwn.call(o, key);
    });
  },

  /**
   * Stringifies an Object, accommodating nested objects
   * (forming the conventional key 'parent[child]=value')
   */
  stringifyRequestData: function(data) {
    return qs.stringify(data, {arrayFormat: 'brackets'})
      // Don't use strict form encoding by changing the square bracket control
      // characters back to their literals. This is fine by the server, and
      // makes these parameter strings easier to read.
      .replace(/%5B/g, '[').replace(/%5D/g, ']');
  },

  /**
   * Outputs a new function with interpolated object property values.
   * Use like so:
   *   var fn = makeURLInterpolator('some/url/{param1}/{param2}');
   *   fn({ param1: 123, param2: 456 }); // => 'some/url/123/456'
   */
  makeURLInterpolator: (function() {
    var rc = {
      '\n': '\\n', '\"': '\\\"',
      '\u2028': '\\u2028', '\u2029': '\\u2029',
    };
    return function makeURLInterpolator(str) {
      var cleanString = str.replace(/["\n\r\u2028\u2029]/g, function($0) {
        return rc[$0];
      });
      return function(outputs) {
        return cleanString.replace(/\{([\s\S]+?)\}/g, function($0, $1) {
          return encodeURIComponent(outputs[$1] || '');
        });
      };
    };
  }()),

  /**
   * Return the data argument from a list of arguments
   */
  getDataFromArgs: function(args) {
    if (args.length < 1 || !isPlainObject(args[0])) {
      return {};
    }

    if (!utils.isOptionsHash(args[0])) {
      return args.shift();
    }

    var argKeys = Object.keys(args[0]);

    var optionKeysInArgs = argKeys.filter(function(key) {
      return OPTIONS_KEYS.indexOf(key) > -1;
    });

    // In some cases options may be the provided as the first argument.
    // Here we're detecting a case where there are two distinct arguments
    // (the first being args and the second options) and with known
    // option keys in the first so that we can warn the user about it.
    if (optionKeysInArgs.length > 0 && optionKeysInArgs.length !== argKeys.length) {
      emitWarning(
        'Options found in arguments (' + optionKeysInArgs.join(', ') + '). Did you mean to pass an options ' +
        'object? See https://github.com/telnyx/telnyx-node/wiki/Passing-Options.'
      );
    }

    return {};
  },

  /**
   * Return the options hash from a list of arguments
   */
  getOptionsFromArgs: function(args) {
    var opts = {
      auth: null,
      headers: {},
    };
    if (args.length > 0) {
      var arg = args[args.length - 1];
      if (utils.isAuthKey(arg)) {
        opts.auth = args.pop();
      } else if (utils.isOptionsHash(arg)) {
        var params = args.pop();

        var extraKeys = Object.keys(params).filter(function(key) {
          return OPTIONS_KEYS.indexOf(key) == -1;
        });

        if (extraKeys.length) {
          emitWarning('Invalid options found (' + extraKeys.join(', ') + '); ignoring.');
        }

        if (params.api_key) {
          opts.auth = params.api_key;
        }
      }
    }
    return opts;
  },

  /**
   * Provide simple "Class" extension mechanism
   */
  protoExtend: function(sub) {
    var Super = this;
    var Constructor = hasOwn.call(sub, 'constructor') ? sub.constructor : function() {
      Super.apply(this, arguments);
    };

    // This initialization logic is somewhat sensitive to be compatible with
    // divergent JS implementations like the one found in Qt. See here for more
    // context:
    //
    // https://github.com/telnyx/telnyx-node/pull/334
    Object.assign(Constructor, Super);
    Constructor.prototype = Object.create(Super.prototype);
    Object.assign(Constructor.prototype, sub);

    return Constructor;
  },

  /**
  * Secure compare, from https://github.com/freewil/scmp
  */
  secureCompare: function(a, b) {
    a = Buffer.from(a);
    b = Buffer.from(b);

    // return early here if buffer lengths are not equal since timingSafeEqual
    // will throw if buffer lengths are not equal
    if (a.length !== b.length) {
      return false;
    }

    // use crypto.timingSafeEqual if available (since Node.js v6.6.0),
    // otherwise use our own scmp-internal function.
    if (crypto.timingSafeEqual) {
      return crypto.timingSafeEqual(a, b);
    }

    var len = a.length;
    var result = 0;

    for (var i = 0; i < len; ++i) {
      result |= a[i] ^ b[i];
    }
    return result === 0;
  },

  /**
  * Remove empty values from an object
  */
  removeEmpty: function(obj) {
    if (typeof obj !== 'object') {
      throw new Error('Argument must be an object');
    }

    Object.keys(obj).forEach(function(key) {
      if (obj[key] === null || obj[key] === undefined) {
        delete obj[key];
      }
    });

    return obj;
  },

  /**
  * Determine if file data is a derivative of EventEmitter class.
  * https://nodejs.org/api/events.html#events_events
  */
  checkForStream: function (obj) {
    if (obj.file && obj.file.data) {
      return obj.file.data instanceof EventEmitter;
    }
    return false;
  },

  callbackifyPromiseWithTimeout: function(promise, callback) {
    if (callback) {
      // Ensure callback is called outside of promise stack.
      return promise.then(function(res) {
        setTimeout(function() { callback(null, res) }, 0);
      }, function(err) {
        setTimeout(function() { callback(err, null); }, 0);
      });
    }

    return promise;
  },

  /**
   * Allow for special capitalization cases (such as OAuth)
   */
  pascalToCamelCase: function(name) {
    return name[0].toLowerCase() + name.substring(1);
  },

  /**
   * snake_case to camelCase
   */
  snakeToCamelCase: function(name) {
    const words = name.split('_');

    return words.reduce(function(acc, nextWord) {
      return acc + nextWord.charAt(0).toUpperCase() + nextWord.slice(1);
    });
  },

  /**
   * remove final `s` from names
   */
  toSingular: function(name) {
    if (name.endsWith('s')) {
      return name.slice(0, -1);
    }
  },

  /**
   * Add TelnyxResource to API response data
   *
   * @param [response] Resource response object
   * @param [telnyx] Telnyx SDK
   * @param [resourceName] Resource name in camelCase
   * @param [methods] resource methods to include
   */
  addResourceToResponseData: function (
    response,
    telnyx,
    resourceName,
    methods
  ) {
    if (response && response.data && typeof response.data === 'object') {

      /*
       * make nested methods. e.g.: call.bridge();
       * nested methods should be used from basic methods response. See specs for an example
       */
      var resourceFulData = telnyx[resourceName];

      Object.assign(resourceFulData, response.data, methods);

      response.data = resourceFulData;
    }

    return response;
  },

  /**
   * Create multiple nested methods, in camelCase and snakeCase, using spec and method names
   *
   * @param [telnyxMethod] TelnyxResource Method  telnyxMethod creator
   * @param [names=[]] Array of method names
   * @param [spec] telnyxMethod spec creator by method name
   */
  createNestedMethods: function(telnyxMethod, names, spec) {
    var methods = {};

    names.forEach(function(name) {
      methods[name] = methods[utils.snakeToCamelCase(name)] = telnyxMethod(spec(name));
    })

    return methods;
  },

  emitWarning: emitWarning,

  tryParseJSON: tryParseJSON,
};

function emitWarning(warning) {
  if (typeof process.emitWarning !== 'function') {
    return console.warn('Telnyx: ' + warning); /* eslint-disable-line no-console */
  }

  return process.emitWarning(warning, 'Telnyx');
}

/**
 * tryParseJSON used to only parse JSON response,
 * if it is not a JSON response sends the value inside a data object to keep the standard.
 *
 * @param [jsonString]  Response object
 */
function tryParseJSON (jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    const defaultValue = {
      data: jsonString
    };

    return defaultValue;
  }
}


/***/ }),
/* 2 */
/***/ (function(module, exports) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

/**
 * This is a helper function for getting values from parameter/options
 * objects.
 *
 * @param args The object we are extracting values from
 * @param name The name of the property we are getting.
 * @param defaultValue An optional value to return if the property is missing
 * from the object. If this is not specified and the property is missing, an
 * error will be thrown.
 */
function getArg(aArgs, aName, aDefaultValue) {
  if (aName in aArgs) {
    return aArgs[aName];
  } else if (arguments.length === 3) {
    return aDefaultValue;
  } else {
    throw new Error('"' + aName + '" is a required argument.');
  }
}
exports.getArg = getArg;

var urlRegexp = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.]*)(?::(\d+))?(\S*)$/;
var dataUrlRegexp = /^data:.+\,.+$/;

function urlParse(aUrl) {
  var match = aUrl.match(urlRegexp);
  if (!match) {
    return null;
  }
  return {
    scheme: match[1],
    auth: match[2],
    host: match[3],
    port: match[4],
    path: match[5]
  };
}
exports.urlParse = urlParse;

function urlGenerate(aParsedUrl) {
  var url = '';
  if (aParsedUrl.scheme) {
    url += aParsedUrl.scheme + ':';
  }
  url += '//';
  if (aParsedUrl.auth) {
    url += aParsedUrl.auth + '@';
  }
  if (aParsedUrl.host) {
    url += aParsedUrl.host;
  }
  if (aParsedUrl.port) {
    url += ":" + aParsedUrl.port
  }
  if (aParsedUrl.path) {
    url += aParsedUrl.path;
  }
  return url;
}
exports.urlGenerate = urlGenerate;

/**
 * Normalizes a path, or the path portion of a URL:
 *
 * - Replaces consecutive slashes with one slash.
 * - Removes unnecessary '.' parts.
 * - Removes unnecessary '<dir>/..' parts.
 *
 * Based on code in the Node.js 'path' core module.
 *
 * @param aPath The path or url to normalize.
 */
function normalize(aPath) {
  var path = aPath;
  var url = urlParse(aPath);
  if (url) {
    if (!url.path) {
      return aPath;
    }
    path = url.path;
  }
  var isAbsolute = exports.isAbsolute(path);

  var parts = path.split(/\/+/);
  for (var part, up = 0, i = parts.length - 1; i >= 0; i--) {
    part = parts[i];
    if (part === '.') {
      parts.splice(i, 1);
    } else if (part === '..') {
      up++;
    } else if (up > 0) {
      if (part === '') {
        // The first part is blank if the path is absolute. Trying to go
        // above the root is a no-op. Therefore we can remove all '..' parts
        // directly after the root.
        parts.splice(i + 1, up);
        up = 0;
      } else {
        parts.splice(i, 2);
        up--;
      }
    }
  }
  path = parts.join('/');

  if (path === '') {
    path = isAbsolute ? '/' : '.';
  }

  if (url) {
    url.path = path;
    return urlGenerate(url);
  }
  return path;
}
exports.normalize = normalize;

/**
 * Joins two paths/URLs.
 *
 * @param aRoot The root path or URL.
 * @param aPath The path or URL to be joined with the root.
 *
 * - If aPath is a URL or a data URI, aPath is returned, unless aPath is a
 *   scheme-relative URL: Then the scheme of aRoot, if any, is prepended
 *   first.
 * - Otherwise aPath is a path. If aRoot is a URL, then its path portion
 *   is updated with the result and aRoot is returned. Otherwise the result
 *   is returned.
 *   - If aPath is absolute, the result is aPath.
 *   - Otherwise the two paths are joined with a slash.
 * - Joining for example 'http://' and 'www.example.com' is also supported.
 */
function join(aRoot, aPath) {
  if (aRoot === "") {
    aRoot = ".";
  }
  if (aPath === "") {
    aPath = ".";
  }
  var aPathUrl = urlParse(aPath);
  var aRootUrl = urlParse(aRoot);
  if (aRootUrl) {
    aRoot = aRootUrl.path || '/';
  }

  // `join(foo, '//www.example.org')`
  if (aPathUrl && !aPathUrl.scheme) {
    if (aRootUrl) {
      aPathUrl.scheme = aRootUrl.scheme;
    }
    return urlGenerate(aPathUrl);
  }

  if (aPathUrl || aPath.match(dataUrlRegexp)) {
    return aPath;
  }

  // `join('http://', 'www.example.com')`
  if (aRootUrl && !aRootUrl.host && !aRootUrl.path) {
    aRootUrl.host = aPath;
    return urlGenerate(aRootUrl);
  }

  var joined = aPath.charAt(0) === '/'
    ? aPath
    : normalize(aRoot.replace(/\/+$/, '') + '/' + aPath);

  if (aRootUrl) {
    aRootUrl.path = joined;
    return urlGenerate(aRootUrl);
  }
  return joined;
}
exports.join = join;

exports.isAbsolute = function (aPath) {
  return aPath.charAt(0) === '/' || !!aPath.match(urlRegexp);
};

/**
 * Make a path relative to a URL or another path.
 *
 * @param aRoot The root path or URL.
 * @param aPath The path or URL to be made relative to aRoot.
 */
function relative(aRoot, aPath) {
  if (aRoot === "") {
    aRoot = ".";
  }

  aRoot = aRoot.replace(/\/$/, '');

  // It is possible for the path to be above the root. In this case, simply
  // checking whether the root is a prefix of the path won't work. Instead, we
  // need to remove components from the root one by one, until either we find
  // a prefix that fits, or we run out of components to remove.
  var level = 0;
  while (aPath.indexOf(aRoot + '/') !== 0) {
    var index = aRoot.lastIndexOf("/");
    if (index < 0) {
      return aPath;
    }

    // If the only part of the root that is left is the scheme (i.e. http://,
    // file:///, etc.), one or more slashes (/), or simply nothing at all, we
    // have exhausted all components, so the path is not relative to the root.
    aRoot = aRoot.slice(0, index);
    if (aRoot.match(/^([^\/]+:\/)?\/*$/)) {
      return aPath;
    }

    ++level;
  }

  // Make sure we add a "../" for each component we removed from the root.
  return Array(level + 1).join("../") + aPath.substr(aRoot.length + 1);
}
exports.relative = relative;

var supportsNullProto = (function () {
  var obj = Object.create(null);
  return !('__proto__' in obj);
}());

function identity (s) {
  return s;
}

/**
 * Because behavior goes wacky when you set `__proto__` on objects, we
 * have to prefix all the strings in our set with an arbitrary character.
 *
 * See https://github.com/mozilla/source-map/pull/31 and
 * https://github.com/mozilla/source-map/issues/30
 *
 * @param String aStr
 */
function toSetString(aStr) {
  if (isProtoString(aStr)) {
    return '$' + aStr;
  }

  return aStr;
}
exports.toSetString = supportsNullProto ? identity : toSetString;

function fromSetString(aStr) {
  if (isProtoString(aStr)) {
    return aStr.slice(1);
  }

  return aStr;
}
exports.fromSetString = supportsNullProto ? identity : fromSetString;

function isProtoString(s) {
  if (!s) {
    return false;
  }

  var length = s.length;

  if (length < 9 /* "__proto__".length */) {
    return false;
  }

  if (s.charCodeAt(length - 1) !== 95  /* '_' */ ||
      s.charCodeAt(length - 2) !== 95  /* '_' */ ||
      s.charCodeAt(length - 3) !== 111 /* 'o' */ ||
      s.charCodeAt(length - 4) !== 116 /* 't' */ ||
      s.charCodeAt(length - 5) !== 111 /* 'o' */ ||
      s.charCodeAt(length - 6) !== 114 /* 'r' */ ||
      s.charCodeAt(length - 7) !== 112 /* 'p' */ ||
      s.charCodeAt(length - 8) !== 95  /* '_' */ ||
      s.charCodeAt(length - 9) !== 95  /* '_' */) {
    return false;
  }

  for (var i = length - 10; i >= 0; i--) {
    if (s.charCodeAt(i) !== 36 /* '$' */) {
      return false;
    }
  }

  return true;
}

/**
 * Comparator between two mappings where the original positions are compared.
 *
 * Optionally pass in `true` as `onlyCompareGenerated` to consider two
 * mappings with the same original source/line/column, but different generated
 * line and column the same. Useful when searching for a mapping with a
 * stubbed out mapping.
 */
function compareByOriginalPositions(mappingA, mappingB, onlyCompareOriginal) {
  var cmp = mappingA.source - mappingB.source;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.originalLine - mappingB.originalLine;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.originalColumn - mappingB.originalColumn;
  if (cmp !== 0 || onlyCompareOriginal) {
    return cmp;
  }

  cmp = mappingA.generatedColumn - mappingB.generatedColumn;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.generatedLine - mappingB.generatedLine;
  if (cmp !== 0) {
    return cmp;
  }

  return mappingA.name - mappingB.name;
}
exports.compareByOriginalPositions = compareByOriginalPositions;

/**
 * Comparator between two mappings with deflated source and name indices where
 * the generated positions are compared.
 *
 * Optionally pass in `true` as `onlyCompareGenerated` to consider two
 * mappings with the same generated line and column, but different
 * source/name/original line and column the same. Useful when searching for a
 * mapping with a stubbed out mapping.
 */
function compareByGeneratedPositionsDeflated(mappingA, mappingB, onlyCompareGenerated) {
  var cmp = mappingA.generatedLine - mappingB.generatedLine;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.generatedColumn - mappingB.generatedColumn;
  if (cmp !== 0 || onlyCompareGenerated) {
    return cmp;
  }

  cmp = mappingA.source - mappingB.source;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.originalLine - mappingB.originalLine;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.originalColumn - mappingB.originalColumn;
  if (cmp !== 0) {
    return cmp;
  }

  return mappingA.name - mappingB.name;
}
exports.compareByGeneratedPositionsDeflated = compareByGeneratedPositionsDeflated;

function strcmp(aStr1, aStr2) {
  if (aStr1 === aStr2) {
    return 0;
  }

  if (aStr1 > aStr2) {
    return 1;
  }

  return -1;
}

/**
 * Comparator between two mappings with inflated source and name strings where
 * the generated positions are compared.
 */
function compareByGeneratedPositionsInflated(mappingA, mappingB) {
  var cmp = mappingA.generatedLine - mappingB.generatedLine;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.generatedColumn - mappingB.generatedColumn;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = strcmp(mappingA.source, mappingB.source);
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.originalLine - mappingB.originalLine;
  if (cmp !== 0) {
    return cmp;
  }

  cmp = mappingA.originalColumn - mappingB.originalColumn;
  if (cmp !== 0) {
    return cmp;
  }

  return strcmp(mappingA.name, mappingB.name);
}
exports.compareByGeneratedPositionsInflated = compareByGeneratedPositionsInflated;


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(1);

module.exports = _Error;

/**
 * Generic Error klass to wrap any errors returned by telnyx-node
 */
function _Error(raw) {
  this.populate.apply(this, arguments);
  this.stack = (new Error(this.message)).stack;
}

function buildMessage(raw) {
  return `${statusString(raw)}${idString(raw)}${message(raw.errors)}${otherErrorsMessage(raw.errors)}`;
}

function otherErrorsMessage(errors) {
  var count = errorCount(errors);
  if (count > 2) {
    return ` plus ${count} other errors.`;
  } else if (count == 2) {
    return ' plus 1 other error.';
  }

  return '';
}

function errorCount(errors) {
  if (Array.isArray(errors)) {
    return errors.len;
  } else {
    return 1;
  }
}

function message(errors) {
  if (Array.isArray(errors)) {
    return errors[0] && (` ${errors[0].title || errors[0].detail}`);
  } else {
    return ` ${errors}`;
  }
}

function statusString(raw) {
  if (raw.statusCode) {
    return `(Status ${raw.statusCode})`;
  } else {
    return '';
  }
}

function idString(raw) {
  if (raw.requestId) {
    return ` (Request ${raw.requestId})`;
  } else {
    return '';
  }
}

// Extend Native Error
_Error.prototype = Object.create(Error.prototype);

_Error.prototype.type = 'GenericError';
_Error.prototype.populate = function(type, message) {
  this.type = type;
  this.message = message;
};

_Error.extend = utils.protoExtend;

/**
 * Create subclass of internal Error klass
 * (Specifically for errors returned from Telnyx's REST API)
 */
var TelnyxError = _Error.TelnyxError = _Error.extend({
  type: 'TelnyxError',
  populate: function(raw) {
    var message;
    if (raw.message) {
      message = raw.message;
    } else {
      message = buildMessage(raw);
    }
    // Move from prototype def (so it appears in stringified obj)
    this.type = this.type;
    this.stack = (new Error(message)).stack;
    this.message = message;
    this.raw = raw;
    this.headers = raw.headers;
    this.requestId = raw.requestId;
    this.statusCode = raw.statusCode;
    this.responseBody = raw.responseBody;
  },
});

/**
 * Helper factory which takes raw stripe errors and outputs wrapping instances
 */
TelnyxError.generate = function(rawTelnyxError) {
  switch (rawTelnyxError.statusCode) {
  case 400:
    return new _Error.TelnyxInvalidRequestError(rawTelnyxError);
  case 401:
    return new _Error.TelnyxAuthenticationError(rawTelnyxError);
  case 403:
    return new _Error.TelnyxPermissionError(rawTelnyxError);
  case 404:
    return new _Error.TelnyxResourceNotFoundError(rawTelnyxError);
  case 405:
    return new _Error.TelnyxMethodNotSupportedError(rawTelnyxError);
  case 408:
    return new _Error.TelnyxTimeoutError(rawTelnyxError);
  case 415:
    return new _Error.TelnyxUnsupportedMediaTypeError(rawTelnyxError);
  case 422:
    return new _Error.TelnyxInvalidParametersError(rawTelnyxError);
  case 429:
    return new _Error.TelnyxRateLimitError(rawTelnyxError);
  case 500:
    return new _Error.TelnyxAPIError(rawTelnyxError);
  case 503:
    return new _Error.TelnyxServiceUnavailableError(rawTelnyxError);
  }
  return new _Error('Generic', 'Unknown Error');
};

// Specific Telnyx Error types:
_Error.TelnyxInvalidRequestError = TelnyxError.extend({type: 'TelnyxInvalidRequestError'}); // 400
_Error.TelnyxAuthenticationError = TelnyxError.extend({type: 'TelnyxAuthenticationError'}); // 401
_Error.TelnyxPermissionError = TelnyxError.extend({type: 'TelnyxPermissionError'}); // 403
_Error.TelnyxResourceNotFoundError = TelnyxError.extend({type: 'TelnyxResourceNotFoundError'}); // 404
_Error.TelnyxMethodNotSupportedError = TelnyxError.extend({type: 'TelnyxMethodNotSupportedError'}); // 405
_Error.TelnyxTimeoutError = TelnyxError.extend({type: 'TelnyxTimeoutError'}); // 408
_Error.TelnyxUnsupportedMediaTypeError = TelnyxError.extend({type: 'TelnyxUnsupportedMediaTypeError'}); // 415
_Error.TelnyxInvalidParametersError = TelnyxError.extend({type: 'TelnyxInvalidParametersError'}); // 422
_Error.TelnyxRateLimitError = TelnyxError.extend({type: 'TelnyxRateLimitError'}); // 429
_Error.TelnyxAPIError = TelnyxError.extend({type: 'TelnyxAPIError'}); // 500
_Error.TelnyxServiceUnavailableError = TelnyxError.extend({type: 'TelnyxServiceUnavailableError'}); // 503

_Error.TelnyxConnectionError = TelnyxError.extend({type: 'TelnyxConnectionError'});
_Error.TelnyxSignatureVerificationError = TelnyxError.extend({type: 'TelnyxSignatureVerificationError'});


/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("http");

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable node/no-deprecated-api */
var buffer = __webpack_require__(35)
var Buffer = buffer.Buffer

// alternative to using Object.keys for old browsers
function copyProps (src, dst) {
  for (var key in src) {
    dst[key] = src[key]
  }
}
if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) {
  module.exports = buffer
} else {
  // Copy properties from require('buffer')
  copyProps(buffer, exports)
  exports.Buffer = SafeBuffer
}

function SafeBuffer (arg, encodingOrOffset, length) {
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.prototype = Object.create(Buffer.prototype)

// Copy static methods from Buffer
copyProps(Buffer, SafeBuffer)

SafeBuffer.from = function (arg, encodingOrOffset, length) {
  if (typeof arg === 'number') {
    throw new TypeError('Argument must not be a number')
  }
  return Buffer(arg, encodingOrOffset, length)
}

SafeBuffer.alloc = function (size, fill, encoding) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  var buf = Buffer(size)
  if (fill !== undefined) {
    if (typeof encoding === 'string') {
      buf.fill(fill, encoding)
    } else {
      buf.fill(fill)
    }
  } else {
    buf.fill(0)
  }
  return buf
}

SafeBuffer.allocUnsafe = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return Buffer(size)
}

SafeBuffer.allocUnsafeSlow = function (size) {
  if (typeof size !== 'number') {
    throw new TypeError('Argument must be a number')
  }
  return buffer.SlowBuffer(size)
}


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var base64VLQ = __webpack_require__(7);
var util = __webpack_require__(2);
var ArraySet = __webpack_require__(8).ArraySet;
var MappingList = __webpack_require__(25).MappingList;

/**
 * An instance of the SourceMapGenerator represents a source map which is
 * being built incrementally. You may pass an object with the following
 * properties:
 *
 *   - file: The filename of the generated source.
 *   - sourceRoot: A root for all relative URLs in this source map.
 */
function SourceMapGenerator(aArgs) {
  if (!aArgs) {
    aArgs = {};
  }
  this._file = util.getArg(aArgs, 'file', null);
  this._sourceRoot = util.getArg(aArgs, 'sourceRoot', null);
  this._skipValidation = util.getArg(aArgs, 'skipValidation', false);
  this._sources = new ArraySet();
  this._names = new ArraySet();
  this._mappings = new MappingList();
  this._sourcesContents = null;
}

SourceMapGenerator.prototype._version = 3;

/**
 * Creates a new SourceMapGenerator based on a SourceMapConsumer
 *
 * @param aSourceMapConsumer The SourceMap.
 */
SourceMapGenerator.fromSourceMap =
  function SourceMapGenerator_fromSourceMap(aSourceMapConsumer) {
    var sourceRoot = aSourceMapConsumer.sourceRoot;
    var generator = new SourceMapGenerator({
      file: aSourceMapConsumer.file,
      sourceRoot: sourceRoot
    });
    aSourceMapConsumer.eachMapping(function (mapping) {
      var newMapping = {
        generated: {
          line: mapping.generatedLine,
          column: mapping.generatedColumn
        }
      };

      if (mapping.source != null) {
        newMapping.source = mapping.source;
        if (sourceRoot != null) {
          newMapping.source = util.relative(sourceRoot, newMapping.source);
        }

        newMapping.original = {
          line: mapping.originalLine,
          column: mapping.originalColumn
        };

        if (mapping.name != null) {
          newMapping.name = mapping.name;
        }
      }

      generator.addMapping(newMapping);
    });
    aSourceMapConsumer.sources.forEach(function (sourceFile) {
      var content = aSourceMapConsumer.sourceContentFor(sourceFile);
      if (content != null) {
        generator.setSourceContent(sourceFile, content);
      }
    });
    return generator;
  };

/**
 * Add a single mapping from original source line and column to the generated
 * source's line and column for this source map being created. The mapping
 * object should have the following properties:
 *
 *   - generated: An object with the generated line and column positions.
 *   - original: An object with the original line and column positions.
 *   - source: The original source file (relative to the sourceRoot).
 *   - name: An optional original token name for this mapping.
 */
SourceMapGenerator.prototype.addMapping =
  function SourceMapGenerator_addMapping(aArgs) {
    var generated = util.getArg(aArgs, 'generated');
    var original = util.getArg(aArgs, 'original', null);
    var source = util.getArg(aArgs, 'source', null);
    var name = util.getArg(aArgs, 'name', null);

    if (!this._skipValidation) {
      this._validateMapping(generated, original, source, name);
    }

    if (source != null) {
      source = String(source);
      if (!this._sources.has(source)) {
        this._sources.add(source);
      }
    }

    if (name != null) {
      name = String(name);
      if (!this._names.has(name)) {
        this._names.add(name);
      }
    }

    this._mappings.add({
      generatedLine: generated.line,
      generatedColumn: generated.column,
      originalLine: original != null && original.line,
      originalColumn: original != null && original.column,
      source: source,
      name: name
    });
  };

/**
 * Set the source content for a source file.
 */
SourceMapGenerator.prototype.setSourceContent =
  function SourceMapGenerator_setSourceContent(aSourceFile, aSourceContent) {
    var source = aSourceFile;
    if (this._sourceRoot != null) {
      source = util.relative(this._sourceRoot, source);
    }

    if (aSourceContent != null) {
      // Add the source content to the _sourcesContents map.
      // Create a new _sourcesContents map if the property is null.
      if (!this._sourcesContents) {
        this._sourcesContents = Object.create(null);
      }
      this._sourcesContents[util.toSetString(source)] = aSourceContent;
    } else if (this._sourcesContents) {
      // Remove the source file from the _sourcesContents map.
      // If the _sourcesContents map is empty, set the property to null.
      delete this._sourcesContents[util.toSetString(source)];
      if (Object.keys(this._sourcesContents).length === 0) {
        this._sourcesContents = null;
      }
    }
  };

/**
 * Applies the mappings of a sub-source-map for a specific source file to the
 * source map being generated. Each mapping to the supplied source file is
 * rewritten using the supplied source map. Note: The resolution for the
 * resulting mappings is the minimium of this map and the supplied map.
 *
 * @param aSourceMapConsumer The source map to be applied.
 * @param aSourceFile Optional. The filename of the source file.
 *        If omitted, SourceMapConsumer's file property will be used.
 * @param aSourceMapPath Optional. The dirname of the path to the source map
 *        to be applied. If relative, it is relative to the SourceMapConsumer.
 *        This parameter is needed when the two source maps aren't in the same
 *        directory, and the source map to be applied contains relative source
 *        paths. If so, those relative source paths need to be rewritten
 *        relative to the SourceMapGenerator.
 */
SourceMapGenerator.prototype.applySourceMap =
  function SourceMapGenerator_applySourceMap(aSourceMapConsumer, aSourceFile, aSourceMapPath) {
    var sourceFile = aSourceFile;
    // If aSourceFile is omitted, we will use the file property of the SourceMap
    if (aSourceFile == null) {
      if (aSourceMapConsumer.file == null) {
        throw new Error(
          'SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, ' +
          'or the source map\'s "file" property. Both were omitted.'
        );
      }
      sourceFile = aSourceMapConsumer.file;
    }
    var sourceRoot = this._sourceRoot;
    // Make "sourceFile" relative if an absolute Url is passed.
    if (sourceRoot != null) {
      sourceFile = util.relative(sourceRoot, sourceFile);
    }
    // Applying the SourceMap can add and remove items from the sources and
    // the names array.
    var newSources = new ArraySet();
    var newNames = new ArraySet();

    // Find mappings for the "sourceFile"
    this._mappings.unsortedForEach(function (mapping) {
      if (mapping.source === sourceFile && mapping.originalLine != null) {
        // Check if it can be mapped by the source map, then update the mapping.
        var original = aSourceMapConsumer.originalPositionFor({
          line: mapping.originalLine,
          column: mapping.originalColumn
        });
        if (original.source != null) {
          // Copy mapping
          mapping.source = original.source;
          if (aSourceMapPath != null) {
            mapping.source = util.join(aSourceMapPath, mapping.source)
          }
          if (sourceRoot != null) {
            mapping.source = util.relative(sourceRoot, mapping.source);
          }
          mapping.originalLine = original.line;
          mapping.originalColumn = original.column;
          if (original.name != null) {
            mapping.name = original.name;
          }
        }
      }

      var source = mapping.source;
      if (source != null && !newSources.has(source)) {
        newSources.add(source);
      }

      var name = mapping.name;
      if (name != null && !newNames.has(name)) {
        newNames.add(name);
      }

    }, this);
    this._sources = newSources;
    this._names = newNames;

    // Copy sourcesContents of applied map.
    aSourceMapConsumer.sources.forEach(function (sourceFile) {
      var content = aSourceMapConsumer.sourceContentFor(sourceFile);
      if (content != null) {
        if (aSourceMapPath != null) {
          sourceFile = util.join(aSourceMapPath, sourceFile);
        }
        if (sourceRoot != null) {
          sourceFile = util.relative(sourceRoot, sourceFile);
        }
        this.setSourceContent(sourceFile, content);
      }
    }, this);
  };

/**
 * A mapping can have one of the three levels of data:
 *
 *   1. Just the generated position.
 *   2. The Generated position, original position, and original source.
 *   3. Generated and original position, original source, as well as a name
 *      token.
 *
 * To maintain consistency, we validate that any new mapping being added falls
 * in to one of these categories.
 */
SourceMapGenerator.prototype._validateMapping =
  function SourceMapGenerator_validateMapping(aGenerated, aOriginal, aSource,
                                              aName) {
    // When aOriginal is truthy but has empty values for .line and .column,
    // it is most likely a programmer error. In this case we throw a very
    // specific error message to try to guide them the right way.
    // For example: https://github.com/Polymer/polymer-bundler/pull/519
    if (aOriginal && typeof aOriginal.line !== 'number' && typeof aOriginal.column !== 'number') {
        throw new Error(
            'original.line and original.column are not numbers -- you probably meant to omit ' +
            'the original mapping entirely and only map the generated position. If so, pass ' +
            'null for the original mapping instead of an object with empty or null values.'
        );
    }

    if (aGenerated && 'line' in aGenerated && 'column' in aGenerated
        && aGenerated.line > 0 && aGenerated.column >= 0
        && !aOriginal && !aSource && !aName) {
      // Case 1.
      return;
    }
    else if (aGenerated && 'line' in aGenerated && 'column' in aGenerated
             && aOriginal && 'line' in aOriginal && 'column' in aOriginal
             && aGenerated.line > 0 && aGenerated.column >= 0
             && aOriginal.line > 0 && aOriginal.column >= 0
             && aSource) {
      // Cases 2 and 3.
      return;
    }
    else {
      throw new Error('Invalid mapping: ' + JSON.stringify({
        generated: aGenerated,
        source: aSource,
        original: aOriginal,
        name: aName
      }));
    }
  };

/**
 * Serialize the accumulated mappings in to the stream of base 64 VLQs
 * specified by the source map format.
 */
SourceMapGenerator.prototype._serializeMappings =
  function SourceMapGenerator_serializeMappings() {
    var previousGeneratedColumn = 0;
    var previousGeneratedLine = 1;
    var previousOriginalColumn = 0;
    var previousOriginalLine = 0;
    var previousName = 0;
    var previousSource = 0;
    var result = '';
    var next;
    var mapping;
    var nameIdx;
    var sourceIdx;

    var mappings = this._mappings.toArray();
    for (var i = 0, len = mappings.length; i < len; i++) {
      mapping = mappings[i];
      next = ''

      if (mapping.generatedLine !== previousGeneratedLine) {
        previousGeneratedColumn = 0;
        while (mapping.generatedLine !== previousGeneratedLine) {
          next += ';';
          previousGeneratedLine++;
        }
      }
      else {
        if (i > 0) {
          if (!util.compareByGeneratedPositionsInflated(mapping, mappings[i - 1])) {
            continue;
          }
          next += ',';
        }
      }

      next += base64VLQ.encode(mapping.generatedColumn
                                 - previousGeneratedColumn);
      previousGeneratedColumn = mapping.generatedColumn;

      if (mapping.source != null) {
        sourceIdx = this._sources.indexOf(mapping.source);
        next += base64VLQ.encode(sourceIdx - previousSource);
        previousSource = sourceIdx;

        // lines are stored 0-based in SourceMap spec version 3
        next += base64VLQ.encode(mapping.originalLine - 1
                                   - previousOriginalLine);
        previousOriginalLine = mapping.originalLine - 1;

        next += base64VLQ.encode(mapping.originalColumn
                                   - previousOriginalColumn);
        previousOriginalColumn = mapping.originalColumn;

        if (mapping.name != null) {
          nameIdx = this._names.indexOf(mapping.name);
          next += base64VLQ.encode(nameIdx - previousName);
          previousName = nameIdx;
        }
      }

      result += next;
    }

    return result;
  };

SourceMapGenerator.prototype._generateSourcesContent =
  function SourceMapGenerator_generateSourcesContent(aSources, aSourceRoot) {
    return aSources.map(function (source) {
      if (!this._sourcesContents) {
        return null;
      }
      if (aSourceRoot != null) {
        source = util.relative(aSourceRoot, source);
      }
      var key = util.toSetString(source);
      return Object.prototype.hasOwnProperty.call(this._sourcesContents, key)
        ? this._sourcesContents[key]
        : null;
    }, this);
  };

/**
 * Externalize the source map.
 */
SourceMapGenerator.prototype.toJSON =
  function SourceMapGenerator_toJSON() {
    var map = {
      version: this._version,
      sources: this._sources.toArray(),
      names: this._names.toArray(),
      mappings: this._serializeMappings()
    };
    if (this._file != null) {
      map.file = this._file;
    }
    if (this._sourceRoot != null) {
      map.sourceRoot = this._sourceRoot;
    }
    if (this._sourcesContents) {
      map.sourcesContent = this._generateSourcesContent(map.sources, map.sourceRoot);
    }

    return map;
  };

/**
 * Render the source map being generated to a string.
 */
SourceMapGenerator.prototype.toString =
  function SourceMapGenerator_toString() {
    return JSON.stringify(this.toJSON());
  };

exports.SourceMapGenerator = SourceMapGenerator;


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 *
 * Based on the Base 64 VLQ implementation in Closure Compiler:
 * https://code.google.com/p/closure-compiler/source/browse/trunk/src/com/google/debugging/sourcemap/Base64VLQ.java
 *
 * Copyright 2011 The Closure Compiler Authors. All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *  * Neither the name of Google Inc. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

var base64 = __webpack_require__(24);

// A single base 64 digit can contain 6 bits of data. For the base 64 variable
// length quantities we use in the source map spec, the first bit is the sign,
// the next four bits are the actual value, and the 6th bit is the
// continuation bit. The continuation bit tells us whether there are more
// digits in this value following this digit.
//
//   Continuation
//   |    Sign
//   |    |
//   V    V
//   101011

var VLQ_BASE_SHIFT = 5;

// binary: 100000
var VLQ_BASE = 1 << VLQ_BASE_SHIFT;

// binary: 011111
var VLQ_BASE_MASK = VLQ_BASE - 1;

// binary: 100000
var VLQ_CONTINUATION_BIT = VLQ_BASE;

/**
 * Converts from a two-complement value to a value where the sign bit is
 * placed in the least significant bit.  For example, as decimals:
 *   1 becomes 2 (10 binary), -1 becomes 3 (11 binary)
 *   2 becomes 4 (100 binary), -2 becomes 5 (101 binary)
 */
function toVLQSigned(aValue) {
  return aValue < 0
    ? ((-aValue) << 1) + 1
    : (aValue << 1) + 0;
}

/**
 * Converts to a two-complement value from a value where the sign bit is
 * placed in the least significant bit.  For example, as decimals:
 *   2 (10 binary) becomes 1, 3 (11 binary) becomes -1
 *   4 (100 binary) becomes 2, 5 (101 binary) becomes -2
 */
function fromVLQSigned(aValue) {
  var isNegative = (aValue & 1) === 1;
  var shifted = aValue >> 1;
  return isNegative
    ? -shifted
    : shifted;
}

/**
 * Returns the base 64 VLQ encoded value.
 */
exports.encode = function base64VLQ_encode(aValue) {
  var encoded = "";
  var digit;

  var vlq = toVLQSigned(aValue);

  do {
    digit = vlq & VLQ_BASE_MASK;
    vlq >>>= VLQ_BASE_SHIFT;
    if (vlq > 0) {
      // There are still more digits in this value, so we must make sure the
      // continuation bit is marked.
      digit |= VLQ_CONTINUATION_BIT;
    }
    encoded += base64.encode(digit);
  } while (vlq > 0);

  return encoded;
};

/**
 * Decodes the next base 64 VLQ value from the given string and returns the
 * value and the rest of the string via the out parameter.
 */
exports.decode = function base64VLQ_decode(aStr, aIndex, aOutParam) {
  var strLen = aStr.length;
  var result = 0;
  var shift = 0;
  var continuation, digit;

  do {
    if (aIndex >= strLen) {
      throw new Error("Expected more digits in base 64 VLQ value.");
    }

    digit = base64.decode(aStr.charCodeAt(aIndex++));
    if (digit === -1) {
      throw new Error("Invalid base64 digit: " + aStr.charAt(aIndex - 1));
    }

    continuation = !!(digit & VLQ_CONTINUATION_BIT);
    digit &= VLQ_BASE_MASK;
    result = result + (digit << shift);
    shift += VLQ_BASE_SHIFT;
  } while (continuation);

  aOutParam.value = fromVLQSigned(result);
  aOutParam.rest = aIndex;
};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var util = __webpack_require__(2);
var has = Object.prototype.hasOwnProperty;
var hasNativeMap = typeof Map !== "undefined";

/**
 * A data structure which is a combination of an array and a set. Adding a new
 * member is O(1), testing for membership is O(1), and finding the index of an
 * element is O(1). Removing elements from the set is not supported. Only
 * strings are supported for membership.
 */
function ArraySet() {
  this._array = [];
  this._set = hasNativeMap ? new Map() : Object.create(null);
}

/**
 * Static method for creating ArraySet instances from an existing array.
 */
ArraySet.fromArray = function ArraySet_fromArray(aArray, aAllowDuplicates) {
  var set = new ArraySet();
  for (var i = 0, len = aArray.length; i < len; i++) {
    set.add(aArray[i], aAllowDuplicates);
  }
  return set;
};

/**
 * Return how many unique items are in this ArraySet. If duplicates have been
 * added, than those do not count towards the size.
 *
 * @returns Number
 */
ArraySet.prototype.size = function ArraySet_size() {
  return hasNativeMap ? this._set.size : Object.getOwnPropertyNames(this._set).length;
};

/**
 * Add the given string to this set.
 *
 * @param String aStr
 */
ArraySet.prototype.add = function ArraySet_add(aStr, aAllowDuplicates) {
  var sStr = hasNativeMap ? aStr : util.toSetString(aStr);
  var isDuplicate = hasNativeMap ? this.has(aStr) : has.call(this._set, sStr);
  var idx = this._array.length;
  if (!isDuplicate || aAllowDuplicates) {
    this._array.push(aStr);
  }
  if (!isDuplicate) {
    if (hasNativeMap) {
      this._set.set(aStr, idx);
    } else {
      this._set[sStr] = idx;
    }
  }
};

/**
 * Is the given string a member of this set?
 *
 * @param String aStr
 */
ArraySet.prototype.has = function ArraySet_has(aStr) {
  if (hasNativeMap) {
    return this._set.has(aStr);
  } else {
    var sStr = util.toSetString(aStr);
    return has.call(this._set, sStr);
  }
};

/**
 * What is the index of the given string in the array?
 *
 * @param String aStr
 */
ArraySet.prototype.indexOf = function ArraySet_indexOf(aStr) {
  if (hasNativeMap) {
    var idx = this._set.get(aStr);
    if (idx >= 0) {
        return idx;
    }
  } else {
    var sStr = util.toSetString(aStr);
    if (has.call(this._set, sStr)) {
      return this._set[sStr];
    }
  }

  throw new Error('"' + aStr + '" is not in the set.');
};

/**
 * What is the element at the given index?
 *
 * @param Number aIdx
 */
ArraySet.prototype.at = function ArraySet_at(aIdx) {
  if (aIdx >= 0 && aIdx < this._array.length) {
    return this._array[aIdx];
  }
  throw new Error('No element indexed by ' + aIdx);
};

/**
 * Returns the array representation of this set (which has the proper indices
 * indicated by indexOf). Note that this is a copy of the internal array used
 * for storing the members so that no one can mess with internal state.
 */
ArraySet.prototype.toArray = function ArraySet_toArray() {
  return this._array.slice();
};

exports.ArraySet = ArraySet;


/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("https");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var has = Object.prototype.hasOwnProperty;
var isArray = Array.isArray;

var hexTable = (function () {
    var array = [];
    for (var i = 0; i < 256; ++i) {
        array.push('%' + ((i < 16 ? '0' : '') + i.toString(16)).toUpperCase());
    }

    return array;
}());

var compactQueue = function compactQueue(queue) {
    while (queue.length > 1) {
        var item = queue.pop();
        var obj = item.obj[item.prop];

        if (isArray(obj)) {
            var compacted = [];

            for (var j = 0; j < obj.length; ++j) {
                if (typeof obj[j] !== 'undefined') {
                    compacted.push(obj[j]);
                }
            }

            item.obj[item.prop] = compacted;
        }
    }
};

var arrayToObject = function arrayToObject(source, options) {
    var obj = options && options.plainObjects ? Object.create(null) : {};
    for (var i = 0; i < source.length; ++i) {
        if (typeof source[i] !== 'undefined') {
            obj[i] = source[i];
        }
    }

    return obj;
};

var merge = function merge(target, source, options) {
    if (!source) {
        return target;
    }

    if (typeof source !== 'object') {
        if (isArray(target)) {
            target.push(source);
        } else if (target && typeof target === 'object') {
            if ((options && (options.plainObjects || options.allowPrototypes)) || !has.call(Object.prototype, source)) {
                target[source] = true;
            }
        } else {
            return [target, source];
        }

        return target;
    }

    if (!target || typeof target !== 'object') {
        return [target].concat(source);
    }

    var mergeTarget = target;
    if (isArray(target) && !isArray(source)) {
        mergeTarget = arrayToObject(target, options);
    }

    if (isArray(target) && isArray(source)) {
        source.forEach(function (item, i) {
            if (has.call(target, i)) {
                var targetItem = target[i];
                if (targetItem && typeof targetItem === 'object' && item && typeof item === 'object') {
                    target[i] = merge(targetItem, item, options);
                } else {
                    target.push(item);
                }
            } else {
                target[i] = item;
            }
        });
        return target;
    }

    return Object.keys(source).reduce(function (acc, key) {
        var value = source[key];

        if (has.call(acc, key)) {
            acc[key] = merge(acc[key], value, options);
        } else {
            acc[key] = value;
        }
        return acc;
    }, mergeTarget);
};

var assign = function assignSingleSource(target, source) {
    return Object.keys(source).reduce(function (acc, key) {
        acc[key] = source[key];
        return acc;
    }, target);
};

var decode = function (str, decoder, charset) {
    var strWithoutPlus = str.replace(/\+/g, ' ');
    if (charset === 'iso-8859-1') {
        // unescape never throws, no try...catch needed:
        return strWithoutPlus.replace(/%[0-9a-f]{2}/gi, unescape);
    }
    // utf-8
    try {
        return decodeURIComponent(strWithoutPlus);
    } catch (e) {
        return strWithoutPlus;
    }
};

var encode = function encode(str, defaultEncoder, charset) {
    // This code was originally written by Brian White (mscdex) for the io.js core querystring library.
    // It has been adapted here for stricter adherence to RFC 3986
    if (str.length === 0) {
        return str;
    }

    var string = typeof str === 'string' ? str : String(str);

    if (charset === 'iso-8859-1') {
        return escape(string).replace(/%u[0-9a-f]{4}/gi, function ($0) {
            return '%26%23' + parseInt($0.slice(2), 16) + '%3B';
        });
    }

    var out = '';
    for (var i = 0; i < string.length; ++i) {
        var c = string.charCodeAt(i);

        if (
            c === 0x2D // -
            || c === 0x2E // .
            || c === 0x5F // _
            || c === 0x7E // ~
            || (c >= 0x30 && c <= 0x39) // 0-9
            || (c >= 0x41 && c <= 0x5A) // a-z
            || (c >= 0x61 && c <= 0x7A) // A-Z
        ) {
            out += string.charAt(i);
            continue;
        }

        if (c < 0x80) {
            out = out + hexTable[c];
            continue;
        }

        if (c < 0x800) {
            out = out + (hexTable[0xC0 | (c >> 6)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        if (c < 0xD800 || c >= 0xE000) {
            out = out + (hexTable[0xE0 | (c >> 12)] + hexTable[0x80 | ((c >> 6) & 0x3F)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        i += 1;
        c = 0x10000 + (((c & 0x3FF) << 10) | (string.charCodeAt(i) & 0x3FF));
        out += hexTable[0xF0 | (c >> 18)]
            + hexTable[0x80 | ((c >> 12) & 0x3F)]
            + hexTable[0x80 | ((c >> 6) & 0x3F)]
            + hexTable[0x80 | (c & 0x3F)];
    }

    return out;
};

var compact = function compact(value) {
    var queue = [{ obj: { o: value }, prop: 'o' }];
    var refs = [];

    for (var i = 0; i < queue.length; ++i) {
        var item = queue[i];
        var obj = item.obj[item.prop];

        var keys = Object.keys(obj);
        for (var j = 0; j < keys.length; ++j) {
            var key = keys[j];
            var val = obj[key];
            if (typeof val === 'object' && val !== null && refs.indexOf(val) === -1) {
                queue.push({ obj: obj, prop: key });
                refs.push(val);
            }
        }
    }

    compactQueue(queue);

    return value;
};

var isRegExp = function isRegExp(obj) {
    return Object.prototype.toString.call(obj) === '[object RegExp]';
};

var isBuffer = function isBuffer(obj) {
    if (!obj || typeof obj !== 'object') {
        return false;
    }

    return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
};

var combine = function combine(a, b) {
    return [].concat(a, b);
};

module.exports = {
    arrayToObject: arrayToObject,
    assign: assign,
    combine: combine,
    compact: compact,
    decode: decode,
    encode: encode,
    isBuffer: isBuffer,
    isRegExp: isRegExp,
    merge: merge
};


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var replace = String.prototype.replace;
var percentTwenties = /%20/g;

module.exports = {
    'default': 'RFC3986',
    formatters: {
        RFC1738: function (value) {
            return replace.call(value, percentTwenties, '+');
        },
        RFC3986: function (value) {
            return value;
        }
    },
    RFC1738: 'RFC1738',
    RFC3986: 'RFC3986'
};


/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),
/* 15 */
/***/ (function(module, exports) {

/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** `Object#toString` result references. */
var objectTag = '[object Object]';

/**
 * Checks if `value` is a host object in IE < 9.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a host object, else `false`.
 */
function isHostObject(value) {
  // Many host objects are `Object` objects that can coerce to strings
  // despite having improperly defined `toString` methods.
  var result = false;
  if (value != null && typeof value.toString != 'function') {
    try {
      result = !!(value + '');
    } catch (e) {}
  }
  return result;
}

/**
 * Creates a unary function that invokes `func` with its argument transformed.
 *
 * @private
 * @param {Function} func The function to wrap.
 * @param {Function} transform The argument transform.
 * @returns {Function} Returns the new function.
 */
function overArg(func, transform) {
  return function(arg) {
    return func(transform(arg));
  };
}

/** Used for built-in method references. */
var funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/** Used to infer the `Object` constructor. */
var objectCtorString = funcToString.call(Object);

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/** Built-in value references. */
var getPrototype = overArg(Object.getPrototypeOf, Object);

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is a plain object, that is, an object created by the
 * `Object` constructor or one with a `[[Prototype]]` of `null`.
 *
 * @static
 * @memberOf _
 * @since 0.8.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a plain object, else `false`.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 * }
 *
 * _.isPlainObject(new Foo);
 * // => false
 *
 * _.isPlainObject([1, 2, 3]);
 * // => false
 *
 * _.isPlainObject({ 'x': 0, 'y': 0 });
 * // => true
 *
 * _.isPlainObject(Object.create(null));
 * // => true
 */
function isPlainObject(value) {
  if (!isObjectLike(value) ||
      objectToString.call(value) != objectTag || isHostObject(value)) {
    return false;
  }
  var proto = getPrototype(value);
  if (proto === null) {
    return true;
  }
  var Ctor = hasOwnProperty.call(proto, 'constructor') && proto.constructor;
  return (typeof Ctor == 'function' &&
    Ctor instanceof Ctor && funcToString.call(Ctor) == objectCtorString);
}

module.exports = isPlainObject;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(1);
var makeRequest = __webpack_require__(17);
var makeAutoPaginationMethods = __webpack_require__(40).makeAutoPaginationMethods;

/**
 * Create an API method from the declared spec.
 *
 * @param [spec.method='GET'] Request Method (POST, GET, DELETE, PUT, PATCH)
 * @param [spec.path=''] Path to be appended to the API BASE_PATH, joined with
 *  the instance's path (e.g. 'messaging_profiles' or 'available_phone_numbers')
 * @param [spec.urlParams=[]] Array of required arguments in the order that they
 *  must be passed by the consumer of the API. Subsequent optional arguments are
 *  optionally passed through a hash (Object) as the penultimate argument
 *  (preceding the also-optional callback argument
 * @param [spec.paramsNames=[]] Array of required arguments in the order that they
 *  are to be used instead of being passed by the consumer of the API. Useful for nested resources
 *  in a manner that consumer doesn't need to provide path arguments
 * @param [spec.paramsValues=[]] Array of substitute require arguments in `paramsNames` values
 * @param [spec.encode] Function for mutating input parameters to a method.
 *  Usefully for applying transforms to data on a per-method basis.
 * @param [spec.host] Hostname for the request.
 * @param [spec.transformResponseData]   mutates response data to decorate with any util functions or info.
 */
function telnyxMethod(spec) {
  return function() {
    var self = this;
    var args = [].slice.call(arguments);

    if (spec.paramsValues) {
      populateUrlParamsWithResource(self, args, spec);
    }

    var callback = typeof args[args.length - 1] == 'function' && args.pop();

    var requestPromise = utils.callbackifyPromiseWithTimeout(makeRequest(self, args, spec, {}), callback)

    if (spec.methodType === 'list') {
      var autoPaginationMethods = makeAutoPaginationMethods(self, args, spec, requestPromise);
      Object.assign(requestPromise, autoPaginationMethods);
    }

    return requestPromise;
  };
}

/**
 * Populate nested method URL params with resource object attributes that match the param name.
 * This allows you to do things like setting the `call_control_id` attribute from an existing call object on a new instance of `telnyx.calls`.
 */
function populateUrlParamsWithResource(self, args, spec) {
  // if url params is not in resource response data.
  if (!spec.paramsValues[0]) {
    const paramsValues = spec.paramsNames.reduce(function(result, name) {
      if (self[name]) {
        result.push(self[name]);
      }
      return result;
    }, []);

    args.unshift(paramsValues);
  } else {
    args.unshift(spec.paramsValues);
  }
}

module.exports = telnyxMethod;


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(1);
var OPTIONAL_REGEX = /^optional!/;

function getRequestOpts(self, requestArgs, spec, overrideData) {
  // Extract spec values with defaults.
  var commandPath = typeof spec.path == 'function' ? spec.path
    : utils.makeURLInterpolator(spec.path || '');
  var requestMethod = (spec.method || 'GET').toUpperCase();
  var urlParams = spec.urlParams || [];
  var encode = spec.encode || function(data) {return data;};
  var host = spec.host;

  // Don't mutate args externally.
  var args = [].slice.call(requestArgs);

  // Generate and validate url params.
  var urlData = self.createUrlData();
  for (var i = 0, l = urlParams.length; i < l; ++i) {
    var path;

    // Note that we shift the args array after every iteration so this just
    // grabs the "next" argument for use as a URL parameter.
    var arg = args[0];

    var param = urlParams[i];

    var isOptional = OPTIONAL_REGEX.test(param);
    param = param.replace(OPTIONAL_REGEX, '');

    if (param == 'id' && typeof arg !== 'string') {
      path = self.createResourcePathWithSymbols(spec.path);
      throw new Error(
        'Telnyx: "id" must be a string, but got: ' + typeof arg +
        ' (on API request to `' + requestMethod + ' ' + path + '`)'
      );
    }

    if (!arg) {
      if (isOptional) {
        urlData[param] = '';
        continue;
      }

      path = self.createResourcePathWithSymbols(spec.path);
      throw new Error(
        'Telnyx: Argument "' + urlParams[i] + '" required, but got: ' + arg +
        ' (on API request to `' + requestMethod + ' ' + path + '`)'
      );
    }

    urlData[param] = args.shift();
  }

  // Pull request data and options (headers, auth) from args.
  var dataFromArgs = utils.getDataFromArgs(args);
  var data = encode(Object.assign({}, dataFromArgs, overrideData));
  var options = utils.getOptionsFromArgs(args);

  // Validate that there are no more args.
  if (args.length) {
    path = self.createResourcePathWithSymbols(spec.path);
    throw new Error(
      'Telnyx: Unknown arguments (' + args + '). Did you mean to pass an options ' +
      'object? (on API request to ' + requestMethod + ' `' + path + '`)'
    );
  }

  var requestPath = self.createFullPath(commandPath, urlData);
  var headers = Object.assign(options.headers, spec.headers);

  if (spec.validator) {
    spec.validator(data, {headers: headers});
  }

  return {
    requestMethod: requestMethod,
    requestPath: requestPath,
    data: data,
    auth: options.auth,
    headers: headers,
    host: host,
  };
}

function makeRequest(self, requestArgs, spec, overrideData) {
  return new Promise(function(resolve, reject) {
    try {
      var opts = getRequestOpts(self, requestArgs, spec, overrideData);
    } catch (err) {
      reject(err);
      return;
    }

    function requestCallback(err, response) {
      if (err) {
        reject(err);
      } else {
        resolve(
          spec.transformResponseData && response.data ?
            spec.transformResponseData(response, self._telnyx) :
            response
        );
      }
    }

    self._request(opts.requestMethod, opts.host, opts.requestPath, opts.data, opts.auth, {headers: opts.headers}, requestCallback);
  });
}

module.exports = makeRequest;


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'phoneNumbersInboundChannels',
    {
      update: telnyxMethod({
        method: 'PATCH',
        path: '',
        urlParams: ['channels'],
        paramsValues: [response.data.id],
        paramsNames: ['channels'],
      }),
    }
  );
}

module.exports = __webpack_require__(0).extend({
  path: 'phone_numbers/inbound_channels',

  retrieve: telnyxMethod({
    method: 'GET',
    path: '',
    urlParams: [],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var Buffer = __webpack_require__(5).Buffer;
var nacl = __webpack_require__(86);

var Error = __webpack_require__(3);

var Webhook = {
  DEFAULT_TOLERANCE: 300, // 5 minutes

  constructEvent: function(payload, signatureHeader, timestampHeader, publicKey, tolerance) {
    this.signature.verifySignature(payload, signatureHeader, timestampHeader, publicKey, tolerance || Webhook.DEFAULT_TOLERANCE);

    var jsonPayload = JSON.parse(payload);
    return jsonPayload;
  },
};

var signature = {
  verifySignature: function(payload, signatureHeader = '', timestampHeader = '', publicKey, tolerance) {
    payload = Buffer.isBuffer(payload) ? payload.toString('utf8') : payload;
    timestampHeader = Buffer.isBuffer(timestampHeader) ? timestampHeader.toString('utf8') : timestampHeader;

    var payloadBuffer = Buffer.from(`${timestampHeader}|${payload}`, 'utf8');

    var verification;

    try {
      verification = nacl.sign.detached.verify(
        payloadBuffer,
        Buffer.from(signatureHeader, 'base64'),
        Buffer.from(publicKey, 'base64')
      );
    } catch (err) {
      throwSignatureVerificationError(payload, signatureHeader, timestampHeader);
    }

    if (!verification) {
      throwSignatureVerificationError(payload, signatureHeader, timestampHeader);
    }

    var timestampAge = Math.floor(Date.now() / 1000) - parseInt(timestampHeader, 10);

    if (tolerance > 0 && timestampAge > tolerance) {
      throw new Error.TelnyxSignatureVerificationError({
        message: 'Timestamp outside the tolerance zone',
        detail: {
          signatureHeader: signatureHeader,
          timestampHeader: timestampHeader,
          payload: payload,
        },
      });
    }

    return true;
  },
};

function throwSignatureVerificationError(payload, signatureHeader, timestampHeader) {
  throw new Error.TelnyxSignatureVerificationError({
    message: 'Signature is invalid and does not match the payload',
    detail: {
      signatureHeader: signatureHeader,
      timestampHeader: timestampHeader,
      payload: payload,
    },
  });
}

Webhook.signature = signature;

module.exports = Webhook;


/***/ }),
/* 20 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "main", function() { return main; });
/* harmony import */ var source_map_support_register__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21);
/* harmony import */ var source_map_support_register__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(source_map_support_register__WEBPACK_IMPORTED_MODULE_0__);


const telnyx = __webpack_require__(32)(process.env.telnyx_api_key);

async function main(event, context) {
  const data = JSON.parse(event.body);
  let body, statusCode;

  try {
    // Run the Lambda
    body = await telnyx.messages.create({
      'from': process.env.telnyx_number,
      // Your Telnyx number
      'to': data.phoneNumber,
      'text': data.workout,
      'webhook_url': process.env.telnyx_status_url,
      'use_profile_webhooks': false,
      'media_urls': ["https://i.pinimg.com/originals/a9/20/40/a920403fcd4e3cdac91374023af5f155.jpg"]
    });
    statusCode = 200;
  } catch (e) {
    body = {
      error: e.message
    };
    statusCode = 500;
  } // Return HTTP response


  return {
    statusCode,
    body: JSON.stringify(body),
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    }
  };
}
;

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(22).install();


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

var SourceMapConsumer = __webpack_require__(23).SourceMapConsumer;
var path = __webpack_require__(9);

var fs;
try {
  fs = __webpack_require__(30);
  if (!fs.existsSync || !fs.readFileSync) {
    // fs doesn't have all methods we need
    fs = null;
  }
} catch (err) {
  /* nop */
}

// Only install once if called multiple times
var errorFormatterInstalled = false;
var uncaughtShimInstalled = false;

// If true, the caches are reset before a stack trace formatting operation
var emptyCacheBetweenOperations = false;

// Supports {browser, node, auto}
var environment = "auto";

// Maps a file path to a string containing the file contents
var fileContentsCache = {};

// Maps a file path to a source map for that file
var sourceMapCache = {};

// Regex for detecting source maps
var reSourceMap = /^data:application\/json[^,]+base64,/;

// Priority list of retrieve handlers
var retrieveFileHandlers = [];
var retrieveMapHandlers = [];

function isInBrowser() {
  if (environment === "browser")
    return true;
  if (environment === "node")
    return false;
  return ((typeof window !== 'undefined') && (typeof XMLHttpRequest === 'function') && !(window.require && window.module && window.process && window.process.type === "renderer"));
}

function hasGlobalProcessEventEmitter() {
  return ((typeof process === 'object') && (process !== null) && (typeof process.on === 'function'));
}

function handlerExec(list) {
  return function(arg) {
    for (var i = 0; i < list.length; i++) {
      var ret = list[i](arg);
      if (ret) {
        return ret;
      }
    }
    return null;
  };
}

var retrieveFile = handlerExec(retrieveFileHandlers);

retrieveFileHandlers.push(function(path) {
  // Trim the path to make sure there is no extra whitespace.
  path = path.trim();
  if (path in fileContentsCache) {
    return fileContentsCache[path];
  }

  var contents = null;
  if (!fs) {
    // Use SJAX if we are in the browser
    var xhr = new XMLHttpRequest();
    xhr.open('GET', path, false);
    xhr.send(null);
    var contents = null
    if (xhr.readyState === 4 && xhr.status === 200) {
      contents = xhr.responseText
    }
  } else if (fs.existsSync(path)) {
    // Otherwise, use the filesystem
    try {
      contents = fs.readFileSync(path, 'utf8');
    } catch (er) {
      contents = '';
    }
  }

  return fileContentsCache[path] = contents;
});

// Support URLs relative to a directory, but be careful about a protocol prefix
// in case we are in the browser (i.e. directories may start with "http://")
function supportRelativeURL(file, url) {
  if (!file) return url;
  var dir = path.dirname(file);
  var match = /^\w+:\/\/[^\/]*/.exec(dir);
  var protocol = match ? match[0] : '';
  return protocol + path.resolve(dir.slice(protocol.length), url);
}

function retrieveSourceMapURL(source) {
  var fileData;

  if (isInBrowser()) {
     try {
       var xhr = new XMLHttpRequest();
       xhr.open('GET', source, false);
       xhr.send(null);
       fileData = xhr.readyState === 4 ? xhr.responseText : null;

       // Support providing a sourceMappingURL via the SourceMap header
       var sourceMapHeader = xhr.getResponseHeader("SourceMap") ||
                             xhr.getResponseHeader("X-SourceMap");
       if (sourceMapHeader) {
         return sourceMapHeader;
       }
     } catch (e) {
     }
  }

  // Get the URL of the source map
  fileData = retrieveFile(source);
  var re = /(?:\/\/[@#][ \t]+sourceMappingURL=([^\s'"]+?)[ \t]*$)|(?:\/\*[@#][ \t]+sourceMappingURL=([^\*]+?)[ \t]*(?:\*\/)[ \t]*$)/mg;
  // Keep executing the search to find the *last* sourceMappingURL to avoid
  // picking up sourceMappingURLs from comments, strings, etc.
  var lastMatch, match;
  while (match = re.exec(fileData)) lastMatch = match;
  if (!lastMatch) return null;
  return lastMatch[1];
};

// Can be overridden by the retrieveSourceMap option to install. Takes a
// generated source filename; returns a {map, optional url} object, or null if
// there is no source map.  The map field may be either a string or the parsed
// JSON object (ie, it must be a valid argument to the SourceMapConsumer
// constructor).
var retrieveSourceMap = handlerExec(retrieveMapHandlers);
retrieveMapHandlers.push(function(source) {
  var sourceMappingURL = retrieveSourceMapURL(source);
  if (!sourceMappingURL) return null;

  // Read the contents of the source map
  var sourceMapData;
  if (reSourceMap.test(sourceMappingURL)) {
    // Support source map URL as a data url
    var rawData = sourceMappingURL.slice(sourceMappingURL.indexOf(',') + 1);
    sourceMapData = new Buffer(rawData, "base64").toString();
    sourceMappingURL = source;
  } else {
    // Support source map URLs relative to the source URL
    sourceMappingURL = supportRelativeURL(source, sourceMappingURL);
    sourceMapData = retrieveFile(sourceMappingURL);
  }

  if (!sourceMapData) {
    return null;
  }

  return {
    url: sourceMappingURL,
    map: sourceMapData
  };
});

function mapSourcePosition(position) {
  var sourceMap = sourceMapCache[position.source];
  if (!sourceMap) {
    // Call the (overrideable) retrieveSourceMap function to get the source map.
    var urlAndMap = retrieveSourceMap(position.source);
    if (urlAndMap) {
      sourceMap = sourceMapCache[position.source] = {
        url: urlAndMap.url,
        map: new SourceMapConsumer(urlAndMap.map)
      };

      // Load all sources stored inline with the source map into the file cache
      // to pretend like they are already loaded. They may not exist on disk.
      if (sourceMap.map.sourcesContent) {
        sourceMap.map.sources.forEach(function(source, i) {
          var contents = sourceMap.map.sourcesContent[i];
          if (contents) {
            var url = supportRelativeURL(sourceMap.url, source);
            fileContentsCache[url] = contents;
          }
        });
      }
    } else {
      sourceMap = sourceMapCache[position.source] = {
        url: null,
        map: null
      };
    }
  }

  // Resolve the source URL relative to the URL of the source map
  if (sourceMap && sourceMap.map) {
    var originalPosition = sourceMap.map.originalPositionFor(position);

    // Only return the original position if a matching line was found. If no
    // matching line is found then we return position instead, which will cause
    // the stack trace to print the path and line for the compiled file. It is
    // better to give a precise location in the compiled file than a vague
    // location in the original file.
    if (originalPosition.source !== null) {
      originalPosition.source = supportRelativeURL(
        sourceMap.url, originalPosition.source);
      return originalPosition;
    }
  }

  return position;
}

// Parses code generated by FormatEvalOrigin(), a function inside V8:
// https://code.google.com/p/v8/source/browse/trunk/src/messages.js
function mapEvalOrigin(origin) {
  // Most eval() calls are in this format
  var match = /^eval at ([^(]+) \((.+):(\d+):(\d+)\)$/.exec(origin);
  if (match) {
    var position = mapSourcePosition({
      source: match[2],
      line: +match[3],
      column: match[4] - 1
    });
    return 'eval at ' + match[1] + ' (' + position.source + ':' +
      position.line + ':' + (position.column + 1) + ')';
  }

  // Parse nested eval() calls using recursion
  match = /^eval at ([^(]+) \((.+)\)$/.exec(origin);
  if (match) {
    return 'eval at ' + match[1] + ' (' + mapEvalOrigin(match[2]) + ')';
  }

  // Make sure we still return useful information if we didn't find anything
  return origin;
}

// This is copied almost verbatim from the V8 source code at
// https://code.google.com/p/v8/source/browse/trunk/src/messages.js. The
// implementation of wrapCallSite() used to just forward to the actual source
// code of CallSite.prototype.toString but unfortunately a new release of V8
// did something to the prototype chain and broke the shim. The only fix I
// could find was copy/paste.
function CallSiteToString() {
  var fileName;
  var fileLocation = "";
  if (this.isNative()) {
    fileLocation = "native";
  } else {
    fileName = this.getScriptNameOrSourceURL();
    if (!fileName && this.isEval()) {
      fileLocation = this.getEvalOrigin();
      fileLocation += ", ";  // Expecting source position to follow.
    }

    if (fileName) {
      fileLocation += fileName;
    } else {
      // Source code does not originate from a file and is not native, but we
      // can still get the source position inside the source string, e.g. in
      // an eval string.
      fileLocation += "<anonymous>";
    }
    var lineNumber = this.getLineNumber();
    if (lineNumber != null) {
      fileLocation += ":" + lineNumber;
      var columnNumber = this.getColumnNumber();
      if (columnNumber) {
        fileLocation += ":" + columnNumber;
      }
    }
  }

  var line = "";
  var functionName = this.getFunctionName();
  var addSuffix = true;
  var isConstructor = this.isConstructor();
  var isMethodCall = !(this.isToplevel() || isConstructor);
  if (isMethodCall) {
    var typeName = this.getTypeName();
    // Fixes shim to be backward compatable with Node v0 to v4
    if (typeName === "[object Object]") {
      typeName = "null";
    }
    var methodName = this.getMethodName();
    if (functionName) {
      if (typeName && functionName.indexOf(typeName) != 0) {
        line += typeName + ".";
      }
      line += functionName;
      if (methodName && functionName.indexOf("." + methodName) != functionName.length - methodName.length - 1) {
        line += " [as " + methodName + "]";
      }
    } else {
      line += typeName + "." + (methodName || "<anonymous>");
    }
  } else if (isConstructor) {
    line += "new " + (functionName || "<anonymous>");
  } else if (functionName) {
    line += functionName;
  } else {
    line += fileLocation;
    addSuffix = false;
  }
  if (addSuffix) {
    line += " (" + fileLocation + ")";
  }
  return line;
}

function cloneCallSite(frame) {
  var object = {};
  Object.getOwnPropertyNames(Object.getPrototypeOf(frame)).forEach(function(name) {
    object[name] = /^(?:is|get)/.test(name) ? function() { return frame[name].call(frame); } : frame[name];
  });
  object.toString = CallSiteToString;
  return object;
}

function wrapCallSite(frame) {
  if(frame.isNative()) {
    return frame;
  }

  // Most call sites will return the source file from getFileName(), but code
  // passed to eval() ending in "//# sourceURL=..." will return the source file
  // from getScriptNameOrSourceURL() instead
  var source = frame.getFileName() || frame.getScriptNameOrSourceURL();
  if (source) {
    var line = frame.getLineNumber();
    var column = frame.getColumnNumber() - 1;

    // Fix position in Node where some (internal) code is prepended.
    // See https://github.com/evanw/node-source-map-support/issues/36
    var headerLength = 62;
    if (line === 1 && column > headerLength && !isInBrowser() && !frame.isEval()) {
      column -= headerLength;
    }

    var position = mapSourcePosition({
      source: source,
      line: line,
      column: column
    });
    frame = cloneCallSite(frame);
    frame.getFileName = function() { return position.source; };
    frame.getLineNumber = function() { return position.line; };
    frame.getColumnNumber = function() { return position.column + 1; };
    frame.getScriptNameOrSourceURL = function() { return position.source; };
    return frame;
  }

  // Code called using eval() needs special handling
  var origin = frame.isEval() && frame.getEvalOrigin();
  if (origin) {
    origin = mapEvalOrigin(origin);
    frame = cloneCallSite(frame);
    frame.getEvalOrigin = function() { return origin; };
    return frame;
  }

  // If we get here then we were unable to change the source position
  return frame;
}

// This function is part of the V8 stack trace API, for more info see:
// http://code.google.com/p/v8/wiki/JavaScriptStackTraceApi
function prepareStackTrace(error, stack) {
  if (emptyCacheBetweenOperations) {
    fileContentsCache = {};
    sourceMapCache = {};
  }

  return error + stack.map(function(frame) {
    return '\n    at ' + wrapCallSite(frame);
  }).join('');
}

// Generate position and snippet of original source with pointer
function getErrorSource(error) {
  var match = /\n    at [^(]+ \((.*):(\d+):(\d+)\)/.exec(error.stack);
  if (match) {
    var source = match[1];
    var line = +match[2];
    var column = +match[3];

    // Support the inline sourceContents inside the source map
    var contents = fileContentsCache[source];

    // Support files on disk
    if (!contents && fs && fs.existsSync(source)) {
      try {
        contents = fs.readFileSync(source, 'utf8');
      } catch (er) {
        contents = '';
      }
    }

    // Format the line from the original source code like node does
    if (contents) {
      var code = contents.split(/(?:\r\n|\r|\n)/)[line - 1];
      if (code) {
        return source + ':' + line + '\n' + code + '\n' +
          new Array(column).join(' ') + '^';
      }
    }
  }
  return null;
}

function printErrorAndExit (error) {
  var source = getErrorSource(error);

  if (source) {
    console.error();
    console.error(source);
  }

  console.error(error.stack);
  process.exit(1);
}

function shimEmitUncaughtException () {
  var origEmit = process.emit;

  process.emit = function (type) {
    if (type === 'uncaughtException') {
      var hasStack = (arguments[1] && arguments[1].stack);
      var hasListeners = (this.listeners(type).length > 0);

      if (hasStack && !hasListeners) {
        return printErrorAndExit(arguments[1]);
      }
    }

    return origEmit.apply(this, arguments);
  };
}

exports.wrapCallSite = wrapCallSite;
exports.getErrorSource = getErrorSource;
exports.mapSourcePosition = mapSourcePosition;
exports.retrieveSourceMap = retrieveSourceMap;

exports.install = function(options) {
  options = options || {};

  if (options.environment) {
    environment = options.environment;
    if (["node", "browser", "auto"].indexOf(environment) === -1) {
      throw new Error("environment " + environment + " was unknown. Available options are {auto, browser, node}")
    }
  }

  // Allow sources to be found by methods other than reading the files
  // directly from disk.
  if (options.retrieveFile) {
    if (options.overrideRetrieveFile) {
      retrieveFileHandlers.length = 0;
    }

    retrieveFileHandlers.unshift(options.retrieveFile);
  }

  // Allow source maps to be found by methods other than reading the files
  // directly from disk.
  if (options.retrieveSourceMap) {
    if (options.overrideRetrieveSourceMap) {
      retrieveMapHandlers.length = 0;
    }

    retrieveMapHandlers.unshift(options.retrieveSourceMap);
  }

  // Support runtime transpilers that include inline source maps
  if (options.hookRequire && !isInBrowser()) {
    var Module;
    try {
      Module = __webpack_require__(31);
    } catch (err) {
      // NOP: Loading in catch block to convert webpack error to warning.
    }
    var $compile = Module.prototype._compile;

    if (!$compile.__sourceMapSupport) {
      Module.prototype._compile = function(content, filename) {
        fileContentsCache[filename] = content;
        sourceMapCache[filename] = undefined;
        return $compile.call(this, content, filename);
      };

      Module.prototype._compile.__sourceMapSupport = true;
    }
  }

  // Configure options
  if (!emptyCacheBetweenOperations) {
    emptyCacheBetweenOperations = 'emptyCacheBetweenOperations' in options ?
      options.emptyCacheBetweenOperations : false;
  }

  // Install the error reformatter
  if (!errorFormatterInstalled) {
    errorFormatterInstalled = true;
    Error.prepareStackTrace = prepareStackTrace;
  }

  if (!uncaughtShimInstalled) {
    var installHandler = 'handleUncaughtExceptions' in options ?
      options.handleUncaughtExceptions : true;

    // Provide the option to not install the uncaught exception handler. This is
    // to support other uncaught exception handlers (in test frameworks, for
    // example). If this handler is not installed and there are no other uncaught
    // exception handlers, uncaught exceptions will be caught by node's built-in
    // exception handler and the process will still be terminated. However, the
    // generated JavaScript code will be shown above the stack trace instead of
    // the original source code.
    if (installHandler && hasGlobalProcessEventEmitter()) {
      uncaughtShimInstalled = true;
      shimEmitUncaughtException();
    }
  }
};


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

/*
 * Copyright 2009-2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE.txt or:
 * http://opensource.org/licenses/BSD-3-Clause
 */
exports.SourceMapGenerator = __webpack_require__(6).SourceMapGenerator;
exports.SourceMapConsumer = __webpack_require__(26).SourceMapConsumer;
exports.SourceNode = __webpack_require__(29).SourceNode;


/***/ }),
/* 24 */
/***/ (function(module, exports) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var intToCharMap = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'.split('');

/**
 * Encode an integer in the range of 0 to 63 to a single base 64 digit.
 */
exports.encode = function (number) {
  if (0 <= number && number < intToCharMap.length) {
    return intToCharMap[number];
  }
  throw new TypeError("Must be between 0 and 63: " + number);
};

/**
 * Decode a single base 64 character code digit to an integer. Returns -1 on
 * failure.
 */
exports.decode = function (charCode) {
  var bigA = 65;     // 'A'
  var bigZ = 90;     // 'Z'

  var littleA = 97;  // 'a'
  var littleZ = 122; // 'z'

  var zero = 48;     // '0'
  var nine = 57;     // '9'

  var plus = 43;     // '+'
  var slash = 47;    // '/'

  var littleOffset = 26;
  var numberOffset = 52;

  // 0 - 25: ABCDEFGHIJKLMNOPQRSTUVWXYZ
  if (bigA <= charCode && charCode <= bigZ) {
    return (charCode - bigA);
  }

  // 26 - 51: abcdefghijklmnopqrstuvwxyz
  if (littleA <= charCode && charCode <= littleZ) {
    return (charCode - littleA + littleOffset);
  }

  // 52 - 61: 0123456789
  if (zero <= charCode && charCode <= nine) {
    return (charCode - zero + numberOffset);
  }

  // 62: +
  if (charCode == plus) {
    return 62;
  }

  // 63: /
  if (charCode == slash) {
    return 63;
  }

  // Invalid base64 digit.
  return -1;
};


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2014 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var util = __webpack_require__(2);

/**
 * Determine whether mappingB is after mappingA with respect to generated
 * position.
 */
function generatedPositionAfter(mappingA, mappingB) {
  // Optimized for most common case
  var lineA = mappingA.generatedLine;
  var lineB = mappingB.generatedLine;
  var columnA = mappingA.generatedColumn;
  var columnB = mappingB.generatedColumn;
  return lineB > lineA || lineB == lineA && columnB >= columnA ||
         util.compareByGeneratedPositionsInflated(mappingA, mappingB) <= 0;
}

/**
 * A data structure to provide a sorted view of accumulated mappings in a
 * performance conscious manner. It trades a neglibable overhead in general
 * case for a large speedup in case of mappings being added in order.
 */
function MappingList() {
  this._array = [];
  this._sorted = true;
  // Serves as infimum
  this._last = {generatedLine: -1, generatedColumn: 0};
}

/**
 * Iterate through internal items. This method takes the same arguments that
 * `Array.prototype.forEach` takes.
 *
 * NOTE: The order of the mappings is NOT guaranteed.
 */
MappingList.prototype.unsortedForEach =
  function MappingList_forEach(aCallback, aThisArg) {
    this._array.forEach(aCallback, aThisArg);
  };

/**
 * Add the given source mapping.
 *
 * @param Object aMapping
 */
MappingList.prototype.add = function MappingList_add(aMapping) {
  if (generatedPositionAfter(this._last, aMapping)) {
    this._last = aMapping;
    this._array.push(aMapping);
  } else {
    this._sorted = false;
    this._array.push(aMapping);
  }
};

/**
 * Returns the flat, sorted array of mappings. The mappings are sorted by
 * generated position.
 *
 * WARNING: This method returns internal data without copying, for
 * performance. The return value must NOT be mutated, and should be treated as
 * an immutable borrow. If you want to take ownership, you must make your own
 * copy.
 */
MappingList.prototype.toArray = function MappingList_toArray() {
  if (!this._sorted) {
    this._array.sort(util.compareByGeneratedPositionsInflated);
    this._sorted = true;
  }
  return this._array;
};

exports.MappingList = MappingList;


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var util = __webpack_require__(2);
var binarySearch = __webpack_require__(27);
var ArraySet = __webpack_require__(8).ArraySet;
var base64VLQ = __webpack_require__(7);
var quickSort = __webpack_require__(28).quickSort;

function SourceMapConsumer(aSourceMap) {
  var sourceMap = aSourceMap;
  if (typeof aSourceMap === 'string') {
    sourceMap = JSON.parse(aSourceMap.replace(/^\)\]\}'/, ''));
  }

  return sourceMap.sections != null
    ? new IndexedSourceMapConsumer(sourceMap)
    : new BasicSourceMapConsumer(sourceMap);
}

SourceMapConsumer.fromSourceMap = function(aSourceMap) {
  return BasicSourceMapConsumer.fromSourceMap(aSourceMap);
}

/**
 * The version of the source mapping spec that we are consuming.
 */
SourceMapConsumer.prototype._version = 3;

// `__generatedMappings` and `__originalMappings` are arrays that hold the
// parsed mapping coordinates from the source map's "mappings" attribute. They
// are lazily instantiated, accessed via the `_generatedMappings` and
// `_originalMappings` getters respectively, and we only parse the mappings
// and create these arrays once queried for a source location. We jump through
// these hoops because there can be many thousands of mappings, and parsing
// them is expensive, so we only want to do it if we must.
//
// Each object in the arrays is of the form:
//
//     {
//       generatedLine: The line number in the generated code,
//       generatedColumn: The column number in the generated code,
//       source: The path to the original source file that generated this
//               chunk of code,
//       originalLine: The line number in the original source that
//                     corresponds to this chunk of generated code,
//       originalColumn: The column number in the original source that
//                       corresponds to this chunk of generated code,
//       name: The name of the original symbol which generated this chunk of
//             code.
//     }
//
// All properties except for `generatedLine` and `generatedColumn` can be
// `null`.
//
// `_generatedMappings` is ordered by the generated positions.
//
// `_originalMappings` is ordered by the original positions.

SourceMapConsumer.prototype.__generatedMappings = null;
Object.defineProperty(SourceMapConsumer.prototype, '_generatedMappings', {
  get: function () {
    if (!this.__generatedMappings) {
      this._parseMappings(this._mappings, this.sourceRoot);
    }

    return this.__generatedMappings;
  }
});

SourceMapConsumer.prototype.__originalMappings = null;
Object.defineProperty(SourceMapConsumer.prototype, '_originalMappings', {
  get: function () {
    if (!this.__originalMappings) {
      this._parseMappings(this._mappings, this.sourceRoot);
    }

    return this.__originalMappings;
  }
});

SourceMapConsumer.prototype._charIsMappingSeparator =
  function SourceMapConsumer_charIsMappingSeparator(aStr, index) {
    var c = aStr.charAt(index);
    return c === ";" || c === ",";
  };

/**
 * Parse the mappings in a string in to a data structure which we can easily
 * query (the ordered arrays in the `this.__generatedMappings` and
 * `this.__originalMappings` properties).
 */
SourceMapConsumer.prototype._parseMappings =
  function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
    throw new Error("Subclasses must implement _parseMappings");
  };

SourceMapConsumer.GENERATED_ORDER = 1;
SourceMapConsumer.ORIGINAL_ORDER = 2;

SourceMapConsumer.GREATEST_LOWER_BOUND = 1;
SourceMapConsumer.LEAST_UPPER_BOUND = 2;

/**
 * Iterate over each mapping between an original source/line/column and a
 * generated line/column in this source map.
 *
 * @param Function aCallback
 *        The function that is called with each mapping.
 * @param Object aContext
 *        Optional. If specified, this object will be the value of `this` every
 *        time that `aCallback` is called.
 * @param aOrder
 *        Either `SourceMapConsumer.GENERATED_ORDER` or
 *        `SourceMapConsumer.ORIGINAL_ORDER`. Specifies whether you want to
 *        iterate over the mappings sorted by the generated file's line/column
 *        order or the original's source/line/column order, respectively. Defaults to
 *        `SourceMapConsumer.GENERATED_ORDER`.
 */
SourceMapConsumer.prototype.eachMapping =
  function SourceMapConsumer_eachMapping(aCallback, aContext, aOrder) {
    var context = aContext || null;
    var order = aOrder || SourceMapConsumer.GENERATED_ORDER;

    var mappings;
    switch (order) {
    case SourceMapConsumer.GENERATED_ORDER:
      mappings = this._generatedMappings;
      break;
    case SourceMapConsumer.ORIGINAL_ORDER:
      mappings = this._originalMappings;
      break;
    default:
      throw new Error("Unknown order of iteration.");
    }

    var sourceRoot = this.sourceRoot;
    mappings.map(function (mapping) {
      var source = mapping.source === null ? null : this._sources.at(mapping.source);
      if (source != null && sourceRoot != null) {
        source = util.join(sourceRoot, source);
      }
      return {
        source: source,
        generatedLine: mapping.generatedLine,
        generatedColumn: mapping.generatedColumn,
        originalLine: mapping.originalLine,
        originalColumn: mapping.originalColumn,
        name: mapping.name === null ? null : this._names.at(mapping.name)
      };
    }, this).forEach(aCallback, context);
  };

/**
 * Returns all generated line and column information for the original source,
 * line, and column provided. If no column is provided, returns all mappings
 * corresponding to a either the line we are searching for or the next
 * closest line that has any mappings. Otherwise, returns all mappings
 * corresponding to the given line and either the column we are searching for
 * or the next closest column that has any offsets.
 *
 * The only argument is an object with the following properties:
 *
 *   - source: The filename of the original source.
 *   - line: The line number in the original source.
 *   - column: Optional. the column number in the original source.
 *
 * and an array of objects is returned, each with the following properties:
 *
 *   - line: The line number in the generated source, or null.
 *   - column: The column number in the generated source, or null.
 */
SourceMapConsumer.prototype.allGeneratedPositionsFor =
  function SourceMapConsumer_allGeneratedPositionsFor(aArgs) {
    var line = util.getArg(aArgs, 'line');

    // When there is no exact match, BasicSourceMapConsumer.prototype._findMapping
    // returns the index of the closest mapping less than the needle. By
    // setting needle.originalColumn to 0, we thus find the last mapping for
    // the given line, provided such a mapping exists.
    var needle = {
      source: util.getArg(aArgs, 'source'),
      originalLine: line,
      originalColumn: util.getArg(aArgs, 'column', 0)
    };

    if (this.sourceRoot != null) {
      needle.source = util.relative(this.sourceRoot, needle.source);
    }
    if (!this._sources.has(needle.source)) {
      return [];
    }
    needle.source = this._sources.indexOf(needle.source);

    var mappings = [];

    var index = this._findMapping(needle,
                                  this._originalMappings,
                                  "originalLine",
                                  "originalColumn",
                                  util.compareByOriginalPositions,
                                  binarySearch.LEAST_UPPER_BOUND);
    if (index >= 0) {
      var mapping = this._originalMappings[index];

      if (aArgs.column === undefined) {
        var originalLine = mapping.originalLine;

        // Iterate until either we run out of mappings, or we run into
        // a mapping for a different line than the one we found. Since
        // mappings are sorted, this is guaranteed to find all mappings for
        // the line we found.
        while (mapping && mapping.originalLine === originalLine) {
          mappings.push({
            line: util.getArg(mapping, 'generatedLine', null),
            column: util.getArg(mapping, 'generatedColumn', null),
            lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
          });

          mapping = this._originalMappings[++index];
        }
      } else {
        var originalColumn = mapping.originalColumn;

        // Iterate until either we run out of mappings, or we run into
        // a mapping for a different line than the one we were searching for.
        // Since mappings are sorted, this is guaranteed to find all mappings for
        // the line we are searching for.
        while (mapping &&
               mapping.originalLine === line &&
               mapping.originalColumn == originalColumn) {
          mappings.push({
            line: util.getArg(mapping, 'generatedLine', null),
            column: util.getArg(mapping, 'generatedColumn', null),
            lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
          });

          mapping = this._originalMappings[++index];
        }
      }
    }

    return mappings;
  };

exports.SourceMapConsumer = SourceMapConsumer;

/**
 * A BasicSourceMapConsumer instance represents a parsed source map which we can
 * query for information about the original file positions by giving it a file
 * position in the generated source.
 *
 * The only parameter is the raw source map (either as a JSON string, or
 * already parsed to an object). According to the spec, source maps have the
 * following attributes:
 *
 *   - version: Which version of the source map spec this map is following.
 *   - sources: An array of URLs to the original source files.
 *   - names: An array of identifiers which can be referrenced by individual mappings.
 *   - sourceRoot: Optional. The URL root from which all sources are relative.
 *   - sourcesContent: Optional. An array of contents of the original source files.
 *   - mappings: A string of base64 VLQs which contain the actual mappings.
 *   - file: Optional. The generated file this source map is associated with.
 *
 * Here is an example source map, taken from the source map spec[0]:
 *
 *     {
 *       version : 3,
 *       file: "out.js",
 *       sourceRoot : "",
 *       sources: ["foo.js", "bar.js"],
 *       names: ["src", "maps", "are", "fun"],
 *       mappings: "AA,AB;;ABCDE;"
 *     }
 *
 * [0]: https://docs.google.com/document/d/1U1RGAehQwRypUTovF1KRlpiOFze0b-_2gc6fAH0KY0k/edit?pli=1#
 */
function BasicSourceMapConsumer(aSourceMap) {
  var sourceMap = aSourceMap;
  if (typeof aSourceMap === 'string') {
    sourceMap = JSON.parse(aSourceMap.replace(/^\)\]\}'/, ''));
  }

  var version = util.getArg(sourceMap, 'version');
  var sources = util.getArg(sourceMap, 'sources');
  // Sass 3.3 leaves out the 'names' array, so we deviate from the spec (which
  // requires the array) to play nice here.
  var names = util.getArg(sourceMap, 'names', []);
  var sourceRoot = util.getArg(sourceMap, 'sourceRoot', null);
  var sourcesContent = util.getArg(sourceMap, 'sourcesContent', null);
  var mappings = util.getArg(sourceMap, 'mappings');
  var file = util.getArg(sourceMap, 'file', null);

  // Once again, Sass deviates from the spec and supplies the version as a
  // string rather than a number, so we use loose equality checking here.
  if (version != this._version) {
    throw new Error('Unsupported version: ' + version);
  }

  sources = sources
    .map(String)
    // Some source maps produce relative source paths like "./foo.js" instead of
    // "foo.js".  Normalize these first so that future comparisons will succeed.
    // See bugzil.la/1090768.
    .map(util.normalize)
    // Always ensure that absolute sources are internally stored relative to
    // the source root, if the source root is absolute. Not doing this would
    // be particularly problematic when the source root is a prefix of the
    // source (valid, but why??). See github issue #199 and bugzil.la/1188982.
    .map(function (source) {
      return sourceRoot && util.isAbsolute(sourceRoot) && util.isAbsolute(source)
        ? util.relative(sourceRoot, source)
        : source;
    });

  // Pass `true` below to allow duplicate names and sources. While source maps
  // are intended to be compressed and deduplicated, the TypeScript compiler
  // sometimes generates source maps with duplicates in them. See Github issue
  // #72 and bugzil.la/889492.
  this._names = ArraySet.fromArray(names.map(String), true);
  this._sources = ArraySet.fromArray(sources, true);

  this.sourceRoot = sourceRoot;
  this.sourcesContent = sourcesContent;
  this._mappings = mappings;
  this.file = file;
}

BasicSourceMapConsumer.prototype = Object.create(SourceMapConsumer.prototype);
BasicSourceMapConsumer.prototype.consumer = SourceMapConsumer;

/**
 * Create a BasicSourceMapConsumer from a SourceMapGenerator.
 *
 * @param SourceMapGenerator aSourceMap
 *        The source map that will be consumed.
 * @returns BasicSourceMapConsumer
 */
BasicSourceMapConsumer.fromSourceMap =
  function SourceMapConsumer_fromSourceMap(aSourceMap) {
    var smc = Object.create(BasicSourceMapConsumer.prototype);

    var names = smc._names = ArraySet.fromArray(aSourceMap._names.toArray(), true);
    var sources = smc._sources = ArraySet.fromArray(aSourceMap._sources.toArray(), true);
    smc.sourceRoot = aSourceMap._sourceRoot;
    smc.sourcesContent = aSourceMap._generateSourcesContent(smc._sources.toArray(),
                                                            smc.sourceRoot);
    smc.file = aSourceMap._file;

    // Because we are modifying the entries (by converting string sources and
    // names to indices into the sources and names ArraySets), we have to make
    // a copy of the entry or else bad things happen. Shared mutable state
    // strikes again! See github issue #191.

    var generatedMappings = aSourceMap._mappings.toArray().slice();
    var destGeneratedMappings = smc.__generatedMappings = [];
    var destOriginalMappings = smc.__originalMappings = [];

    for (var i = 0, length = generatedMappings.length; i < length; i++) {
      var srcMapping = generatedMappings[i];
      var destMapping = new Mapping;
      destMapping.generatedLine = srcMapping.generatedLine;
      destMapping.generatedColumn = srcMapping.generatedColumn;

      if (srcMapping.source) {
        destMapping.source = sources.indexOf(srcMapping.source);
        destMapping.originalLine = srcMapping.originalLine;
        destMapping.originalColumn = srcMapping.originalColumn;

        if (srcMapping.name) {
          destMapping.name = names.indexOf(srcMapping.name);
        }

        destOriginalMappings.push(destMapping);
      }

      destGeneratedMappings.push(destMapping);
    }

    quickSort(smc.__originalMappings, util.compareByOriginalPositions);

    return smc;
  };

/**
 * The version of the source mapping spec that we are consuming.
 */
BasicSourceMapConsumer.prototype._version = 3;

/**
 * The list of original sources.
 */
Object.defineProperty(BasicSourceMapConsumer.prototype, 'sources', {
  get: function () {
    return this._sources.toArray().map(function (s) {
      return this.sourceRoot != null ? util.join(this.sourceRoot, s) : s;
    }, this);
  }
});

/**
 * Provide the JIT with a nice shape / hidden class.
 */
function Mapping() {
  this.generatedLine = 0;
  this.generatedColumn = 0;
  this.source = null;
  this.originalLine = null;
  this.originalColumn = null;
  this.name = null;
}

/**
 * Parse the mappings in a string in to a data structure which we can easily
 * query (the ordered arrays in the `this.__generatedMappings` and
 * `this.__originalMappings` properties).
 */
BasicSourceMapConsumer.prototype._parseMappings =
  function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
    var generatedLine = 1;
    var previousGeneratedColumn = 0;
    var previousOriginalLine = 0;
    var previousOriginalColumn = 0;
    var previousSource = 0;
    var previousName = 0;
    var length = aStr.length;
    var index = 0;
    var cachedSegments = {};
    var temp = {};
    var originalMappings = [];
    var generatedMappings = [];
    var mapping, str, segment, end, value;

    while (index < length) {
      if (aStr.charAt(index) === ';') {
        generatedLine++;
        index++;
        previousGeneratedColumn = 0;
      }
      else if (aStr.charAt(index) === ',') {
        index++;
      }
      else {
        mapping = new Mapping();
        mapping.generatedLine = generatedLine;

        // Because each offset is encoded relative to the previous one,
        // many segments often have the same encoding. We can exploit this
        // fact by caching the parsed variable length fields of each segment,
        // allowing us to avoid a second parse if we encounter the same
        // segment again.
        for (end = index; end < length; end++) {
          if (this._charIsMappingSeparator(aStr, end)) {
            break;
          }
        }
        str = aStr.slice(index, end);

        segment = cachedSegments[str];
        if (segment) {
          index += str.length;
        } else {
          segment = [];
          while (index < end) {
            base64VLQ.decode(aStr, index, temp);
            value = temp.value;
            index = temp.rest;
            segment.push(value);
          }

          if (segment.length === 2) {
            throw new Error('Found a source, but no line and column');
          }

          if (segment.length === 3) {
            throw new Error('Found a source and line, but no column');
          }

          cachedSegments[str] = segment;
        }

        // Generated column.
        mapping.generatedColumn = previousGeneratedColumn + segment[0];
        previousGeneratedColumn = mapping.generatedColumn;

        if (segment.length > 1) {
          // Original source.
          mapping.source = previousSource + segment[1];
          previousSource += segment[1];

          // Original line.
          mapping.originalLine = previousOriginalLine + segment[2];
          previousOriginalLine = mapping.originalLine;
          // Lines are stored 0-based
          mapping.originalLine += 1;

          // Original column.
          mapping.originalColumn = previousOriginalColumn + segment[3];
          previousOriginalColumn = mapping.originalColumn;

          if (segment.length > 4) {
            // Original name.
            mapping.name = previousName + segment[4];
            previousName += segment[4];
          }
        }

        generatedMappings.push(mapping);
        if (typeof mapping.originalLine === 'number') {
          originalMappings.push(mapping);
        }
      }
    }

    quickSort(generatedMappings, util.compareByGeneratedPositionsDeflated);
    this.__generatedMappings = generatedMappings;

    quickSort(originalMappings, util.compareByOriginalPositions);
    this.__originalMappings = originalMappings;
  };

/**
 * Find the mapping that best matches the hypothetical "needle" mapping that
 * we are searching for in the given "haystack" of mappings.
 */
BasicSourceMapConsumer.prototype._findMapping =
  function SourceMapConsumer_findMapping(aNeedle, aMappings, aLineName,
                                         aColumnName, aComparator, aBias) {
    // To return the position we are searching for, we must first find the
    // mapping for the given position and then return the opposite position it
    // points to. Because the mappings are sorted, we can use binary search to
    // find the best mapping.

    if (aNeedle[aLineName] <= 0) {
      throw new TypeError('Line must be greater than or equal to 1, got '
                          + aNeedle[aLineName]);
    }
    if (aNeedle[aColumnName] < 0) {
      throw new TypeError('Column must be greater than or equal to 0, got '
                          + aNeedle[aColumnName]);
    }

    return binarySearch.search(aNeedle, aMappings, aComparator, aBias);
  };

/**
 * Compute the last column for each generated mapping. The last column is
 * inclusive.
 */
BasicSourceMapConsumer.prototype.computeColumnSpans =
  function SourceMapConsumer_computeColumnSpans() {
    for (var index = 0; index < this._generatedMappings.length; ++index) {
      var mapping = this._generatedMappings[index];

      // Mappings do not contain a field for the last generated columnt. We
      // can come up with an optimistic estimate, however, by assuming that
      // mappings are contiguous (i.e. given two consecutive mappings, the
      // first mapping ends where the second one starts).
      if (index + 1 < this._generatedMappings.length) {
        var nextMapping = this._generatedMappings[index + 1];

        if (mapping.generatedLine === nextMapping.generatedLine) {
          mapping.lastGeneratedColumn = nextMapping.generatedColumn - 1;
          continue;
        }
      }

      // The last mapping for each line spans the entire line.
      mapping.lastGeneratedColumn = Infinity;
    }
  };

/**
 * Returns the original source, line, and column information for the generated
 * source's line and column positions provided. The only argument is an object
 * with the following properties:
 *
 *   - line: The line number in the generated source.
 *   - column: The column number in the generated source.
 *   - bias: Either 'SourceMapConsumer.GREATEST_LOWER_BOUND' or
 *     'SourceMapConsumer.LEAST_UPPER_BOUND'. Specifies whether to return the
 *     closest element that is smaller than or greater than the one we are
 *     searching for, respectively, if the exact element cannot be found.
 *     Defaults to 'SourceMapConsumer.GREATEST_LOWER_BOUND'.
 *
 * and an object is returned with the following properties:
 *
 *   - source: The original source file, or null.
 *   - line: The line number in the original source, or null.
 *   - column: The column number in the original source, or null.
 *   - name: The original identifier, or null.
 */
BasicSourceMapConsumer.prototype.originalPositionFor =
  function SourceMapConsumer_originalPositionFor(aArgs) {
    var needle = {
      generatedLine: util.getArg(aArgs, 'line'),
      generatedColumn: util.getArg(aArgs, 'column')
    };

    var index = this._findMapping(
      needle,
      this._generatedMappings,
      "generatedLine",
      "generatedColumn",
      util.compareByGeneratedPositionsDeflated,
      util.getArg(aArgs, 'bias', SourceMapConsumer.GREATEST_LOWER_BOUND)
    );

    if (index >= 0) {
      var mapping = this._generatedMappings[index];

      if (mapping.generatedLine === needle.generatedLine) {
        var source = util.getArg(mapping, 'source', null);
        if (source !== null) {
          source = this._sources.at(source);
          if (this.sourceRoot != null) {
            source = util.join(this.sourceRoot, source);
          }
        }
        var name = util.getArg(mapping, 'name', null);
        if (name !== null) {
          name = this._names.at(name);
        }
        return {
          source: source,
          line: util.getArg(mapping, 'originalLine', null),
          column: util.getArg(mapping, 'originalColumn', null),
          name: name
        };
      }
    }

    return {
      source: null,
      line: null,
      column: null,
      name: null
    };
  };

/**
 * Return true if we have the source content for every source in the source
 * map, false otherwise.
 */
BasicSourceMapConsumer.prototype.hasContentsOfAllSources =
  function BasicSourceMapConsumer_hasContentsOfAllSources() {
    if (!this.sourcesContent) {
      return false;
    }
    return this.sourcesContent.length >= this._sources.size() &&
      !this.sourcesContent.some(function (sc) { return sc == null; });
  };

/**
 * Returns the original source content. The only argument is the url of the
 * original source file. Returns null if no original source content is
 * available.
 */
BasicSourceMapConsumer.prototype.sourceContentFor =
  function SourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
    if (!this.sourcesContent) {
      return null;
    }

    if (this.sourceRoot != null) {
      aSource = util.relative(this.sourceRoot, aSource);
    }

    if (this._sources.has(aSource)) {
      return this.sourcesContent[this._sources.indexOf(aSource)];
    }

    var url;
    if (this.sourceRoot != null
        && (url = util.urlParse(this.sourceRoot))) {
      // XXX: file:// URIs and absolute paths lead to unexpected behavior for
      // many users. We can help them out when they expect file:// URIs to
      // behave like it would if they were running a local HTTP server. See
      // https://bugzilla.mozilla.org/show_bug.cgi?id=885597.
      var fileUriAbsPath = aSource.replace(/^file:\/\//, "");
      if (url.scheme == "file"
          && this._sources.has(fileUriAbsPath)) {
        return this.sourcesContent[this._sources.indexOf(fileUriAbsPath)]
      }

      if ((!url.path || url.path == "/")
          && this._sources.has("/" + aSource)) {
        return this.sourcesContent[this._sources.indexOf("/" + aSource)];
      }
    }

    // This function is used recursively from
    // IndexedSourceMapConsumer.prototype.sourceContentFor. In that case, we
    // don't want to throw if we can't find the source - we just want to
    // return null, so we provide a flag to exit gracefully.
    if (nullOnMissing) {
      return null;
    }
    else {
      throw new Error('"' + aSource + '" is not in the SourceMap.');
    }
  };

/**
 * Returns the generated line and column information for the original source,
 * line, and column positions provided. The only argument is an object with
 * the following properties:
 *
 *   - source: The filename of the original source.
 *   - line: The line number in the original source.
 *   - column: The column number in the original source.
 *   - bias: Either 'SourceMapConsumer.GREATEST_LOWER_BOUND' or
 *     'SourceMapConsumer.LEAST_UPPER_BOUND'. Specifies whether to return the
 *     closest element that is smaller than or greater than the one we are
 *     searching for, respectively, if the exact element cannot be found.
 *     Defaults to 'SourceMapConsumer.GREATEST_LOWER_BOUND'.
 *
 * and an object is returned with the following properties:
 *
 *   - line: The line number in the generated source, or null.
 *   - column: The column number in the generated source, or null.
 */
BasicSourceMapConsumer.prototype.generatedPositionFor =
  function SourceMapConsumer_generatedPositionFor(aArgs) {
    var source = util.getArg(aArgs, 'source');
    if (this.sourceRoot != null) {
      source = util.relative(this.sourceRoot, source);
    }
    if (!this._sources.has(source)) {
      return {
        line: null,
        column: null,
        lastColumn: null
      };
    }
    source = this._sources.indexOf(source);

    var needle = {
      source: source,
      originalLine: util.getArg(aArgs, 'line'),
      originalColumn: util.getArg(aArgs, 'column')
    };

    var index = this._findMapping(
      needle,
      this._originalMappings,
      "originalLine",
      "originalColumn",
      util.compareByOriginalPositions,
      util.getArg(aArgs, 'bias', SourceMapConsumer.GREATEST_LOWER_BOUND)
    );

    if (index >= 0) {
      var mapping = this._originalMappings[index];

      if (mapping.source === needle.source) {
        return {
          line: util.getArg(mapping, 'generatedLine', null),
          column: util.getArg(mapping, 'generatedColumn', null),
          lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
        };
      }
    }

    return {
      line: null,
      column: null,
      lastColumn: null
    };
  };

exports.BasicSourceMapConsumer = BasicSourceMapConsumer;

/**
 * An IndexedSourceMapConsumer instance represents a parsed source map which
 * we can query for information. It differs from BasicSourceMapConsumer in
 * that it takes "indexed" source maps (i.e. ones with a "sections" field) as
 * input.
 *
 * The only parameter is a raw source map (either as a JSON string, or already
 * parsed to an object). According to the spec for indexed source maps, they
 * have the following attributes:
 *
 *   - version: Which version of the source map spec this map is following.
 *   - file: Optional. The generated file this source map is associated with.
 *   - sections: A list of section definitions.
 *
 * Each value under the "sections" field has two fields:
 *   - offset: The offset into the original specified at which this section
 *       begins to apply, defined as an object with a "line" and "column"
 *       field.
 *   - map: A source map definition. This source map could also be indexed,
 *       but doesn't have to be.
 *
 * Instead of the "map" field, it's also possible to have a "url" field
 * specifying a URL to retrieve a source map from, but that's currently
 * unsupported.
 *
 * Here's an example source map, taken from the source map spec[0], but
 * modified to omit a section which uses the "url" field.
 *
 *  {
 *    version : 3,
 *    file: "app.js",
 *    sections: [{
 *      offset: {line:100, column:10},
 *      map: {
 *        version : 3,
 *        file: "section.js",
 *        sources: ["foo.js", "bar.js"],
 *        names: ["src", "maps", "are", "fun"],
 *        mappings: "AAAA,E;;ABCDE;"
 *      }
 *    }],
 *  }
 *
 * [0]: https://docs.google.com/document/d/1U1RGAehQwRypUTovF1KRlpiOFze0b-_2gc6fAH0KY0k/edit#heading=h.535es3xeprgt
 */
function IndexedSourceMapConsumer(aSourceMap) {
  var sourceMap = aSourceMap;
  if (typeof aSourceMap === 'string') {
    sourceMap = JSON.parse(aSourceMap.replace(/^\)\]\}'/, ''));
  }

  var version = util.getArg(sourceMap, 'version');
  var sections = util.getArg(sourceMap, 'sections');

  if (version != this._version) {
    throw new Error('Unsupported version: ' + version);
  }

  this._sources = new ArraySet();
  this._names = new ArraySet();

  var lastOffset = {
    line: -1,
    column: 0
  };
  this._sections = sections.map(function (s) {
    if (s.url) {
      // The url field will require support for asynchronicity.
      // See https://github.com/mozilla/source-map/issues/16
      throw new Error('Support for url field in sections not implemented.');
    }
    var offset = util.getArg(s, 'offset');
    var offsetLine = util.getArg(offset, 'line');
    var offsetColumn = util.getArg(offset, 'column');

    if (offsetLine < lastOffset.line ||
        (offsetLine === lastOffset.line && offsetColumn < lastOffset.column)) {
      throw new Error('Section offsets must be ordered and non-overlapping.');
    }
    lastOffset = offset;

    return {
      generatedOffset: {
        // The offset fields are 0-based, but we use 1-based indices when
        // encoding/decoding from VLQ.
        generatedLine: offsetLine + 1,
        generatedColumn: offsetColumn + 1
      },
      consumer: new SourceMapConsumer(util.getArg(s, 'map'))
    }
  });
}

IndexedSourceMapConsumer.prototype = Object.create(SourceMapConsumer.prototype);
IndexedSourceMapConsumer.prototype.constructor = SourceMapConsumer;

/**
 * The version of the source mapping spec that we are consuming.
 */
IndexedSourceMapConsumer.prototype._version = 3;

/**
 * The list of original sources.
 */
Object.defineProperty(IndexedSourceMapConsumer.prototype, 'sources', {
  get: function () {
    var sources = [];
    for (var i = 0; i < this._sections.length; i++) {
      for (var j = 0; j < this._sections[i].consumer.sources.length; j++) {
        sources.push(this._sections[i].consumer.sources[j]);
      }
    }
    return sources;
  }
});

/**
 * Returns the original source, line, and column information for the generated
 * source's line and column positions provided. The only argument is an object
 * with the following properties:
 *
 *   - line: The line number in the generated source.
 *   - column: The column number in the generated source.
 *
 * and an object is returned with the following properties:
 *
 *   - source: The original source file, or null.
 *   - line: The line number in the original source, or null.
 *   - column: The column number in the original source, or null.
 *   - name: The original identifier, or null.
 */
IndexedSourceMapConsumer.prototype.originalPositionFor =
  function IndexedSourceMapConsumer_originalPositionFor(aArgs) {
    var needle = {
      generatedLine: util.getArg(aArgs, 'line'),
      generatedColumn: util.getArg(aArgs, 'column')
    };

    // Find the section containing the generated position we're trying to map
    // to an original position.
    var sectionIndex = binarySearch.search(needle, this._sections,
      function(needle, section) {
        var cmp = needle.generatedLine - section.generatedOffset.generatedLine;
        if (cmp) {
          return cmp;
        }

        return (needle.generatedColumn -
                section.generatedOffset.generatedColumn);
      });
    var section = this._sections[sectionIndex];

    if (!section) {
      return {
        source: null,
        line: null,
        column: null,
        name: null
      };
    }

    return section.consumer.originalPositionFor({
      line: needle.generatedLine -
        (section.generatedOffset.generatedLine - 1),
      column: needle.generatedColumn -
        (section.generatedOffset.generatedLine === needle.generatedLine
         ? section.generatedOffset.generatedColumn - 1
         : 0),
      bias: aArgs.bias
    });
  };

/**
 * Return true if we have the source content for every source in the source
 * map, false otherwise.
 */
IndexedSourceMapConsumer.prototype.hasContentsOfAllSources =
  function IndexedSourceMapConsumer_hasContentsOfAllSources() {
    return this._sections.every(function (s) {
      return s.consumer.hasContentsOfAllSources();
    });
  };

/**
 * Returns the original source content. The only argument is the url of the
 * original source file. Returns null if no original source content is
 * available.
 */
IndexedSourceMapConsumer.prototype.sourceContentFor =
  function IndexedSourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
    for (var i = 0; i < this._sections.length; i++) {
      var section = this._sections[i];

      var content = section.consumer.sourceContentFor(aSource, true);
      if (content) {
        return content;
      }
    }
    if (nullOnMissing) {
      return null;
    }
    else {
      throw new Error('"' + aSource + '" is not in the SourceMap.');
    }
  };

/**
 * Returns the generated line and column information for the original source,
 * line, and column positions provided. The only argument is an object with
 * the following properties:
 *
 *   - source: The filename of the original source.
 *   - line: The line number in the original source.
 *   - column: The column number in the original source.
 *
 * and an object is returned with the following properties:
 *
 *   - line: The line number in the generated source, or null.
 *   - column: The column number in the generated source, or null.
 */
IndexedSourceMapConsumer.prototype.generatedPositionFor =
  function IndexedSourceMapConsumer_generatedPositionFor(aArgs) {
    for (var i = 0; i < this._sections.length; i++) {
      var section = this._sections[i];

      // Only consider this section if the requested source is in the list of
      // sources of the consumer.
      if (section.consumer.sources.indexOf(util.getArg(aArgs, 'source')) === -1) {
        continue;
      }
      var generatedPosition = section.consumer.generatedPositionFor(aArgs);
      if (generatedPosition) {
        var ret = {
          line: generatedPosition.line +
            (section.generatedOffset.generatedLine - 1),
          column: generatedPosition.column +
            (section.generatedOffset.generatedLine === generatedPosition.line
             ? section.generatedOffset.generatedColumn - 1
             : 0)
        };
        return ret;
      }
    }

    return {
      line: null,
      column: null
    };
  };

/**
 * Parse the mappings in a string in to a data structure which we can easily
 * query (the ordered arrays in the `this.__generatedMappings` and
 * `this.__originalMappings` properties).
 */
IndexedSourceMapConsumer.prototype._parseMappings =
  function IndexedSourceMapConsumer_parseMappings(aStr, aSourceRoot) {
    this.__generatedMappings = [];
    this.__originalMappings = [];
    for (var i = 0; i < this._sections.length; i++) {
      var section = this._sections[i];
      var sectionMappings = section.consumer._generatedMappings;
      for (var j = 0; j < sectionMappings.length; j++) {
        var mapping = sectionMappings[j];

        var source = section.consumer._sources.at(mapping.source);
        if (section.consumer.sourceRoot !== null) {
          source = util.join(section.consumer.sourceRoot, source);
        }
        this._sources.add(source);
        source = this._sources.indexOf(source);

        var name = section.consumer._names.at(mapping.name);
        this._names.add(name);
        name = this._names.indexOf(name);

        // The mappings coming from the consumer for the section have
        // generated positions relative to the start of the section, so we
        // need to offset them to be relative to the start of the concatenated
        // generated file.
        var adjustedMapping = {
          source: source,
          generatedLine: mapping.generatedLine +
            (section.generatedOffset.generatedLine - 1),
          generatedColumn: mapping.generatedColumn +
            (section.generatedOffset.generatedLine === mapping.generatedLine
            ? section.generatedOffset.generatedColumn - 1
            : 0),
          originalLine: mapping.originalLine,
          originalColumn: mapping.originalColumn,
          name: name
        };

        this.__generatedMappings.push(adjustedMapping);
        if (typeof adjustedMapping.originalLine === 'number') {
          this.__originalMappings.push(adjustedMapping);
        }
      }
    }

    quickSort(this.__generatedMappings, util.compareByGeneratedPositionsDeflated);
    quickSort(this.__originalMappings, util.compareByOriginalPositions);
  };

exports.IndexedSourceMapConsumer = IndexedSourceMapConsumer;


/***/ }),
/* 27 */
/***/ (function(module, exports) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

exports.GREATEST_LOWER_BOUND = 1;
exports.LEAST_UPPER_BOUND = 2;

/**
 * Recursive implementation of binary search.
 *
 * @param aLow Indices here and lower do not contain the needle.
 * @param aHigh Indices here and higher do not contain the needle.
 * @param aNeedle The element being searched for.
 * @param aHaystack The non-empty array being searched.
 * @param aCompare Function which takes two elements and returns -1, 0, or 1.
 * @param aBias Either 'binarySearch.GREATEST_LOWER_BOUND' or
 *     'binarySearch.LEAST_UPPER_BOUND'. Specifies whether to return the
 *     closest element that is smaller than or greater than the one we are
 *     searching for, respectively, if the exact element cannot be found.
 */
function recursiveSearch(aLow, aHigh, aNeedle, aHaystack, aCompare, aBias) {
  // This function terminates when one of the following is true:
  //
  //   1. We find the exact element we are looking for.
  //
  //   2. We did not find the exact element, but we can return the index of
  //      the next-closest element.
  //
  //   3. We did not find the exact element, and there is no next-closest
  //      element than the one we are searching for, so we return -1.
  var mid = Math.floor((aHigh - aLow) / 2) + aLow;
  var cmp = aCompare(aNeedle, aHaystack[mid], true);
  if (cmp === 0) {
    // Found the element we are looking for.
    return mid;
  }
  else if (cmp > 0) {
    // Our needle is greater than aHaystack[mid].
    if (aHigh - mid > 1) {
      // The element is in the upper half.
      return recursiveSearch(mid, aHigh, aNeedle, aHaystack, aCompare, aBias);
    }

    // The exact needle element was not found in this haystack. Determine if
    // we are in termination case (3) or (2) and return the appropriate thing.
    if (aBias == exports.LEAST_UPPER_BOUND) {
      return aHigh < aHaystack.length ? aHigh : -1;
    } else {
      return mid;
    }
  }
  else {
    // Our needle is less than aHaystack[mid].
    if (mid - aLow > 1) {
      // The element is in the lower half.
      return recursiveSearch(aLow, mid, aNeedle, aHaystack, aCompare, aBias);
    }

    // we are in termination case (3) or (2) and return the appropriate thing.
    if (aBias == exports.LEAST_UPPER_BOUND) {
      return mid;
    } else {
      return aLow < 0 ? -1 : aLow;
    }
  }
}

/**
 * This is an implementation of binary search which will always try and return
 * the index of the closest element if there is no exact hit. This is because
 * mappings between original and generated line/col pairs are single points,
 * and there is an implicit region between each of them, so a miss just means
 * that you aren't on the very start of a region.
 *
 * @param aNeedle The element you are looking for.
 * @param aHaystack The array that is being searched.
 * @param aCompare A function which takes the needle and an element in the
 *     array and returns -1, 0, or 1 depending on whether the needle is less
 *     than, equal to, or greater than the element, respectively.
 * @param aBias Either 'binarySearch.GREATEST_LOWER_BOUND' or
 *     'binarySearch.LEAST_UPPER_BOUND'. Specifies whether to return the
 *     closest element that is smaller than or greater than the one we are
 *     searching for, respectively, if the exact element cannot be found.
 *     Defaults to 'binarySearch.GREATEST_LOWER_BOUND'.
 */
exports.search = function search(aNeedle, aHaystack, aCompare, aBias) {
  if (aHaystack.length === 0) {
    return -1;
  }

  var index = recursiveSearch(-1, aHaystack.length, aNeedle, aHaystack,
                              aCompare, aBias || exports.GREATEST_LOWER_BOUND);
  if (index < 0) {
    return -1;
  }

  // We have found either the exact element, or the next-closest element than
  // the one we are searching for. However, there may be more than one such
  // element. Make sure we always return the smallest of these.
  while (index - 1 >= 0) {
    if (aCompare(aHaystack[index], aHaystack[index - 1], true) !== 0) {
      break;
    }
    --index;
  }

  return index;
};


/***/ }),
/* 28 */
/***/ (function(module, exports) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

// It turns out that some (most?) JavaScript engines don't self-host
// `Array.prototype.sort`. This makes sense because C++ will likely remain
// faster than JS when doing raw CPU-intensive sorting. However, when using a
// custom comparator function, calling back and forth between the VM's C++ and
// JIT'd JS is rather slow *and* loses JIT type information, resulting in
// worse generated code for the comparator function than would be optimal. In
// fact, when sorting with a comparator, these costs outweigh the benefits of
// sorting in C++. By using our own JS-implemented Quick Sort (below), we get
// a ~3500ms mean speed-up in `bench/bench.html`.

/**
 * Swap the elements indexed by `x` and `y` in the array `ary`.
 *
 * @param {Array} ary
 *        The array.
 * @param {Number} x
 *        The index of the first item.
 * @param {Number} y
 *        The index of the second item.
 */
function swap(ary, x, y) {
  var temp = ary[x];
  ary[x] = ary[y];
  ary[y] = temp;
}

/**
 * Returns a random integer within the range `low .. high` inclusive.
 *
 * @param {Number} low
 *        The lower bound on the range.
 * @param {Number} high
 *        The upper bound on the range.
 */
function randomIntInRange(low, high) {
  return Math.round(low + (Math.random() * (high - low)));
}

/**
 * The Quick Sort algorithm.
 *
 * @param {Array} ary
 *        An array to sort.
 * @param {function} comparator
 *        Function to use to compare two items.
 * @param {Number} p
 *        Start index of the array
 * @param {Number} r
 *        End index of the array
 */
function doQuickSort(ary, comparator, p, r) {
  // If our lower bound is less than our upper bound, we (1) partition the
  // array into two pieces and (2) recurse on each half. If it is not, this is
  // the empty array and our base case.

  if (p < r) {
    // (1) Partitioning.
    //
    // The partitioning chooses a pivot between `p` and `r` and moves all
    // elements that are less than or equal to the pivot to the before it, and
    // all the elements that are greater than it after it. The effect is that
    // once partition is done, the pivot is in the exact place it will be when
    // the array is put in sorted order, and it will not need to be moved
    // again. This runs in O(n) time.

    // Always choose a random pivot so that an input array which is reverse
    // sorted does not cause O(n^2) running time.
    var pivotIndex = randomIntInRange(p, r);
    var i = p - 1;

    swap(ary, pivotIndex, r);
    var pivot = ary[r];

    // Immediately after `j` is incremented in this loop, the following hold
    // true:
    //
    //   * Every element in `ary[p .. i]` is less than or equal to the pivot.
    //
    //   * Every element in `ary[i+1 .. j-1]` is greater than the pivot.
    for (var j = p; j < r; j++) {
      if (comparator(ary[j], pivot) <= 0) {
        i += 1;
        swap(ary, i, j);
      }
    }

    swap(ary, i + 1, j);
    var q = i + 1;

    // (2) Recurse on each half.

    doQuickSort(ary, comparator, p, q - 1);
    doQuickSort(ary, comparator, q + 1, r);
  }
}

/**
 * Sort the given array in-place with the given comparator function.
 *
 * @param {Array} ary
 *        An array to sort.
 * @param {function} comparator
 *        Function to use to compare two items.
 */
exports.quickSort = function (ary, comparator) {
  doQuickSort(ary, comparator, 0, ary.length - 1);
};


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

/* -*- Mode: js; js-indent-level: 2; -*- */
/*
 * Copyright 2011 Mozilla Foundation and contributors
 * Licensed under the New BSD license. See LICENSE or:
 * http://opensource.org/licenses/BSD-3-Clause
 */

var SourceMapGenerator = __webpack_require__(6).SourceMapGenerator;
var util = __webpack_require__(2);

// Matches a Windows-style `\r\n` newline or a `\n` newline used by all other
// operating systems these days (capturing the result).
var REGEX_NEWLINE = /(\r?\n)/;

// Newline character code for charCodeAt() comparisons
var NEWLINE_CODE = 10;

// Private symbol for identifying `SourceNode`s when multiple versions of
// the source-map library are loaded. This MUST NOT CHANGE across
// versions!
var isSourceNode = "$$$isSourceNode$$$";

/**
 * SourceNodes provide a way to abstract over interpolating/concatenating
 * snippets of generated JavaScript source code while maintaining the line and
 * column information associated with the original source code.
 *
 * @param aLine The original line number.
 * @param aColumn The original column number.
 * @param aSource The original source's filename.
 * @param aChunks Optional. An array of strings which are snippets of
 *        generated JS, or other SourceNodes.
 * @param aName The original identifier.
 */
function SourceNode(aLine, aColumn, aSource, aChunks, aName) {
  this.children = [];
  this.sourceContents = {};
  this.line = aLine == null ? null : aLine;
  this.column = aColumn == null ? null : aColumn;
  this.source = aSource == null ? null : aSource;
  this.name = aName == null ? null : aName;
  this[isSourceNode] = true;
  if (aChunks != null) this.add(aChunks);
}

/**
 * Creates a SourceNode from generated code and a SourceMapConsumer.
 *
 * @param aGeneratedCode The generated code
 * @param aSourceMapConsumer The SourceMap for the generated code
 * @param aRelativePath Optional. The path that relative sources in the
 *        SourceMapConsumer should be relative to.
 */
SourceNode.fromStringWithSourceMap =
  function SourceNode_fromStringWithSourceMap(aGeneratedCode, aSourceMapConsumer, aRelativePath) {
    // The SourceNode we want to fill with the generated code
    // and the SourceMap
    var node = new SourceNode();

    // All even indices of this array are one line of the generated code,
    // while all odd indices are the newlines between two adjacent lines
    // (since `REGEX_NEWLINE` captures its match).
    // Processed fragments are accessed by calling `shiftNextLine`.
    var remainingLines = aGeneratedCode.split(REGEX_NEWLINE);
    var remainingLinesIndex = 0;
    var shiftNextLine = function() {
      var lineContents = getNextLine();
      // The last line of a file might not have a newline.
      var newLine = getNextLine() || "";
      return lineContents + newLine;

      function getNextLine() {
        return remainingLinesIndex < remainingLines.length ?
            remainingLines[remainingLinesIndex++] : undefined;
      }
    };

    // We need to remember the position of "remainingLines"
    var lastGeneratedLine = 1, lastGeneratedColumn = 0;

    // The generate SourceNodes we need a code range.
    // To extract it current and last mapping is used.
    // Here we store the last mapping.
    var lastMapping = null;

    aSourceMapConsumer.eachMapping(function (mapping) {
      if (lastMapping !== null) {
        // We add the code from "lastMapping" to "mapping":
        // First check if there is a new line in between.
        if (lastGeneratedLine < mapping.generatedLine) {
          // Associate first line with "lastMapping"
          addMappingWithCode(lastMapping, shiftNextLine());
          lastGeneratedLine++;
          lastGeneratedColumn = 0;
          // The remaining code is added without mapping
        } else {
          // There is no new line in between.
          // Associate the code between "lastGeneratedColumn" and
          // "mapping.generatedColumn" with "lastMapping"
          var nextLine = remainingLines[remainingLinesIndex];
          var code = nextLine.substr(0, mapping.generatedColumn -
                                        lastGeneratedColumn);
          remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn -
                                              lastGeneratedColumn);
          lastGeneratedColumn = mapping.generatedColumn;
          addMappingWithCode(lastMapping, code);
          // No more remaining code, continue
          lastMapping = mapping;
          return;
        }
      }
      // We add the generated code until the first mapping
      // to the SourceNode without any mapping.
      // Each line is added as separate string.
      while (lastGeneratedLine < mapping.generatedLine) {
        node.add(shiftNextLine());
        lastGeneratedLine++;
      }
      if (lastGeneratedColumn < mapping.generatedColumn) {
        var nextLine = remainingLines[remainingLinesIndex];
        node.add(nextLine.substr(0, mapping.generatedColumn));
        remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn);
        lastGeneratedColumn = mapping.generatedColumn;
      }
      lastMapping = mapping;
    }, this);
    // We have processed all mappings.
    if (remainingLinesIndex < remainingLines.length) {
      if (lastMapping) {
        // Associate the remaining code in the current line with "lastMapping"
        addMappingWithCode(lastMapping, shiftNextLine());
      }
      // and add the remaining lines without any mapping
      node.add(remainingLines.splice(remainingLinesIndex).join(""));
    }

    // Copy sourcesContent into SourceNode
    aSourceMapConsumer.sources.forEach(function (sourceFile) {
      var content = aSourceMapConsumer.sourceContentFor(sourceFile);
      if (content != null) {
        if (aRelativePath != null) {
          sourceFile = util.join(aRelativePath, sourceFile);
        }
        node.setSourceContent(sourceFile, content);
      }
    });

    return node;

    function addMappingWithCode(mapping, code) {
      if (mapping === null || mapping.source === undefined) {
        node.add(code);
      } else {
        var source = aRelativePath
          ? util.join(aRelativePath, mapping.source)
          : mapping.source;
        node.add(new SourceNode(mapping.originalLine,
                                mapping.originalColumn,
                                source,
                                code,
                                mapping.name));
      }
    }
  };

/**
 * Add a chunk of generated JS to this source node.
 *
 * @param aChunk A string snippet of generated JS code, another instance of
 *        SourceNode, or an array where each member is one of those things.
 */
SourceNode.prototype.add = function SourceNode_add(aChunk) {
  if (Array.isArray(aChunk)) {
    aChunk.forEach(function (chunk) {
      this.add(chunk);
    }, this);
  }
  else if (aChunk[isSourceNode] || typeof aChunk === "string") {
    if (aChunk) {
      this.children.push(aChunk);
    }
  }
  else {
    throw new TypeError(
      "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
    );
  }
  return this;
};

/**
 * Add a chunk of generated JS to the beginning of this source node.
 *
 * @param aChunk A string snippet of generated JS code, another instance of
 *        SourceNode, or an array where each member is one of those things.
 */
SourceNode.prototype.prepend = function SourceNode_prepend(aChunk) {
  if (Array.isArray(aChunk)) {
    for (var i = aChunk.length-1; i >= 0; i--) {
      this.prepend(aChunk[i]);
    }
  }
  else if (aChunk[isSourceNode] || typeof aChunk === "string") {
    this.children.unshift(aChunk);
  }
  else {
    throw new TypeError(
      "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
    );
  }
  return this;
};

/**
 * Walk over the tree of JS snippets in this node and its children. The
 * walking function is called once for each snippet of JS and is passed that
 * snippet and the its original associated source's line/column location.
 *
 * @param aFn The traversal function.
 */
SourceNode.prototype.walk = function SourceNode_walk(aFn) {
  var chunk;
  for (var i = 0, len = this.children.length; i < len; i++) {
    chunk = this.children[i];
    if (chunk[isSourceNode]) {
      chunk.walk(aFn);
    }
    else {
      if (chunk !== '') {
        aFn(chunk, { source: this.source,
                     line: this.line,
                     column: this.column,
                     name: this.name });
      }
    }
  }
};

/**
 * Like `String.prototype.join` except for SourceNodes. Inserts `aStr` between
 * each of `this.children`.
 *
 * @param aSep The separator.
 */
SourceNode.prototype.join = function SourceNode_join(aSep) {
  var newChildren;
  var i;
  var len = this.children.length;
  if (len > 0) {
    newChildren = [];
    for (i = 0; i < len-1; i++) {
      newChildren.push(this.children[i]);
      newChildren.push(aSep);
    }
    newChildren.push(this.children[i]);
    this.children = newChildren;
  }
  return this;
};

/**
 * Call String.prototype.replace on the very right-most source snippet. Useful
 * for trimming whitespace from the end of a source node, etc.
 *
 * @param aPattern The pattern to replace.
 * @param aReplacement The thing to replace the pattern with.
 */
SourceNode.prototype.replaceRight = function SourceNode_replaceRight(aPattern, aReplacement) {
  var lastChild = this.children[this.children.length - 1];
  if (lastChild[isSourceNode]) {
    lastChild.replaceRight(aPattern, aReplacement);
  }
  else if (typeof lastChild === 'string') {
    this.children[this.children.length - 1] = lastChild.replace(aPattern, aReplacement);
  }
  else {
    this.children.push(''.replace(aPattern, aReplacement));
  }
  return this;
};

/**
 * Set the source content for a source file. This will be added to the SourceMapGenerator
 * in the sourcesContent field.
 *
 * @param aSourceFile The filename of the source file
 * @param aSourceContent The content of the source file
 */
SourceNode.prototype.setSourceContent =
  function SourceNode_setSourceContent(aSourceFile, aSourceContent) {
    this.sourceContents[util.toSetString(aSourceFile)] = aSourceContent;
  };

/**
 * Walk over the tree of SourceNodes. The walking function is called for each
 * source file content and is passed the filename and source content.
 *
 * @param aFn The traversal function.
 */
SourceNode.prototype.walkSourceContents =
  function SourceNode_walkSourceContents(aFn) {
    for (var i = 0, len = this.children.length; i < len; i++) {
      if (this.children[i][isSourceNode]) {
        this.children[i].walkSourceContents(aFn);
      }
    }

    var sources = Object.keys(this.sourceContents);
    for (var i = 0, len = sources.length; i < len; i++) {
      aFn(util.fromSetString(sources[i]), this.sourceContents[sources[i]]);
    }
  };

/**
 * Return the string representation of this source node. Walks over the tree
 * and concatenates all the various snippets together to one string.
 */
SourceNode.prototype.toString = function SourceNode_toString() {
  var str = "";
  this.walk(function (chunk) {
    str += chunk;
  });
  return str;
};

/**
 * Returns the string representation of this source node along with a source
 * map.
 */
SourceNode.prototype.toStringWithSourceMap = function SourceNode_toStringWithSourceMap(aArgs) {
  var generated = {
    code: "",
    line: 1,
    column: 0
  };
  var map = new SourceMapGenerator(aArgs);
  var sourceMappingActive = false;
  var lastOriginalSource = null;
  var lastOriginalLine = null;
  var lastOriginalColumn = null;
  var lastOriginalName = null;
  this.walk(function (chunk, original) {
    generated.code += chunk;
    if (original.source !== null
        && original.line !== null
        && original.column !== null) {
      if(lastOriginalSource !== original.source
         || lastOriginalLine !== original.line
         || lastOriginalColumn !== original.column
         || lastOriginalName !== original.name) {
        map.addMapping({
          source: original.source,
          original: {
            line: original.line,
            column: original.column
          },
          generated: {
            line: generated.line,
            column: generated.column
          },
          name: original.name
        });
      }
      lastOriginalSource = original.source;
      lastOriginalLine = original.line;
      lastOriginalColumn = original.column;
      lastOriginalName = original.name;
      sourceMappingActive = true;
    } else if (sourceMappingActive) {
      map.addMapping({
        generated: {
          line: generated.line,
          column: generated.column
        }
      });
      lastOriginalSource = null;
      sourceMappingActive = false;
    }
    for (var idx = 0, length = chunk.length; idx < length; idx++) {
      if (chunk.charCodeAt(idx) === NEWLINE_CODE) {
        generated.line++;
        generated.column = 0;
        // Mappings end at eol
        if (idx + 1 === length) {
          lastOriginalSource = null;
          sourceMappingActive = false;
        } else if (sourceMappingActive) {
          map.addMapping({
            source: original.source,
            original: {
              line: original.line,
              column: original.column
            },
            generated: {
              line: generated.line,
              column: generated.column
            },
            name: original.name
          });
        }
      } else {
        generated.column++;
      }
    }
  });
  this.walkSourceContents(function (sourceFile, sourceContent) {
    map.setSourceContent(sourceFile, sourceContent);
  });

  return { code: generated.code, map: map };
};

exports.SourceNode = SourceNode;


/***/ }),
/* 30 */
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ }),
/* 31 */
/***/ (function(module, exports) {

module.exports = require("module");

/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Telnyx.DEFAULT_HOST = process.env.TELNYX_API_BASE || 'api.telnyx.com';
Telnyx.DEFAULT_PORT = '443';
Telnyx.DEFAULT_BASE_PATH = '/v2/';

// Use node's default timeout:
Telnyx.DEFAULT_TIMEOUT = __webpack_require__(4).createServer().timeout;

Telnyx.PACKAGE_VERSION = __webpack_require__(33).version;

Telnyx.USER_AGENT = {
  bindings_version: Telnyx.PACKAGE_VERSION,
  lang: 'node',
  lang_version: process.version,
  platform: process.platform,
  publisher: 'telnyx',
  uname: null,
};

Telnyx.USER_AGENT_SERIALIZED = null;

Telnyx.MAX_NETWORK_RETRY_DELAY_SEC = 2;
Telnyx.INITIAL_NETWORK_RETRY_DELAY_SEC = 0.5;

var APP_INFO_PROPERTIES = ['name', 'version', 'url', 'partner_id'];

var http = __webpack_require__(4);
var https = __webpack_require__(10);

var EventEmitter = __webpack_require__(11).EventEmitter;
var exec = __webpack_require__(34).exec;
var utils = __webpack_require__(1);

var resources = {
  AvailablePhoneNumbers: __webpack_require__(39),
  Events: __webpack_require__(42),
  Messages: __webpack_require__(43),
  MessagingPhoneNumbers: __webpack_require__(45),
  MessagingProfiles: __webpack_require__(46),
  MessagingSenderIds: __webpack_require__(47),
  MessagingShortCodes: __webpack_require__(48),
  NumberOrders: __webpack_require__(49),
  NumberReservations: __webpack_require__(50),
  PhoneNumbers: __webpack_require__(51),
  Calls: __webpack_require__(54),
  Conferences: __webpack_require__(55),
  CallEvents: __webpack_require__(56),
  PublicKey: __webpack_require__(57),
  SimCards: __webpack_require__(58),
  BillingGroups: __webpack_require__(59),
  Ips: __webpack_require__(60),
  Fqdns: __webpack_require__(61),
  Connections: __webpack_require__(62),
  IpConnections: __webpack_require__(63),
  FqdnConnections: __webpack_require__(64),
  CredentialConnections: __webpack_require__(65),
  RegulatoryRequirements: __webpack_require__(66),
  PhoneNumberRegulatoryRequirements: __webpack_require__(67),
  NumberOrderDocuments: __webpack_require__(68),
  Actions: __webpack_require__(69),
  OutboundVoiceProfiles: __webpack_require__(71),
  CallControlApplications: __webpack_require__(72),
  PhoneNumbersInboundChannels: __webpack_require__(18),
  OtaUpdates: __webpack_require__(73),
  MobileOperatorNetworks: __webpack_require__(74),
  SimCardGroups: __webpack_require__(75),
  NumberLookup: __webpack_require__(76),
  Balance: __webpack_require__(77),
  Addresses: __webpack_require__(78),
  Faxes: __webpack_require__(79),
  ShortCodes: __webpack_require__(80),
  MessagingProfileMetrics: __webpack_require__(81),
  TelephonyCredentials: __webpack_require__(82),
  VerifyProfiles: __webpack_require__(83),
  Verifications: __webpack_require__(84),
};

Telnyx.TelnyxResource = __webpack_require__(0);
Telnyx.resources = resources;

function Telnyx(key, version) {
  if (!(this instanceof Telnyx)) {
    return new Telnyx(key, version);
  }

  Object.defineProperty(this, '_emitter', {
    value: new EventEmitter(),
    enumerable: false,
    configurable: false,
    writeable: false,
  });

  this.on = this._emitter.on.bind(this._emitter);
  this.off = this._emitter.removeListener.bind(this._emitter);

  this._api = {
    auth: null,
    host: Telnyx.DEFAULT_HOST,
    port: Telnyx.DEFAULT_PORT,
    basePath: Telnyx.DEFAULT_BASE_PATH,
    timeout: Telnyx.DEFAULT_TIMEOUT,
    http_agent: this._buildDefaultAgent('http'),
    https_agent: this._buildDefaultAgent('https'),
    dev: false,
    maxNetworkRetries: 0,
  };

  this.setApiKey(key);
  this._prepResources();

  this.errors = __webpack_require__(3);
  this.webhooks = __webpack_require__(19);

  this._prevRequestMetrics = [];
}

Telnyx.errors = __webpack_require__(3);
Telnyx.webhooks = __webpack_require__(19);

Telnyx.prototype = {
  setHost: function(host, port, protocol) {
    this._setApiField('host', host);
    if (port) {
      this.setPort(port);
    }
    if (protocol) {
      this.setProtocol(protocol);
    }
  },

  setProtocol: function(protocol) {
    this._setApiField('protocol', protocol.toLowerCase());
  },

  setPort: function(port) {
    this._setApiField('port', port);
  },

  setApiKey: function(key) {
    if (key) {
      this._setApiField(
        'auth',
        'Bearer ' + key
      );
    }
  },

  setTimeout: function(timeout) {
    this._setApiField(
      'timeout',
      timeout == null ? Telnyx.DEFAULT_TIMEOUT : timeout
    );
  },

  setAppInfo: function(info) {
    if (info && typeof info !== 'object') {
      throw new Error('AppInfo must be an object.');
    }

    if (info && !info.name) {
      throw new Error('AppInfo.name is required');
    }

    info = info || {};

    var appInfo = APP_INFO_PROPERTIES.reduce(function(accum, prop) {
      if (typeof info[prop] == 'string') {
        accum = accum || {};

        accum[prop] = info[prop];
      }

      return accum;
    }, undefined);

    // Kill the cached UA string because it may no longer be valid
    Telnyx.USER_AGENT_SERIALIZED = undefined;

    this._appInfo = appInfo;
  },

  setHttpAgent: function(agent) {
    if (agent instanceof https.Agent) {
      this._setApiField('https_agent', agent);
    } else {
      this._setApiField('http_agent', agent);
    }
  },

  _setApiField: function(key, value) {
    this._api[key] = value;
  },

  getApiField: function(key) {
    return this._api[key];
  },

  setClientId: function(clientId) {
    this._clientId = clientId;
  },

  getClientId: function() {
    return this._clientId;
  },

  getConstant: function(c) {
    return Telnyx[c];
  },

  getMaxNetworkRetries: function() {
    return this.getApiField('maxNetworkRetries');
  },

  setMaxNetworkRetries: function(maxNetworkRetries) {
    if ((maxNetworkRetries && typeof maxNetworkRetries !== 'number') || arguments.length < 1) {
      throw new Error('maxNetworkRetries must be a number.');
    }

    this._setApiField('maxNetworkRetries', maxNetworkRetries);
  },

  getMaxNetworkRetryDelay: function() {
    return this.getConstant('MAX_NETWORK_RETRY_DELAY_SEC');
  },

  getInitialNetworkRetryDelay: function() {
    return this.getConstant('INITIAL_NETWORK_RETRY_DELAY_SEC');
  },

  // Gets a JSON version of a User-Agent and uses a cached version for a slight
  // speed advantage.
  getClientUserAgent: function(cb) {
    if (Telnyx.USER_AGENT_SERIALIZED) {
      return cb(Telnyx.USER_AGENT_SERIALIZED);
    }
    this.getClientUserAgentSeeded(Telnyx.USER_AGENT, function(cua) {
      Telnyx.USER_AGENT_SERIALIZED = cua;
      cb(Telnyx.USER_AGENT_SERIALIZED);
    })
  },

  // Gets a JSON version of a User-Agent by encoding a seeded object and
  // fetching a uname from the system.
  getClientUserAgentSeeded: function(seed, cb) {
    var self = this;

    exec('uname -a', function(err, uname) {
      var userAgent = {};
      for (var field in seed) {
        userAgent[field] = encodeURIComponent(seed[field]);
      }

      // URI-encode in case there are unusual characters in the system's uname.
      userAgent.uname = encodeURIComponent(uname) || 'UNKNOWN';

      if (self._appInfo) {
        userAgent.application = self._appInfo;
      }

      cb(JSON.stringify(userAgent));
    });
  },

  getAppInfoAsString: function() {
    if (!this._appInfo) {
      return '';
    }

    var formatted = this._appInfo.name;

    if (this._appInfo.version) {
      formatted += '/' + this._appInfo.version;
    }

    if (this._appInfo.url) {
      formatted += ' (' + this._appInfo.url + ')';
    }

    return formatted;
  },

  _buildDefaultAgent: function(protocol) {
    var httpLib = protocol === 'http' ? http : https;
    return new httpLib.Agent({keepAlive: true});
  },

  _prepResources: function() {
    for (var name in resources) {
      this._instantiateResource(name, this);

      this[utils.toSingular(name)] = this._createConstructor(name, this);
    }
  },

  _instantiateResource: function(name, self) {
    var camelCaseName = utils.pascalToCamelCase(name);

    self[camelCaseName] = new resources[name](self);

    return self[camelCaseName];
  },

  _createConstructor: function(resourceName, self) {
    return function(args) {
      return Object.assign(self._instantiateResource(resourceName, self), args || {});
    }
  },
};

module.exports = Telnyx;
// expose constructor as a named property to enable mocking with Sinon.JS
module.exports.Telnyx = Telnyx;


/***/ }),
/* 33 */
/***/ (function(module) {

module.exports = JSON.parse("{\"_from\":\"telnyx\",\"_id\":\"telnyx@1.11.0\",\"_inBundle\":false,\"_integrity\":\"sha512-MXh+h0uoyPtVIRuv79Lpf26gpKtlbKGZt0YlIwWsdODf+ahIsAJxm1vkseXLfIq96hZraodHNA7mNkYTixBExg==\",\"_location\":\"/telnyx\",\"_phantomChildren\":{},\"_requested\":{\"type\":\"tag\",\"registry\":true,\"raw\":\"telnyx\",\"name\":\"telnyx\",\"escapedName\":\"telnyx\",\"rawSpec\":\"\",\"saveSpec\":null,\"fetchSpec\":\"latest\"},\"_requiredBy\":[\"#USER\",\"/\"],\"_resolved\":\"https://registry.npmjs.org/telnyx/-/telnyx-1.11.0.tgz\",\"_shasum\":\"bf314c37f44b468072d88c2b79f90b3c191e9988\",\"_shrinkwrap\":{\"name\":\"telnyx\",\"version\":\"1.11.0\",\"lockfileVersion\":1,\"requires\":true,\"dependencies\":{\"@babel/code-frame\":{\"version\":\"7.5.5\",\"resolved\":\"https://registry.npmjs.org/@babel/code-frame/-/code-frame-7.5.5.tgz\",\"integrity\":\"sha512-27d4lZoomVyo51VegxI20xZPuSHusqbQag/ztrBC7wegWoQ1nLREPVSKSW8byhTlzTKyNE4ifaTA6lCp7JjpFw==\",\"dev\":true,\"requires\":{\"@babel/highlight\":\"^7.0.0\"}},\"@babel/generator\":{\"version\":\"7.5.5\",\"resolved\":\"https://registry.npmjs.org/@babel/generator/-/generator-7.5.5.tgz\",\"integrity\":\"sha512-ETI/4vyTSxTzGnU2c49XHv2zhExkv9JHLTwDAFz85kmcwuShvYG2H08FwgIguQf4JC75CBnXAUM5PqeF4fj0nQ==\",\"dev\":true,\"requires\":{\"@babel/types\":\"^7.5.5\",\"jsesc\":\"^2.5.1\",\"lodash\":\"^4.17.13\",\"source-map\":\"^0.5.0\",\"trim-right\":\"^1.0.1\"}},\"@babel/helper-function-name\":{\"version\":\"7.1.0\",\"resolved\":\"https://registry.npmjs.org/@babel/helper-function-name/-/helper-function-name-7.1.0.tgz\",\"integrity\":\"sha512-A95XEoCpb3TO+KZzJ4S/5uW5fNe26DjBGqf1o9ucyLyCmi1dXq/B3c8iaWTfBk3VvetUxl16e8tIrd5teOCfGw==\",\"dev\":true,\"requires\":{\"@babel/helper-get-function-arity\":\"^7.0.0\",\"@babel/template\":\"^7.1.0\",\"@babel/types\":\"^7.0.0\"}},\"@babel/helper-get-function-arity\":{\"version\":\"7.0.0\",\"resolved\":\"https://registry.npmjs.org/@babel/helper-get-function-arity/-/helper-get-function-arity-7.0.0.tgz\",\"integrity\":\"sha512-r2DbJeg4svYvt3HOS74U4eWKsUAMRH01Z1ds1zx8KNTPtpTL5JAsdFv8BNyOpVqdFhHkkRDIg5B4AsxmkjAlmQ==\",\"dev\":true,\"requires\":{\"@babel/types\":\"^7.0.0\"}},\"@babel/helper-split-export-declaration\":{\"version\":\"7.4.4\",\"resolved\":\"https://registry.npmjs.org/@babel/helper-split-export-declaration/-/helper-split-export-declaration-7.4.4.tgz\",\"integrity\":\"sha512-Ro/XkzLf3JFITkW6b+hNxzZ1n5OQ80NvIUdmHspih1XAhtN3vPTuUFT4eQnela+2MaZ5ulH+iyP513KJrxbN7Q==\",\"dev\":true,\"requires\":{\"@babel/types\":\"^7.4.4\"}},\"@babel/highlight\":{\"version\":\"7.5.0\",\"resolved\":\"https://registry.npmjs.org/@babel/highlight/-/highlight-7.5.0.tgz\",\"integrity\":\"sha512-7dV4eu9gBxoM0dAnj/BCFDW9LFU0zvTrkq0ugM7pnHEgguOEeOz1so2ZghEdzviYzQEED0r4EAgpsBChKy1TRQ==\",\"dev\":true,\"requires\":{\"chalk\":\"^2.0.0\",\"esutils\":\"^2.0.2\",\"js-tokens\":\"^4.0.0\"},\"dependencies\":{\"js-tokens\":{\"version\":\"4.0.0\",\"resolved\":\"https://registry.npmjs.org/js-tokens/-/js-tokens-4.0.0.tgz\",\"integrity\":\"sha512-RdJUflcE3cUzKiMqQgsCu06FPu9UdIJO0beYbPhHN4k6apgJtifcoCtT9bcxOpYBtpD2kCM6Sbzg4CausW/PKQ==\",\"dev\":true}}},\"@babel/parser\":{\"version\":\"7.5.5\",\"resolved\":\"https://registry.npmjs.org/@babel/parser/-/parser-7.5.5.tgz\",\"integrity\":\"sha512-E5BN68cqR7dhKan1SfqgPGhQ178bkVKpXTPEXnFJBrEt8/DKRZlybmy+IgYLTeN7tp1R5Ccmbm2rBk17sHYU3g==\",\"dev\":true},\"@babel/template\":{\"version\":\"7.4.4\",\"resolved\":\"https://registry.npmjs.org/@babel/template/-/template-7.4.4.tgz\",\"integrity\":\"sha512-CiGzLN9KgAvgZsnivND7rkA+AeJ9JB0ciPOD4U59GKbQP2iQl+olF1l76kJOupqidozfZ32ghwBEJDhnk9MEcw==\",\"dev\":true,\"requires\":{\"@babel/code-frame\":\"^7.0.0\",\"@babel/parser\":\"^7.4.4\",\"@babel/types\":\"^7.4.4\"}},\"@babel/traverse\":{\"version\":\"7.5.5\",\"resolved\":\"https://registry.npmjs.org/@babel/traverse/-/traverse-7.5.5.tgz\",\"integrity\":\"sha512-MqB0782whsfffYfSjH4TM+LMjrJnhCNEDMDIjeTpl+ASaUvxcjoiVCo/sM1GhS1pHOXYfWVCYneLjMckuUxDaQ==\",\"dev\":true,\"requires\":{\"@babel/code-frame\":\"^7.5.5\",\"@babel/generator\":\"^7.5.5\",\"@babel/helper-function-name\":\"^7.1.0\",\"@babel/helper-split-export-declaration\":\"^7.4.4\",\"@babel/parser\":\"^7.5.5\",\"@babel/types\":\"^7.5.5\",\"debug\":\"^4.1.0\",\"globals\":\"^11.1.0\",\"lodash\":\"^4.17.13\"}},\"@babel/types\":{\"version\":\"7.5.5\",\"resolved\":\"https://registry.npmjs.org/@babel/types/-/types-7.5.5.tgz\",\"integrity\":\"sha512-s63F9nJioLqOlW3UkyMd+BYhXt44YuaFm/VV0VwuteqjYwRrObkU7ra9pY4wAJR3oXi8hJrMcrcJdO/HH33vtw==\",\"dev\":true,\"requires\":{\"esutils\":\"^2.0.2\",\"lodash\":\"^4.17.13\",\"to-fast-properties\":\"^2.0.0\"}},\"acorn\":{\"version\":\"5.7.3\",\"resolved\":\"https://registry.npmjs.org/acorn/-/acorn-5.7.3.tgz\",\"integrity\":\"sha512-T/zvzYRfbVojPWahDsE5evJdHb3oJoQfFbsrKM7w5Zcs++Tr257tia3BmMP8XYVjp1S9RZXQMh7gao96BlqZOw==\",\"dev\":true},\"acorn-jsx\":{\"version\":\"3.0.1\",\"resolved\":\"https://registry.npmjs.org/acorn-jsx/-/acorn-jsx-3.0.1.tgz\",\"integrity\":\"sha1-r9+UiPsezvyDSPb7IvRk4ypYs2s=\",\"dev\":true,\"requires\":{\"acorn\":\"^3.0.4\"},\"dependencies\":{\"acorn\":{\"version\":\"3.3.0\",\"resolved\":\"https://registry.npmjs.org/acorn/-/acorn-3.3.0.tgz\",\"integrity\":\"sha1-ReN/s56No/JbruP/U2niu18iAXo=\",\"dev\":true}}},\"ajv\":{\"version\":\"6.10.2\",\"resolved\":\"https://registry.npmjs.org/ajv/-/ajv-6.10.2.tgz\",\"integrity\":\"sha512-TXtUUEYHuaTEbLZWIKUr5pmBuhDLy+8KYtPYdcV8qC+pOZL+NKqYwvWSRrVXHn+ZmRRAu8vJTAznH7Oag6RVRw==\",\"dev\":true,\"requires\":{\"fast-deep-equal\":\"^2.0.1\",\"fast-json-stable-stringify\":\"^2.0.0\",\"json-schema-traverse\":\"^0.4.1\",\"uri-js\":\"^4.2.2\"}},\"ajv-keywords\":{\"version\":\"2.1.1\",\"resolved\":\"https://registry.npmjs.org/ajv-keywords/-/ajv-keywords-2.1.1.tgz\",\"integrity\":\"sha1-YXmX/F9gV2iUxDX5QNgZ4TW4B2I=\",\"dev\":true},\"ansi-escapes\":{\"version\":\"3.2.0\",\"resolved\":\"https://registry.npmjs.org/ansi-escapes/-/ansi-escapes-3.2.0.tgz\",\"integrity\":\"sha512-cBhpre4ma+U0T1oM5fXg7Dy1Jw7zzwv7lt/GoCpr+hDQJoYnKVPLL4dCvSEFMmQurOQvSrwT7SL/DAlhBI97RQ==\",\"dev\":true},\"ansi-regex\":{\"version\":\"2.1.1\",\"resolved\":\"https://registry.npmjs.org/ansi-regex/-/ansi-regex-2.1.1.tgz\",\"integrity\":\"sha1-w7M6te42DYbg5ijwRorn7yfWVN8=\",\"dev\":true},\"ansi-styles\":{\"version\":\"2.2.1\",\"resolved\":\"https://registry.npmjs.org/ansi-styles/-/ansi-styles-2.2.1.tgz\",\"integrity\":\"sha1-tDLdM1i2NM914eRmQ2gkBTPB3b4=\",\"dev\":true},\"append-transform\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/append-transform/-/append-transform-1.0.0.tgz\",\"integrity\":\"sha512-P009oYkeHyU742iSZJzZZywj4QRJdnTWffaKuJQLablCZ1uz6/cW4yaRgcDaoQ+uwOxxnt0gRUcwfsNP2ri0gw==\",\"dev\":true,\"requires\":{\"default-require-extensions\":\"^2.0.0\"}},\"archy\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/archy/-/archy-1.0.0.tgz\",\"integrity\":\"sha1-+cjBN1fMHde8N5rHeyxipcKGjEA=\",\"dev\":true},\"argparse\":{\"version\":\"1.0.10\",\"resolved\":\"https://registry.npmjs.org/argparse/-/argparse-1.0.10.tgz\",\"integrity\":\"sha512-o5Roy6tNG4SL/FOkCAN6RzjiakZS25RLYFrcMttJqbdd8BWrnA+fGz57iN5Pb06pvBGvl5gQ0B48dJlslXvoTg==\",\"dev\":true,\"requires\":{\"sprintf-js\":\"~1.0.2\"}},\"asn1\":{\"version\":\"0.2.4\",\"resolved\":\"https://registry.npmjs.org/asn1/-/asn1-0.2.4.tgz\",\"integrity\":\"sha512-jxwzQpLQjSmWXgwaCZE9Nz+glAG01yF1QnWgbhGwHI5A6FRIEY6IVqtHhIepHqI7/kyEyQEagBC5mBEFlIYvdg==\",\"dev\":true,\"requires\":{\"safer-buffer\":\"~2.1.0\"}},\"assert-plus\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/assert-plus/-/assert-plus-1.0.0.tgz\",\"integrity\":\"sha1-8S4PPF13sLHN2RRpQuTpbB5N1SU=\",\"dev\":true},\"assertion-error\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/assertion-error/-/assertion-error-1.1.0.tgz\",\"integrity\":\"sha512-jgsaNduz+ndvGyFt3uSuWqvy4lCnIJiovtouQN5JZHOKCS2QuhEdbcQHFhVksz2N2U9hXJo8odG7ETyWlEeuDw==\",\"dev\":true},\"asynckit\":{\"version\":\"0.4.0\",\"resolved\":\"https://registry.npmjs.org/asynckit/-/asynckit-0.4.0.tgz\",\"integrity\":\"sha1-x57Zf380y48robyXkLzDZkdLS3k=\",\"dev\":true},\"aws-sign2\":{\"version\":\"0.7.0\",\"resolved\":\"https://registry.npmjs.org/aws-sign2/-/aws-sign2-0.7.0.tgz\",\"integrity\":\"sha1-tG6JCTSpWR8tL2+G1+ap8bP+dqg=\",\"dev\":true},\"aws4\":{\"version\":\"1.8.0\",\"resolved\":\"https://registry.npmjs.org/aws4/-/aws4-1.8.0.tgz\",\"integrity\":\"sha512-ReZxvNHIOv88FlT7rxcXIIC0fPt4KZqZbOlivyWtXLt8ESx84zd3kMC6iK5jVeS2qt+g7ftS7ye4fi06X5rtRQ==\",\"dev\":true},\"babel-code-frame\":{\"version\":\"6.26.0\",\"resolved\":\"https://registry.npmjs.org/babel-code-frame/-/babel-code-frame-6.26.0.tgz\",\"integrity\":\"sha1-Y/1D99weO7fONZR9uP42mj9Yx0s=\",\"dev\":true,\"requires\":{\"chalk\":\"^1.1.3\",\"esutils\":\"^2.0.2\",\"js-tokens\":\"^3.0.2\"},\"dependencies\":{\"chalk\":{\"version\":\"1.1.3\",\"resolved\":\"https://registry.npmjs.org/chalk/-/chalk-1.1.3.tgz\",\"integrity\":\"sha1-qBFcVeSnAv5NFQq9OHKCKn4J/Jg=\",\"dev\":true,\"requires\":{\"ansi-styles\":\"^2.2.1\",\"escape-string-regexp\":\"^1.0.2\",\"has-ansi\":\"^2.0.0\",\"strip-ansi\":\"^3.0.0\",\"supports-color\":\"^2.0.0\"}},\"strip-ansi\":{\"version\":\"3.0.1\",\"resolved\":\"https://registry.npmjs.org/strip-ansi/-/strip-ansi-3.0.1.tgz\",\"integrity\":\"sha1-ajhfuIU9lS1f8F0Oiq+UJ43GPc8=\",\"dev\":true,\"requires\":{\"ansi-regex\":\"^2.0.0\"}}}},\"balanced-match\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/balanced-match/-/balanced-match-1.0.0.tgz\",\"integrity\":\"sha1-ibTRmasr7kneFk6gK4nORi1xt2c=\",\"dev\":true},\"bcrypt-pbkdf\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/bcrypt-pbkdf/-/bcrypt-pbkdf-1.0.2.tgz\",\"integrity\":\"sha1-pDAdOJtqQ/m2f/PKEaP2Y342Dp4=\",\"dev\":true,\"requires\":{\"tweetnacl\":\"^0.14.3\"},\"dependencies\":{\"tweetnacl\":{\"version\":\"0.14.5\",\"resolved\":\"https://registry.npmjs.org/tweetnacl/-/tweetnacl-0.14.5.tgz\",\"integrity\":\"sha1-WuaBd/GS1EViadEIr6k/+HQ/T2Q=\",\"dev\":true}}},\"brace-expansion\":{\"version\":\"1.1.11\",\"resolved\":\"https://registry.npmjs.org/brace-expansion/-/brace-expansion-1.1.11.tgz\",\"integrity\":\"sha512-iCuPHDFgrHX7H2vEI/5xpz07zSHB00TpugqhmYtVmMO6518mCuRMoOYFldEBl0g187ufozdaHgWKcYFb61qGiA==\",\"dev\":true,\"requires\":{\"balanced-match\":\"^1.0.0\",\"concat-map\":\"0.0.1\"}},\"browser-stdout\":{\"version\":\"1.3.1\",\"resolved\":\"https://registry.npmjs.org/browser-stdout/-/browser-stdout-1.3.1.tgz\",\"integrity\":\"sha512-qhAVI1+Av2X7qelOfAIYwXONood6XlZE/fXaBSmW/T5SzLAmCgzi+eiWE7fUvbHaeNBQH13UftjpXxsfLkMpgw==\",\"dev\":true},\"buffer-from\":{\"version\":\"1.1.1\",\"resolved\":\"https://registry.npmjs.org/buffer-from/-/buffer-from-1.1.1.tgz\",\"integrity\":\"sha512-MQcXEUbCKtEo7bhqEs6560Hyd4XaovZlO/k9V3hjVUF/zwW7KBVdSK4gIt/bzwS9MbR5qob+F5jusZsb0YQK2A==\",\"dev\":true},\"caching-transform\":{\"version\":\"3.0.2\",\"resolved\":\"https://registry.npmjs.org/caching-transform/-/caching-transform-3.0.2.tgz\",\"integrity\":\"sha512-Mtgcv3lh3U0zRii/6qVgQODdPA4G3zhG+jtbCWj39RXuUFTMzH0vcdMtaJS1jPowd+It2Pqr6y3NJMQqOqCE2w==\",\"dev\":true,\"requires\":{\"hasha\":\"^3.0.0\",\"make-dir\":\"^2.0.0\",\"package-hash\":\"^3.0.0\",\"write-file-atomic\":\"^2.4.2\"}},\"caller-path\":{\"version\":\"0.1.0\",\"resolved\":\"https://registry.npmjs.org/caller-path/-/caller-path-0.1.0.tgz\",\"integrity\":\"sha1-lAhe9jWB7NPaqSREqP6U6CV3dR8=\",\"dev\":true,\"requires\":{\"callsites\":\"^0.2.0\"}},\"callsites\":{\"version\":\"0.2.0\",\"resolved\":\"https://registry.npmjs.org/callsites/-/callsites-0.2.0.tgz\",\"integrity\":\"sha1-r6uWJikQp/M8GaV3WCXGnzTjUMo=\",\"dev\":true},\"camelcase\":{\"version\":\"5.3.1\",\"resolved\":\"https://registry.npmjs.org/camelcase/-/camelcase-5.3.1.tgz\",\"integrity\":\"sha512-L28STB170nwWS63UjtlEOE3dldQApaJXZkOI1uMFfzf3rRuPegHaHesyee+YxQ+W6SvRDQV6UrdOdRiR153wJg==\",\"dev\":true},\"caseless\":{\"version\":\"0.12.0\",\"resolved\":\"https://registry.npmjs.org/caseless/-/caseless-0.12.0.tgz\",\"integrity\":\"sha1-G2gcIf+EAzyCZUMJBolCDRhxUdw=\",\"dev\":true},\"chai\":{\"version\":\"4.1.2\",\"resolved\":\"https://registry.npmjs.org/chai/-/chai-4.1.2.tgz\",\"integrity\":\"sha1-D2RYS6ZC8PKs4oBiefTwbKI61zw=\",\"dev\":true,\"requires\":{\"assertion-error\":\"^1.0.1\",\"check-error\":\"^1.0.1\",\"deep-eql\":\"^3.0.0\",\"get-func-name\":\"^2.0.0\",\"pathval\":\"^1.0.0\",\"type-detect\":\"^4.0.0\"}},\"chai-as-promised\":{\"version\":\"7.1.1\",\"resolved\":\"https://registry.npmjs.org/chai-as-promised/-/chai-as-promised-7.1.1.tgz\",\"integrity\":\"sha512-azL6xMoi+uxu6z4rhWQ1jbdUhOMhis2PvscD/xjLqNMkv3BPPp2JyyuTHOrf9BOosGpNQ11v6BKv/g57RXbiaA==\",\"dev\":true,\"requires\":{\"check-error\":\"^1.0.2\"}},\"chalk\":{\"version\":\"2.4.2\",\"resolved\":\"https://registry.npmjs.org/chalk/-/chalk-2.4.2.tgz\",\"integrity\":\"sha512-Mti+f9lpJNcwF4tWV8/OrTTtF1gZi+f8FqlyAdouralcFWFQWF2+NgCHShjkCb+IFBLq9buZwE1xckQU4peSuQ==\",\"dev\":true,\"requires\":{\"ansi-styles\":\"^3.2.1\",\"escape-string-regexp\":\"^1.0.5\",\"supports-color\":\"^5.3.0\"},\"dependencies\":{\"ansi-styles\":{\"version\":\"3.2.1\",\"resolved\":\"https://registry.npmjs.org/ansi-styles/-/ansi-styles-3.2.1.tgz\",\"integrity\":\"sha512-VT0ZI6kZRdTh8YyJw3SMbYm/u+NqfsAxEpWO0Pf9sq8/e94WxxOpPKx9FR1FlyCtOVDNOQ+8ntlqFxiRc+r5qA==\",\"dev\":true,\"requires\":{\"color-convert\":\"^1.9.0\"}},\"supports-color\":{\"version\":\"5.5.0\",\"resolved\":\"https://registry.npmjs.org/supports-color/-/supports-color-5.5.0.tgz\",\"integrity\":\"sha512-QjVjwdXIt408MIiAqCX4oUKsgU2EqAGzs2Ppkm4aQYbjm+ZEWEcW4SfFNTr4uMNZma0ey4f5lgLrkB0aX0QMow==\",\"dev\":true,\"requires\":{\"has-flag\":\"^3.0.0\"}}}},\"chardet\":{\"version\":\"0.4.2\",\"resolved\":\"https://registry.npmjs.org/chardet/-/chardet-0.4.2.tgz\",\"integrity\":\"sha1-tUc7M9yXxCTl2Y3IfVXU2KKci/I=\",\"dev\":true},\"check-error\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/check-error/-/check-error-1.0.2.tgz\",\"integrity\":\"sha1-V00xLt2Iu13YkS6Sht1sCu1KrII=\",\"dev\":true},\"circular-json\":{\"version\":\"0.3.3\",\"resolved\":\"https://registry.npmjs.org/circular-json/-/circular-json-0.3.3.tgz\",\"integrity\":\"sha512-UZK3NBx2Mca+b5LsG7bY183pHWt5Y1xts4P3Pz7ENTwGVnJOUWbRb3ocjvX7hx9tq/yTAdclXm9sZ38gNuem4A==\",\"dev\":true},\"cli-cursor\":{\"version\":\"2.1.0\",\"resolved\":\"https://registry.npmjs.org/cli-cursor/-/cli-cursor-2.1.0.tgz\",\"integrity\":\"sha1-s12sN2R5+sw+lHR9QdDQ9SOP/LU=\",\"dev\":true,\"requires\":{\"restore-cursor\":\"^2.0.0\"}},\"cli-width\":{\"version\":\"2.2.0\",\"resolved\":\"https://registry.npmjs.org/cli-width/-/cli-width-2.2.0.tgz\",\"integrity\":\"sha1-/xnt6Kml5XkyQUewwR8PvLq+1jk=\",\"dev\":true},\"cliui\":{\"version\":\"5.0.0\",\"resolved\":\"https://registry.npmjs.org/cliui/-/cliui-5.0.0.tgz\",\"integrity\":\"sha512-PYeGSEmmHM6zvoef2w8TPzlrnNpXIjTipYK780YswmIP9vjxmd6Y2a3CB2Ks6/AU8NHjZugXvo8w3oWM2qnwXA==\",\"dev\":true,\"requires\":{\"string-width\":\"^3.1.0\",\"strip-ansi\":\"^5.2.0\",\"wrap-ansi\":\"^5.1.0\"},\"dependencies\":{\"ansi-regex\":{\"version\":\"4.1.0\",\"resolved\":\"https://registry.npmjs.org/ansi-regex/-/ansi-regex-4.1.0.tgz\",\"integrity\":\"sha512-1apePfXM1UOSqw0o9IiFAovVz9M5S1Dg+4TrDwfMewQ6p/rmMueb7tWZjQ1rx4Loy1ArBggoqGpfqqdI4rondg==\",\"dev\":true},\"string-width\":{\"version\":\"3.1.0\",\"resolved\":\"https://registry.npmjs.org/string-width/-/string-width-3.1.0.tgz\",\"integrity\":\"sha512-vafcv6KjVZKSgz06oM/H6GDBrAtz8vdhQakGjFIvNrHA6y3HCF1CInLy+QLq8dTJPQ1b+KDUqDFctkdRW44e1w==\",\"dev\":true,\"requires\":{\"emoji-regex\":\"^7.0.1\",\"is-fullwidth-code-point\":\"^2.0.0\",\"strip-ansi\":\"^5.1.0\"}},\"strip-ansi\":{\"version\":\"5.2.0\",\"resolved\":\"https://registry.npmjs.org/strip-ansi/-/strip-ansi-5.2.0.tgz\",\"integrity\":\"sha512-DuRs1gKbBqsMKIZlrffwlug8MHkcnpjs5VPmL1PAh+mA30U0DTotfDZ0d2UUsXpPmPmMMJ6W773MaA3J+lbiWA==\",\"dev\":true,\"requires\":{\"ansi-regex\":\"^4.1.0\"}}}},\"co\":{\"version\":\"4.6.0\",\"resolved\":\"https://registry.npmjs.org/co/-/co-4.6.0.tgz\",\"integrity\":\"sha1-bqa989hTrlTMuOR7+gvz+QMfsYQ=\",\"dev\":true},\"color-convert\":{\"version\":\"1.9.3\",\"resolved\":\"https://registry.npmjs.org/color-convert/-/color-convert-1.9.3.tgz\",\"integrity\":\"sha512-QfAUtd+vFdAtFQcC8CCyYt1fYWxSqAiK2cSD6zDB8N3cpsEBAvRxp9zOGg6G/SHHJYAT88/az/IuDGALsNVbGg==\",\"dev\":true,\"requires\":{\"color-name\":\"1.1.3\"}},\"color-name\":{\"version\":\"1.1.3\",\"resolved\":\"https://registry.npmjs.org/color-name/-/color-name-1.1.3.tgz\",\"integrity\":\"sha1-p9BVi9icQveV3UIyj3QIMcpTvCU=\",\"dev\":true},\"combined-stream\":{\"version\":\"1.0.8\",\"resolved\":\"https://registry.npmjs.org/combined-stream/-/combined-stream-1.0.8.tgz\",\"integrity\":\"sha512-FQN4MRfuJeHf7cBbBMJFXhKSDq+2kAArBlmRBvcvFE5BB1HZKXtSFASDhdlz9zOYwxh8lDdnvmMOe/+5cdoEdg==\",\"dev\":true,\"requires\":{\"delayed-stream\":\"~1.0.0\"}},\"commander\":{\"version\":\"2.11.0\",\"resolved\":\"https://registry.npmjs.org/commander/-/commander-2.11.0.tgz\",\"integrity\":\"sha512-b0553uYA5YAEGgyYIGYROzKQ7X5RAqedkfjiZxwi0kL1g3bOaBNNZfYkzt/CL0umgD5wc9Jec2FbB98CjkMRvQ==\",\"dev\":true},\"commondir\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/commondir/-/commondir-1.0.1.tgz\",\"integrity\":\"sha1-3dgA2gxmEnOTzKWVDqloo6rxJTs=\",\"dev\":true},\"concat-map\":{\"version\":\"0.0.1\",\"resolved\":\"https://registry.npmjs.org/concat-map/-/concat-map-0.0.1.tgz\",\"integrity\":\"sha1-2Klr13/Wjfd5OnMDajug1UBdR3s=\",\"dev\":true},\"concat-stream\":{\"version\":\"1.6.2\",\"resolved\":\"https://registry.npmjs.org/concat-stream/-/concat-stream-1.6.2.tgz\",\"integrity\":\"sha512-27HBghJxjiZtIk3Ycvn/4kbJk/1uZuJFfuPEns6LaEvpvG1f0hTea8lilrouyo9mVc2GWdcEZ8OLoGmSADlrCw==\",\"dev\":true,\"requires\":{\"buffer-from\":\"^1.0.0\",\"inherits\":\"^2.0.3\",\"readable-stream\":\"^2.2.2\",\"typedarray\":\"^0.0.6\"}},\"convert-source-map\":{\"version\":\"1.6.0\",\"resolved\":\"https://registry.npmjs.org/convert-source-map/-/convert-source-map-1.6.0.tgz\",\"integrity\":\"sha512-eFu7XigvxdZ1ETfbgPBohgyQ/Z++C0eEhTor0qRwBw9unw+L0/6V8wkSuGgzdThkiS5lSpdptOQPD8Ak40a+7A==\",\"dev\":true,\"requires\":{\"safe-buffer\":\"~5.1.1\"},\"dependencies\":{\"safe-buffer\":{\"version\":\"5.1.2\",\"resolved\":\"https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.1.2.tgz\",\"integrity\":\"sha512-Gd2UZBJDkXlY7GbJxfsE8/nvKkUEU1G38c1siN6QP6a9PT9MmHB8GnpscSmMJSoF8LOIrt8ud/wPtojys4G6+g==\",\"dev\":true}}},\"core-util-is\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/core-util-is/-/core-util-is-1.0.2.tgz\",\"integrity\":\"sha1-tf1UIgqivFq1eqtxQMlAdUUDwac=\",\"dev\":true},\"coveralls\":{\"version\":\"3.0.5\",\"resolved\":\"https://registry.npmjs.org/coveralls/-/coveralls-3.0.5.tgz\",\"integrity\":\"sha512-/KD7PGfZv/tjKB6LoW97jzIgFqem0Tu9tZL9/iwBnBd8zkIZp7vT1ZSHNvnr0GSQMV/LTMxUstWg8WcDDUVQKg==\",\"dev\":true,\"requires\":{\"growl\":\"~> 1.10.0\",\"js-yaml\":\"^3.13.1\",\"lcov-parse\":\"^0.0.10\",\"log-driver\":\"^1.2.7\",\"minimist\":\"^1.2.0\",\"request\":\"^2.86.0\"}},\"cp-file\":{\"version\":\"6.2.0\",\"resolved\":\"https://registry.npmjs.org/cp-file/-/cp-file-6.2.0.tgz\",\"integrity\":\"sha512-fmvV4caBnofhPe8kOcitBwSn2f39QLjnAnGq3gO9dfd75mUytzKNZB1hde6QHunW2Rt+OwuBOMc3i1tNElbszA==\",\"dev\":true,\"requires\":{\"graceful-fs\":\"^4.1.2\",\"make-dir\":\"^2.0.0\",\"nested-error-stacks\":\"^2.0.0\",\"pify\":\"^4.0.1\",\"safe-buffer\":\"^5.0.1\"}},\"cross-spawn\":{\"version\":\"5.1.0\",\"resolved\":\"https://registry.npmjs.org/cross-spawn/-/cross-spawn-5.1.0.tgz\",\"integrity\":\"sha1-6L0O/uWPz/b4+UUQoKVUu/ojVEk=\",\"dev\":true,\"requires\":{\"lru-cache\":\"^4.0.1\",\"shebang-command\":\"^1.2.0\",\"which\":\"^1.2.9\"}},\"dashdash\":{\"version\":\"1.14.1\",\"resolved\":\"https://registry.npmjs.org/dashdash/-/dashdash-1.14.1.tgz\",\"integrity\":\"sha1-hTz6D3y+L+1d4gMmuN1YEDX24vA=\",\"dev\":true,\"requires\":{\"assert-plus\":\"^1.0.0\"}},\"debug\":{\"version\":\"4.1.1\",\"resolved\":\"https://registry.npmjs.org/debug/-/debug-4.1.1.tgz\",\"integrity\":\"sha512-pYAIzeRo8J6KPEaJ0VWOh5Pzkbw/RetuzehGM7QRRX5he4fPHx2rdKMB256ehJCkX+XRQm16eZLqLNS8RSZXZw==\",\"dev\":true,\"requires\":{\"ms\":\"^2.1.1\"}},\"decamelize\":{\"version\":\"1.2.0\",\"resolved\":\"https://registry.npmjs.org/decamelize/-/decamelize-1.2.0.tgz\",\"integrity\":\"sha1-9lNNFRSCabIDUue+4m9QH5oZEpA=\",\"dev\":true},\"deep-eql\":{\"version\":\"3.0.1\",\"resolved\":\"https://registry.npmjs.org/deep-eql/-/deep-eql-3.0.1.tgz\",\"integrity\":\"sha512-+QeIQyN5ZuO+3Uk5DYh6/1eKO0m0YmJFGNmFHGACpf1ClL1nmlV/p4gNgbl2pJGxgXb4faqo6UE+M5ACEMyVcw==\",\"dev\":true,\"requires\":{\"type-detect\":\"^4.0.0\"}},\"deep-equal\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/deep-equal/-/deep-equal-1.0.1.tgz\",\"integrity\":\"sha1-9dJgKStmDghO/0zbyfCK0yR0SLU=\",\"dev\":true},\"deep-is\":{\"version\":\"0.1.3\",\"resolved\":\"https://registry.npmjs.org/deep-is/-/deep-is-0.1.3.tgz\",\"integrity\":\"sha1-s2nW+128E+7PUk+RsHD+7cNXzzQ=\",\"dev\":true},\"default-require-extensions\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/default-require-extensions/-/default-require-extensions-2.0.0.tgz\",\"integrity\":\"sha1-9fj7sYp9bVCyH2QfZJ67Uiz+JPc=\",\"dev\":true,\"requires\":{\"strip-bom\":\"^3.0.0\"}},\"delayed-stream\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/delayed-stream/-/delayed-stream-1.0.0.tgz\",\"integrity\":\"sha1-3zrhmayt+31ECqrgsp4icrJOxhk=\",\"dev\":true},\"diff\":{\"version\":\"3.5.0\",\"resolved\":\"https://registry.npmjs.org/diff/-/diff-3.5.0.tgz\",\"integrity\":\"sha512-A46qtFgd+g7pDZinpnwiRJtxbC1hpgf0uzP3iG89scHk0AUC7A1TGxf5OiiOUv/JMZR8GOt8hL900hV0bOy5xA==\",\"dev\":true},\"doctrine\":{\"version\":\"2.1.0\",\"resolved\":\"https://registry.npmjs.org/doctrine/-/doctrine-2.1.0.tgz\",\"integrity\":\"sha512-35mSku4ZXK0vfCuHEDAwt55dg2jNajHZ1odvF+8SSr82EsZY4QmXfuWso8oEd8zRhVObSN18aM0CjSdoBX7zIw==\",\"dev\":true,\"requires\":{\"esutils\":\"^2.0.2\"}},\"ecc-jsbn\":{\"version\":\"0.1.2\",\"resolved\":\"https://registry.npmjs.org/ecc-jsbn/-/ecc-jsbn-0.1.2.tgz\",\"integrity\":\"sha1-OoOpBOVDUyh4dMVkt1SThoSamMk=\",\"dev\":true,\"requires\":{\"jsbn\":\"~0.1.0\",\"safer-buffer\":\"^2.1.0\"}},\"emoji-regex\":{\"version\":\"7.0.3\",\"resolved\":\"https://registry.npmjs.org/emoji-regex/-/emoji-regex-7.0.3.tgz\",\"integrity\":\"sha512-CwBLREIQ7LvYFB0WyRvwhq5N5qPhc6PMjD6bYggFlI5YyDgl+0vxq5VHbMOFqLg7hfWzmu8T5Z1QofhmTIhItA==\",\"dev\":true},\"error-ex\":{\"version\":\"1.3.2\",\"resolved\":\"https://registry.npmjs.org/error-ex/-/error-ex-1.3.2.tgz\",\"integrity\":\"sha512-7dFHNmqeFSEt2ZBsCriorKnn3Z2pj+fd9kmI6QoWw4//DL+icEBfc0U7qJCisqrTsKTjw4fNFy2pW9OqStD84g==\",\"dev\":true,\"requires\":{\"is-arrayish\":\"^0.2.1\"}},\"es6-error\":{\"version\":\"4.1.1\",\"resolved\":\"https://registry.npmjs.org/es6-error/-/es6-error-4.1.1.tgz\",\"integrity\":\"sha512-Um/+FxMr9CISWh0bi5Zv0iOD+4cFh5qLeks1qhAopKVAJw3drgKbKySikp7wGhDL0HPeaja0P5ULZrxLkniUVg==\",\"dev\":true},\"escape-string-regexp\":{\"version\":\"1.0.5\",\"resolved\":\"https://registry.npmjs.org/escape-string-regexp/-/escape-string-regexp-1.0.5.tgz\",\"integrity\":\"sha1-G2HAViGQqN/2rjuyzwIAyhMLhtQ=\",\"dev\":true},\"eslint\":{\"version\":\"4.19.1\",\"resolved\":\"https://registry.npmjs.org/eslint/-/eslint-4.19.1.tgz\",\"integrity\":\"sha512-bT3/1x1EbZB7phzYu7vCr1v3ONuzDtX8WjuM9c0iYxe+cq+pwcKEoQjl7zd3RpC6YOLgnSy3cTN58M2jcoPDIQ==\",\"dev\":true,\"requires\":{\"ajv\":\"^5.3.0\",\"babel-code-frame\":\"^6.22.0\",\"chalk\":\"^2.1.0\",\"concat-stream\":\"^1.6.0\",\"cross-spawn\":\"^5.1.0\",\"debug\":\"^3.1.0\",\"doctrine\":\"^2.1.0\",\"eslint-scope\":\"^3.7.1\",\"eslint-visitor-keys\":\"^1.0.0\",\"espree\":\"^3.5.4\",\"esquery\":\"^1.0.0\",\"esutils\":\"^2.0.2\",\"file-entry-cache\":\"^2.0.0\",\"functional-red-black-tree\":\"^1.0.1\",\"glob\":\"^7.1.2\",\"globals\":\"^11.0.1\",\"ignore\":\"^3.3.3\",\"imurmurhash\":\"^0.1.4\",\"inquirer\":\"^3.0.6\",\"is-resolvable\":\"^1.0.0\",\"js-yaml\":\"^3.9.1\",\"json-stable-stringify-without-jsonify\":\"^1.0.1\",\"levn\":\"^0.3.0\",\"lodash\":\"^4.17.4\",\"minimatch\":\"^3.0.2\",\"mkdirp\":\"^0.5.1\",\"natural-compare\":\"^1.4.0\",\"optionator\":\"^0.8.2\",\"path-is-inside\":\"^1.0.2\",\"pluralize\":\"^7.0.0\",\"progress\":\"^2.0.0\",\"regexpp\":\"^1.0.1\",\"require-uncached\":\"^1.0.3\",\"semver\":\"^5.3.0\",\"strip-ansi\":\"^4.0.0\",\"strip-json-comments\":\"~2.0.1\",\"table\":\"4.0.2\",\"text-table\":\"~0.2.0\"},\"dependencies\":{\"ajv\":{\"version\":\"5.5.2\",\"resolved\":\"https://registry.npmjs.org/ajv/-/ajv-5.5.2.tgz\",\"integrity\":\"sha1-c7Xuyj+rZT49P5Qis0GtQiBdyWU=\",\"dev\":true,\"requires\":{\"co\":\"^4.6.0\",\"fast-deep-equal\":\"^1.0.0\",\"fast-json-stable-stringify\":\"^2.0.0\",\"json-schema-traverse\":\"^0.3.0\"}},\"debug\":{\"version\":\"3.2.6\",\"resolved\":\"https://registry.npmjs.org/debug/-/debug-3.2.6.tgz\",\"integrity\":\"sha512-mel+jf7nrtEl5Pn1Qx46zARXKDpBbvzezse7p7LqINmdoIk8PYP5SySaxEmYv6TZ0JyEKA1hsCId6DIhgITtWQ==\",\"dev\":true,\"requires\":{\"ms\":\"^2.1.1\"}},\"fast-deep-equal\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/fast-deep-equal/-/fast-deep-equal-1.1.0.tgz\",\"integrity\":\"sha1-wFNHeBfIa1HaqFPIHgWbcz0CNhQ=\",\"dev\":true},\"json-schema-traverse\":{\"version\":\"0.3.1\",\"resolved\":\"https://registry.npmjs.org/json-schema-traverse/-/json-schema-traverse-0.3.1.tgz\",\"integrity\":\"sha1-NJptRMU6Ud6JtAgFxdXlm0F9M0A=\",\"dev\":true}}},\"eslint-plugin-chai-friendly\":{\"version\":\"0.4.1\",\"resolved\":\"https://registry.npmjs.org/eslint-plugin-chai-friendly/-/eslint-plugin-chai-friendly-0.4.1.tgz\",\"integrity\":\"sha512-hkpLN7VVoGGsofZjUhcQ+sufC3FgqMJwD0DvAcRfxY1tVRyQyVsqpaKnToPHJQOrRo0FQ0fSEDwW2gr4rsNdGA==\",\"dev\":true},\"eslint-scope\":{\"version\":\"3.7.3\",\"resolved\":\"https://registry.npmjs.org/eslint-scope/-/eslint-scope-3.7.3.tgz\",\"integrity\":\"sha512-W+B0SvF4gamyCTmUc+uITPY0989iXVfKvhwtmJocTaYoc/3khEHmEmvfY/Gn9HA9VV75jrQECsHizkNw1b68FA==\",\"dev\":true,\"requires\":{\"esrecurse\":\"^4.1.0\",\"estraverse\":\"^4.1.1\"}},\"eslint-visitor-keys\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/eslint-visitor-keys/-/eslint-visitor-keys-1.0.0.tgz\",\"integrity\":\"sha512-qzm/XxIbxm/FHyH341ZrbnMUpe+5Bocte9xkmFMzPMjRaZMcXww+MpBptFvtU+79L362nqiLhekCxCxDPaUMBQ==\",\"dev\":true},\"espree\":{\"version\":\"3.5.4\",\"resolved\":\"https://registry.npmjs.org/espree/-/espree-3.5.4.tgz\",\"integrity\":\"sha512-yAcIQxtmMiB/jL32dzEp2enBeidsB7xWPLNiw3IIkpVds1P+h7qF9YwJq1yUNzp2OKXgAprs4F61ih66UsoD1A==\",\"dev\":true,\"requires\":{\"acorn\":\"^5.5.0\",\"acorn-jsx\":\"^3.0.0\"}},\"esprima\":{\"version\":\"4.0.1\",\"resolved\":\"https://registry.npmjs.org/esprima/-/esprima-4.0.1.tgz\",\"integrity\":\"sha512-eGuFFw7Upda+g4p+QHvnW0RyTX/SVeJBDM/gCtMARO0cLuT2HcEKnTPvhjV6aGeqrCB/sbNop0Kszm0jsaWU4A==\",\"dev\":true},\"esquery\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/esquery/-/esquery-1.0.1.tgz\",\"integrity\":\"sha512-SmiyZ5zIWH9VM+SRUReLS5Q8a7GxtRdxEBVZpm98rJM7Sb+A9DVCndXfkeFUd3byderg+EbDkfnevfCwynWaNA==\",\"dev\":true,\"requires\":{\"estraverse\":\"^4.0.0\"}},\"esrecurse\":{\"version\":\"4.2.1\",\"resolved\":\"https://registry.npmjs.org/esrecurse/-/esrecurse-4.2.1.tgz\",\"integrity\":\"sha512-64RBB++fIOAXPw3P9cy89qfMlvZEXZkqqJkjqqXIvzP5ezRZjW+lPWjw35UX/3EhUPFYbg5ER4JYgDw4007/DQ==\",\"dev\":true,\"requires\":{\"estraverse\":\"^4.1.0\"}},\"estraverse\":{\"version\":\"4.2.0\",\"resolved\":\"https://registry.npmjs.org/estraverse/-/estraverse-4.2.0.tgz\",\"integrity\":\"sha1-De4/7TH81GlhjOc0IJn8GvoL2xM=\",\"dev\":true},\"esutils\":{\"version\":\"2.0.2\",\"resolved\":\"https://registry.npmjs.org/esutils/-/esutils-2.0.2.tgz\",\"integrity\":\"sha1-Cr9PHKpbyx96nYrMbepPqqBLrJs=\",\"dev\":true},\"extend\":{\"version\":\"3.0.2\",\"resolved\":\"https://registry.npmjs.org/extend/-/extend-3.0.2.tgz\",\"integrity\":\"sha512-fjquC59cD7CyW6urNXK0FBufkZcoiGG80wTuPujX590cB5Ttln20E2UB4S/WARVqhXffZl2LNgS+gQdPIIim/g==\",\"dev\":true},\"external-editor\":{\"version\":\"2.2.0\",\"resolved\":\"https://registry.npmjs.org/external-editor/-/external-editor-2.2.0.tgz\",\"integrity\":\"sha512-bSn6gvGxKt+b7+6TKEv1ZycHleA7aHhRHyAqJyp5pbUFuYYNIzpZnQDk7AsYckyWdEnTeAnay0aCy2aV6iTk9A==\",\"dev\":true,\"requires\":{\"chardet\":\"^0.4.0\",\"iconv-lite\":\"^0.4.17\",\"tmp\":\"^0.0.33\"}},\"extsprintf\":{\"version\":\"1.3.0\",\"resolved\":\"https://registry.npmjs.org/extsprintf/-/extsprintf-1.3.0.tgz\",\"integrity\":\"sha1-lpGEQOMEGnpBT4xS48V06zw+HgU=\",\"dev\":true},\"fast-deep-equal\":{\"version\":\"2.0.1\",\"resolved\":\"https://registry.npmjs.org/fast-deep-equal/-/fast-deep-equal-2.0.1.tgz\",\"integrity\":\"sha1-ewUhjd+WZ79/Nwv3/bLLFf3Qqkk=\",\"dev\":true},\"fast-json-stable-stringify\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/fast-json-stable-stringify/-/fast-json-stable-stringify-2.0.0.tgz\",\"integrity\":\"sha1-1RQsDK7msRifh9OnYREGT4bIu/I=\",\"dev\":true},\"fast-levenshtein\":{\"version\":\"2.0.6\",\"resolved\":\"https://registry.npmjs.org/fast-levenshtein/-/fast-levenshtein-2.0.6.tgz\",\"integrity\":\"sha1-PYpcZog6FqMMqGQ+hR8Zuqd5eRc=\",\"dev\":true},\"figures\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/figures/-/figures-2.0.0.tgz\",\"integrity\":\"sha1-OrGi0qYsi/tDGgyUy3l6L84nyWI=\",\"dev\":true,\"requires\":{\"escape-string-regexp\":\"^1.0.5\"}},\"file-entry-cache\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/file-entry-cache/-/file-entry-cache-2.0.0.tgz\",\"integrity\":\"sha1-w5KZDD5oR4PYOLjISkXYoEhFg2E=\",\"dev\":true,\"requires\":{\"flat-cache\":\"^1.2.1\",\"object-assign\":\"^4.0.1\"}},\"find-cache-dir\":{\"version\":\"2.1.0\",\"resolved\":\"https://registry.npmjs.org/find-cache-dir/-/find-cache-dir-2.1.0.tgz\",\"integrity\":\"sha512-Tq6PixE0w/VMFfCgbONnkiQIVol/JJL7nRMi20fqzA4NRs9AfeqMGeRdPi3wIhYkxjeBaWh2rxwapn5Tu3IqOQ==\",\"dev\":true,\"requires\":{\"commondir\":\"^1.0.1\",\"make-dir\":\"^2.0.0\",\"pkg-dir\":\"^3.0.0\"}},\"find-up\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/find-up/-/find-up-3.0.0.tgz\",\"integrity\":\"sha512-1yD6RmLI1XBfxugvORwlck6f75tYL+iR0jqwsOrOxMZyGYqUuDhJ0l4AXdO1iX/FTs9cBAMEk1gWSEx1kSbylg==\",\"dev\":true,\"requires\":{\"locate-path\":\"^3.0.0\"}},\"flat-cache\":{\"version\":\"1.3.4\",\"resolved\":\"https://registry.npmjs.org/flat-cache/-/flat-cache-1.3.4.tgz\",\"integrity\":\"sha512-VwyB3Lkgacfik2vhqR4uv2rvebqmDvFu4jlN/C1RzWoJEo8I7z4Q404oiqYCkq41mni8EzQnm95emU9seckwtg==\",\"dev\":true,\"requires\":{\"circular-json\":\"^0.3.1\",\"graceful-fs\":\"^4.1.2\",\"rimraf\":\"~2.6.2\",\"write\":\"^0.2.1\"}},\"foreground-child\":{\"version\":\"1.5.6\",\"resolved\":\"https://registry.npmjs.org/foreground-child/-/foreground-child-1.5.6.tgz\",\"integrity\":\"sha1-T9ca0t/elnibmApcCilZN8svXOk=\",\"dev\":true,\"requires\":{\"cross-spawn\":\"^4\",\"signal-exit\":\"^3.0.0\"},\"dependencies\":{\"cross-spawn\":{\"version\":\"4.0.2\",\"resolved\":\"https://registry.npmjs.org/cross-spawn/-/cross-spawn-4.0.2.tgz\",\"integrity\":\"sha1-e5JHYhwjrf3ThWAEqCPL45dCTUE=\",\"dev\":true,\"requires\":{\"lru-cache\":\"^4.0.1\",\"which\":\"^1.2.9\"}}}},\"forever-agent\":{\"version\":\"0.6.1\",\"resolved\":\"https://registry.npmjs.org/forever-agent/-/forever-agent-0.6.1.tgz\",\"integrity\":\"sha1-+8cfDEGt6zf5bFd60e1C2P2sypE=\",\"dev\":true},\"form-data\":{\"version\":\"2.3.3\",\"resolved\":\"https://registry.npmjs.org/form-data/-/form-data-2.3.3.tgz\",\"integrity\":\"sha512-1lLKB2Mu3aGP1Q/2eCOx0fNbRMe7XdwktwOruhfqqd0rIJWwN4Dh+E3hrPSlDCXnSR7UtZ1N38rVXm+6+MEhJQ==\",\"dev\":true,\"requires\":{\"asynckit\":\"^0.4.0\",\"combined-stream\":\"^1.0.6\",\"mime-types\":\"^2.1.12\"}},\"fs.realpath\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/fs.realpath/-/fs.realpath-1.0.0.tgz\",\"integrity\":\"sha1-FQStJSMVjKpA20onh8sBQRmU6k8=\",\"dev\":true},\"functional-red-black-tree\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/functional-red-black-tree/-/functional-red-black-tree-1.0.1.tgz\",\"integrity\":\"sha1-GwqzvVU7Kg1jmdKcDj6gslIHgyc=\",\"dev\":true},\"get-caller-file\":{\"version\":\"2.0.5\",\"resolved\":\"https://registry.npmjs.org/get-caller-file/-/get-caller-file-2.0.5.tgz\",\"integrity\":\"sha512-DyFP3BM/3YHTQOCUL/w0OZHR0lpKeGrxotcHWcqNEdnltqFwXVfhEBQ94eIo34AfQpo0rGki4cyIiftY06h2Fg==\",\"dev\":true},\"get-func-name\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/get-func-name/-/get-func-name-2.0.0.tgz\",\"integrity\":\"sha1-6td0q+5y4gQJQzoGY2YCPdaIekE=\",\"dev\":true},\"getpass\":{\"version\":\"0.1.7\",\"resolved\":\"https://registry.npmjs.org/getpass/-/getpass-0.1.7.tgz\",\"integrity\":\"sha1-Xv+OPmhNVprkyysSgmBOi6YhSfo=\",\"dev\":true,\"requires\":{\"assert-plus\":\"^1.0.0\"}},\"glob\":{\"version\":\"7.1.4\",\"resolved\":\"https://registry.npmjs.org/glob/-/glob-7.1.4.tgz\",\"integrity\":\"sha512-hkLPepehmnKk41pUGm3sYxoFs/umurYfYJCerbXEyFIWcAzvpipAgVkBqqT9RBKMGjnq6kMuyYwha6csxbiM1A==\",\"dev\":true,\"requires\":{\"fs.realpath\":\"^1.0.0\",\"inflight\":\"^1.0.4\",\"inherits\":\"2\",\"minimatch\":\"^3.0.4\",\"once\":\"^1.3.0\",\"path-is-absolute\":\"^1.0.0\"}},\"globals\":{\"version\":\"11.12.0\",\"resolved\":\"https://registry.npmjs.org/globals/-/globals-11.12.0.tgz\",\"integrity\":\"sha512-WOBp/EEGUiIsJSp7wcv/y6MO+lV9UoncWqxuFfm8eBwzWNgyfBd6Gz+IeKQ9jCmyhoH99g15M3T+QaVHFjizVA==\",\"dev\":true},\"graceful-fs\":{\"version\":\"4.2.0\",\"resolved\":\"https://registry.npmjs.org/graceful-fs/-/graceful-fs-4.2.0.tgz\",\"integrity\":\"sha512-jpSvDPV4Cq/bgtpndIWbI5hmYxhQGHPC4d4cqBPb4DLniCfhJokdXhwhaDuLBGLQdvvRum/UiX6ECVIPvDXqdg==\",\"dev\":true},\"growl\":{\"version\":\"1.10.5\",\"resolved\":\"https://registry.npmjs.org/growl/-/growl-1.10.5.tgz\",\"integrity\":\"sha512-qBr4OuELkhPenW6goKVXiv47US3clb3/IbuWF9KNKEijAy9oeHxU9IgzjvJhHkUzhaj7rOUD7+YGWqUjLp5oSA==\",\"dev\":true},\"handlebars\":{\"version\":\"4.1.2\",\"resolved\":\"https://registry.npmjs.org/handlebars/-/handlebars-4.1.2.tgz\",\"integrity\":\"sha512-nvfrjqvt9xQ8Z/w0ijewdD/vvWDTOweBUm96NTr66Wfvo1mJenBLwcYmPs3TIBP5ruzYGD7Hx/DaM9RmhroGPw==\",\"dev\":true,\"requires\":{\"neo-async\":\"^2.6.0\",\"optimist\":\"^0.6.1\",\"source-map\":\"^0.6.1\",\"uglify-js\":\"^3.1.4\"},\"dependencies\":{\"source-map\":{\"version\":\"0.6.1\",\"resolved\":\"https://registry.npmjs.org/source-map/-/source-map-0.6.1.tgz\",\"integrity\":\"sha512-UjgapumWlbMhkBgzT7Ykc5YXUT46F0iKu8SGXq0bcwP5dz/h0Plj6enJqjz1Zbq2l5WaqYnrVbwWOWMyF3F47g==\",\"dev\":true}}},\"har-schema\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/har-schema/-/har-schema-2.0.0.tgz\",\"integrity\":\"sha1-qUwiJOvKwEeCoNkDVSHyRzW37JI=\",\"dev\":true},\"har-validator\":{\"version\":\"5.1.3\",\"resolved\":\"https://registry.npmjs.org/har-validator/-/har-validator-5.1.3.tgz\",\"integrity\":\"sha512-sNvOCzEQNr/qrvJgc3UG/kD4QtlHycrzwS+6mfTrrSq97BvaYcPZZI1ZSqGSPR73Cxn4LKTD4PttRwfU7jWq5g==\",\"dev\":true,\"requires\":{\"ajv\":\"^6.5.5\",\"har-schema\":\"^2.0.0\"}},\"has-ansi\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/has-ansi/-/has-ansi-2.0.0.tgz\",\"integrity\":\"sha1-NPUEnOHs3ysGSa8+8k5F7TVBbZE=\",\"dev\":true,\"requires\":{\"ansi-regex\":\"^2.0.0\"}},\"has-flag\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/has-flag/-/has-flag-3.0.0.tgz\",\"integrity\":\"sha1-tdRU3CGZriJWmfNGfloH87lVuv0=\",\"dev\":true},\"hasha\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/hasha/-/hasha-3.0.0.tgz\",\"integrity\":\"sha1-UqMvq4Vp1BymmmH/GiFPjrfIvTk=\",\"dev\":true,\"requires\":{\"is-stream\":\"^1.0.1\"}},\"he\":{\"version\":\"1.1.1\",\"resolved\":\"https://registry.npmjs.org/he/-/he-1.1.1.tgz\",\"integrity\":\"sha1-k0EP0hsAlzUVH4howvJx80J+I/0=\",\"dev\":true},\"hosted-git-info\":{\"version\":\"2.7.1\",\"resolved\":\"https://registry.npmjs.org/hosted-git-info/-/hosted-git-info-2.7.1.tgz\",\"integrity\":\"sha512-7T/BxH19zbcCTa8XkMlbK5lTo1WtgkFi3GvdWEyNuc4Vex7/9Dqbnpsf4JMydcfj9HCg4zUWFTL3Za6lapg5/w==\",\"dev\":true},\"http-signature\":{\"version\":\"1.2.0\",\"resolved\":\"https://registry.npmjs.org/http-signature/-/http-signature-1.2.0.tgz\",\"integrity\":\"sha1-muzZJRFHcvPZW2WmCruPfBj7rOE=\",\"dev\":true,\"requires\":{\"assert-plus\":\"^1.0.0\",\"jsprim\":\"^1.2.2\",\"sshpk\":\"^1.7.0\"}},\"iconv-lite\":{\"version\":\"0.4.24\",\"resolved\":\"https://registry.npmjs.org/iconv-lite/-/iconv-lite-0.4.24.tgz\",\"integrity\":\"sha512-v3MXnZAcvnywkTUEZomIActle7RXXeedOR31wwl7VlyoXO4Qi9arvSenNQWne1TcRwhCL1HwLI21bEqdpj8/rA==\",\"dev\":true,\"requires\":{\"safer-buffer\":\">= 2.1.2 < 3\"}},\"ignore\":{\"version\":\"3.3.10\",\"resolved\":\"https://registry.npmjs.org/ignore/-/ignore-3.3.10.tgz\",\"integrity\":\"sha512-Pgs951kaMm5GXP7MOvxERINe3gsaVjUWFm+UZPSq9xYriQAksyhg0csnS0KXSNRD5NmNdapXEpjxG49+AKh/ug==\",\"dev\":true},\"imurmurhash\":{\"version\":\"0.1.4\",\"resolved\":\"https://registry.npmjs.org/imurmurhash/-/imurmurhash-0.1.4.tgz\",\"integrity\":\"sha1-khi5srkoojixPcT7a21XbyMUU+o=\",\"dev\":true},\"inflight\":{\"version\":\"1.0.6\",\"resolved\":\"https://registry.npmjs.org/inflight/-/inflight-1.0.6.tgz\",\"integrity\":\"sha1-Sb1jMdfQLQwJvJEKEHW6gWW1bfk=\",\"dev\":true,\"requires\":{\"once\":\"^1.3.0\",\"wrappy\":\"1\"}},\"inherits\":{\"version\":\"2.0.4\",\"resolved\":\"https://registry.npmjs.org/inherits/-/inherits-2.0.4.tgz\",\"integrity\":\"sha512-k/vGaX4/Yla3WzyMCvTQOXYeIHvqOKtnqBduzTHpzpQZzAskKMhZ2K+EnBiSM9zGSoIFeMpXKxa4dYeZIQqewQ==\",\"dev\":true},\"inquirer\":{\"version\":\"3.3.0\",\"resolved\":\"https://registry.npmjs.org/inquirer/-/inquirer-3.3.0.tgz\",\"integrity\":\"sha512-h+xtnyk4EwKvFWHrUYsWErEVR+igKtLdchu+o0Z1RL7VU/jVMFbYir2bp6bAj8efFNxWqHX0dIss6fJQ+/+qeQ==\",\"dev\":true,\"requires\":{\"ansi-escapes\":\"^3.0.0\",\"chalk\":\"^2.0.0\",\"cli-cursor\":\"^2.1.0\",\"cli-width\":\"^2.0.0\",\"external-editor\":\"^2.0.4\",\"figures\":\"^2.0.0\",\"lodash\":\"^4.3.0\",\"mute-stream\":\"0.0.7\",\"run-async\":\"^2.2.0\",\"rx-lite\":\"^4.0.8\",\"rx-lite-aggregates\":\"^4.0.8\",\"string-width\":\"^2.1.0\",\"strip-ansi\":\"^4.0.0\",\"through\":\"^2.3.6\"}},\"is-arrayish\":{\"version\":\"0.2.1\",\"resolved\":\"https://registry.npmjs.org/is-arrayish/-/is-arrayish-0.2.1.tgz\",\"integrity\":\"sha1-d8mYQFJ6qOyxqLppe4BkWnqSap0=\",\"dev\":true},\"is-fullwidth-code-point\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/is-fullwidth-code-point/-/is-fullwidth-code-point-2.0.0.tgz\",\"integrity\":\"sha1-o7MKXE8ZkYMWeqq5O+764937ZU8=\",\"dev\":true},\"is-promise\":{\"version\":\"2.1.0\",\"resolved\":\"https://registry.npmjs.org/is-promise/-/is-promise-2.1.0.tgz\",\"integrity\":\"sha1-eaKp7OfwlugPNtKy87wWwf9L8/o=\",\"dev\":true},\"is-resolvable\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/is-resolvable/-/is-resolvable-1.1.0.tgz\",\"integrity\":\"sha512-qgDYXFSR5WvEfuS5dMj6oTMEbrrSaM0CrFk2Yiq/gXnBvD9pMa2jGXxyhGLfvhZpuMZe18CJpFxAt3CRs42NMg==\",\"dev\":true},\"is-stream\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/is-stream/-/is-stream-1.1.0.tgz\",\"integrity\":\"sha1-EtSj3U5o4Lec6428hBc66A2RykQ=\",\"dev\":true},\"is-typedarray\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/is-typedarray/-/is-typedarray-1.0.0.tgz\",\"integrity\":\"sha1-5HnICFjfDBsR3dppQPlgEfzaSpo=\",\"dev\":true},\"isarray\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/isarray/-/isarray-1.0.0.tgz\",\"integrity\":\"sha1-u5NdSFgsuhaMBoNJV6VKPgcSTxE=\",\"dev\":true},\"isexe\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/isexe/-/isexe-2.0.0.tgz\",\"integrity\":\"sha1-6PvzdNxVb/iUehDcsFctYz8s+hA=\",\"dev\":true},\"isstream\":{\"version\":\"0.1.2\",\"resolved\":\"https://registry.npmjs.org/isstream/-/isstream-0.1.2.tgz\",\"integrity\":\"sha1-R+Y/evVa+m+S4VAOaQ64uFKcCZo=\",\"dev\":true},\"istanbul-lib-coverage\":{\"version\":\"2.0.5\",\"resolved\":\"https://registry.npmjs.org/istanbul-lib-coverage/-/istanbul-lib-coverage-2.0.5.tgz\",\"integrity\":\"sha512-8aXznuEPCJvGnMSRft4udDRDtb1V3pkQkMMI5LI+6HuQz5oQ4J2UFn1H82raA3qJtyOLkkwVqICBQkjnGtn5mA==\",\"dev\":true},\"istanbul-lib-hook\":{\"version\":\"2.0.7\",\"resolved\":\"https://registry.npmjs.org/istanbul-lib-hook/-/istanbul-lib-hook-2.0.7.tgz\",\"integrity\":\"sha512-vrRztU9VRRFDyC+aklfLoeXyNdTfga2EI3udDGn4cZ6fpSXpHLV9X6CHvfoMCPtggg8zvDDmC4b9xfu0z6/llA==\",\"dev\":true,\"requires\":{\"append-transform\":\"^1.0.0\"}},\"istanbul-lib-instrument\":{\"version\":\"3.3.0\",\"resolved\":\"https://registry.npmjs.org/istanbul-lib-instrument/-/istanbul-lib-instrument-3.3.0.tgz\",\"integrity\":\"sha512-5nnIN4vo5xQZHdXno/YDXJ0G+I3dAm4XgzfSVTPLQpj/zAV2dV6Juy0yaf10/zrJOJeHoN3fraFe+XRq2bFVZA==\",\"dev\":true,\"requires\":{\"@babel/generator\":\"^7.4.0\",\"@babel/parser\":\"^7.4.3\",\"@babel/template\":\"^7.4.0\",\"@babel/traverse\":\"^7.4.3\",\"@babel/types\":\"^7.4.0\",\"istanbul-lib-coverage\":\"^2.0.5\",\"semver\":\"^6.0.0\"},\"dependencies\":{\"semver\":{\"version\":\"6.3.0\",\"resolved\":\"https://registry.npmjs.org/semver/-/semver-6.3.0.tgz\",\"integrity\":\"sha512-b39TBaTSfV6yBrapU89p5fKekE2m/NwnDocOVruQFS1/veMgdzuPcnOM34M6CwxW8jH/lxEa5rBoDeUwu5HHTw==\",\"dev\":true}}},\"istanbul-lib-report\":{\"version\":\"2.0.8\",\"resolved\":\"https://registry.npmjs.org/istanbul-lib-report/-/istanbul-lib-report-2.0.8.tgz\",\"integrity\":\"sha512-fHBeG573EIihhAblwgxrSenp0Dby6tJMFR/HvlerBsrCTD5bkUuoNtn3gVh29ZCS824cGGBPn7Sg7cNk+2xUsQ==\",\"dev\":true,\"requires\":{\"istanbul-lib-coverage\":\"^2.0.5\",\"make-dir\":\"^2.1.0\",\"supports-color\":\"^6.1.0\"},\"dependencies\":{\"supports-color\":{\"version\":\"6.1.0\",\"resolved\":\"https://registry.npmjs.org/supports-color/-/supports-color-6.1.0.tgz\",\"integrity\":\"sha512-qe1jfm1Mg7Nq/NSh6XE24gPXROEVsWHxC1LIx//XNlD9iw7YZQGjZNjYN7xGaEG6iKdA8EtNFW6R0gjnVXp+wQ==\",\"dev\":true,\"requires\":{\"has-flag\":\"^3.0.0\"}}}},\"istanbul-lib-source-maps\":{\"version\":\"3.0.6\",\"resolved\":\"https://registry.npmjs.org/istanbul-lib-source-maps/-/istanbul-lib-source-maps-3.0.6.tgz\",\"integrity\":\"sha512-R47KzMtDJH6X4/YW9XTx+jrLnZnscW4VpNN+1PViSYTejLVPWv7oov+Duf8YQSPyVRUvueQqz1TcsC6mooZTXw==\",\"dev\":true,\"requires\":{\"debug\":\"^4.1.1\",\"istanbul-lib-coverage\":\"^2.0.5\",\"make-dir\":\"^2.1.0\",\"rimraf\":\"^2.6.3\",\"source-map\":\"^0.6.1\"},\"dependencies\":{\"source-map\":{\"version\":\"0.6.1\",\"resolved\":\"https://registry.npmjs.org/source-map/-/source-map-0.6.1.tgz\",\"integrity\":\"sha512-UjgapumWlbMhkBgzT7Ykc5YXUT46F0iKu8SGXq0bcwP5dz/h0Plj6enJqjz1Zbq2l5WaqYnrVbwWOWMyF3F47g==\",\"dev\":true}}},\"istanbul-reports\":{\"version\":\"2.2.6\",\"resolved\":\"https://registry.npmjs.org/istanbul-reports/-/istanbul-reports-2.2.6.tgz\",\"integrity\":\"sha512-SKi4rnMyLBKe0Jy2uUdx28h8oG7ph2PPuQPvIAh31d+Ci+lSiEu4C+h3oBPuJ9+mPKhOyW0M8gY4U5NM1WLeXA==\",\"dev\":true,\"requires\":{\"handlebars\":\"^4.1.2\"}},\"js-tokens\":{\"version\":\"3.0.2\",\"resolved\":\"https://registry.npmjs.org/js-tokens/-/js-tokens-3.0.2.tgz\",\"integrity\":\"sha1-mGbfOVECEw449/mWvOtlRDIJwls=\",\"dev\":true},\"js-yaml\":{\"version\":\"3.13.1\",\"resolved\":\"https://registry.npmjs.org/js-yaml/-/js-yaml-3.13.1.tgz\",\"integrity\":\"sha512-YfbcO7jXDdyj0DGxYVSlSeQNHbD7XPWvrVWeVUujrQEoZzWJIRrCPoyk6kL6IAjAG2IolMK4T0hNUe0HOUs5Jw==\",\"dev\":true,\"requires\":{\"argparse\":\"^1.0.7\",\"esprima\":\"^4.0.0\"}},\"jsbn\":{\"version\":\"0.1.1\",\"resolved\":\"https://registry.npmjs.org/jsbn/-/jsbn-0.1.1.tgz\",\"integrity\":\"sha1-peZUwuWi3rXyAdls77yoDA7y9RM=\",\"dev\":true},\"jsesc\":{\"version\":\"2.5.2\",\"resolved\":\"https://registry.npmjs.org/jsesc/-/jsesc-2.5.2.tgz\",\"integrity\":\"sha512-OYu7XEzjkCQ3C5Ps3QIZsQfNpqoJyZZA99wd9aWd05NCtC5pWOkShK2mkL6HXQR6/Cy2lbNdPlZBpuQHXE63gA==\",\"dev\":true},\"json-parse-better-errors\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/json-parse-better-errors/-/json-parse-better-errors-1.0.2.tgz\",\"integrity\":\"sha512-mrqyZKfX5EhL7hvqcV6WG1yYjnjeuYDzDhhcAAUrq8Po85NBQBJP+ZDUT75qZQ98IkUoBqdkExkukOU7Ts2wrw==\",\"dev\":true},\"json-schema\":{\"version\":\"0.2.3\",\"resolved\":\"https://registry.npmjs.org/json-schema/-/json-schema-0.2.3.tgz\",\"integrity\":\"sha1-tIDIkuWaLwWVTOcnvT8qTogvnhM=\",\"dev\":true},\"json-schema-traverse\":{\"version\":\"0.4.1\",\"resolved\":\"https://registry.npmjs.org/json-schema-traverse/-/json-schema-traverse-0.4.1.tgz\",\"integrity\":\"sha512-xbbCH5dCYU5T8LcEhhuh7HJ88HXuW3qsI3Y0zOZFKfZEHcpWiHU/Jxzk629Brsab/mMiHQti9wMP+845RPe3Vg==\",\"dev\":true},\"json-stable-stringify-without-jsonify\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/json-stable-stringify-without-jsonify/-/json-stable-stringify-without-jsonify-1.0.1.tgz\",\"integrity\":\"sha1-nbe1lJatPzz+8wp1FC0tkwrXJlE=\",\"dev\":true},\"json-stringify-safe\":{\"version\":\"5.0.1\",\"resolved\":\"https://registry.npmjs.org/json-stringify-safe/-/json-stringify-safe-5.0.1.tgz\",\"integrity\":\"sha1-Epai1Y/UXxmg9s4B1lcB4sc1tus=\",\"dev\":true},\"jsprim\":{\"version\":\"1.4.1\",\"resolved\":\"https://registry.npmjs.org/jsprim/-/jsprim-1.4.1.tgz\",\"integrity\":\"sha1-MT5mvB5cwG5Di8G3SZwuXFastqI=\",\"dev\":true,\"requires\":{\"assert-plus\":\"1.0.0\",\"extsprintf\":\"1.3.0\",\"json-schema\":\"0.2.3\",\"verror\":\"1.10.0\"}},\"lcov-parse\":{\"version\":\"0.0.10\",\"resolved\":\"https://registry.npmjs.org/lcov-parse/-/lcov-parse-0.0.10.tgz\",\"integrity\":\"sha1-GwuP+ayceIklBYK3C3ExXZ2m2aM=\",\"dev\":true},\"levn\":{\"version\":\"0.3.0\",\"resolved\":\"https://registry.npmjs.org/levn/-/levn-0.3.0.tgz\",\"integrity\":\"sha1-OwmSTt+fCDwEkP3UwLxEIeBHZO4=\",\"dev\":true,\"requires\":{\"prelude-ls\":\"~1.1.2\",\"type-check\":\"~0.3.2\"}},\"load-json-file\":{\"version\":\"4.0.0\",\"resolved\":\"https://registry.npmjs.org/load-json-file/-/load-json-file-4.0.0.tgz\",\"integrity\":\"sha1-L19Fq5HjMhYjT9U62rZo607AmTs=\",\"dev\":true,\"requires\":{\"graceful-fs\":\"^4.1.2\",\"parse-json\":\"^4.0.0\",\"pify\":\"^3.0.0\",\"strip-bom\":\"^3.0.0\"},\"dependencies\":{\"pify\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/pify/-/pify-3.0.0.tgz\",\"integrity\":\"sha1-5aSs0sEB/fPZpNB/DbxNtJ3SgXY=\",\"dev\":true}}},\"locate-path\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/locate-path/-/locate-path-3.0.0.tgz\",\"integrity\":\"sha512-7AO748wWnIhNqAuaty2ZWHkQHRSNfPVIsPIfwEOWO22AmaoVrWavlOcMR5nzTLNYvp36X220/maaRsrec1G65A==\",\"dev\":true,\"requires\":{\"p-locate\":\"^3.0.0\",\"path-exists\":\"^3.0.0\"}},\"lodash\":{\"version\":\"4.17.15\",\"resolved\":\"https://registry.npmjs.org/lodash/-/lodash-4.17.15.tgz\",\"integrity\":\"sha512-8xOcRHvCjnocdS5cpwXQXVzmmh5e5+saE2QGoeQmbKmRS6J3VQppPOIt0MnmE+4xlZoumy0GPG0D0MVIQbNA1A==\",\"dev\":true},\"lodash.flattendeep\":{\"version\":\"4.4.0\",\"resolved\":\"https://registry.npmjs.org/lodash.flattendeep/-/lodash.flattendeep-4.4.0.tgz\",\"integrity\":\"sha1-+wMJF/hqMTTlvJvsDWngAT3f7bI=\",\"dev\":true},\"lodash.isplainobject\":{\"version\":\"4.0.6\",\"resolved\":\"https://registry.npmjs.org/lodash.isplainobject/-/lodash.isplainobject-4.0.6.tgz\",\"integrity\":\"sha1-fFJqUtibRcRcxpC4gWO+BJf1UMs=\"},\"log-driver\":{\"version\":\"1.2.7\",\"resolved\":\"https://registry.npmjs.org/log-driver/-/log-driver-1.2.7.tgz\",\"integrity\":\"sha512-U7KCmLdqsGHBLeWqYlFA0V0Sl6P08EE1ZrmA9cxjUE0WVqT9qnyVDPz1kzpFEP0jdJuFnasWIfSd7fsaNXkpbg==\",\"dev\":true},\"lru-cache\":{\"version\":\"4.1.5\",\"resolved\":\"https://registry.npmjs.org/lru-cache/-/lru-cache-4.1.5.tgz\",\"integrity\":\"sha512-sWZlbEP2OsHNkXrMl5GYk/jKk70MBng6UU4YI/qGDYbgf6YbP4EvmqISbXCoJiRKs+1bSpFHVgQxvJ17F2li5g==\",\"dev\":true,\"requires\":{\"pseudomap\":\"^1.0.2\",\"yallist\":\"^2.1.2\"}},\"make-dir\":{\"version\":\"2.1.0\",\"resolved\":\"https://registry.npmjs.org/make-dir/-/make-dir-2.1.0.tgz\",\"integrity\":\"sha512-LS9X+dc8KLxXCb8dni79fLIIUA5VyZoyjSMCwTluaXA0o27cCK0bhXkpgw+sTXVpPy/lSO57ilRixqk0vDmtRA==\",\"dev\":true,\"requires\":{\"pify\":\"^4.0.1\",\"semver\":\"^5.6.0\"}},\"merge-source-map\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/merge-source-map/-/merge-source-map-1.1.0.tgz\",\"integrity\":\"sha512-Qkcp7P2ygktpMPh2mCQZaf3jhN6D3Z/qVZHSdWvQ+2Ef5HgRAPBO57A77+ENm0CPx2+1Ce/MYKi3ymqdfuqibw==\",\"dev\":true,\"requires\":{\"source-map\":\"^0.6.1\"},\"dependencies\":{\"source-map\":{\"version\":\"0.6.1\",\"resolved\":\"https://registry.npmjs.org/source-map/-/source-map-0.6.1.tgz\",\"integrity\":\"sha512-UjgapumWlbMhkBgzT7Ykc5YXUT46F0iKu8SGXq0bcwP5dz/h0Plj6enJqjz1Zbq2l5WaqYnrVbwWOWMyF3F47g==\",\"dev\":true}}},\"mime-db\":{\"version\":\"1.40.0\",\"resolved\":\"https://registry.npmjs.org/mime-db/-/mime-db-1.40.0.tgz\",\"integrity\":\"sha512-jYdeOMPy9vnxEqFRRo6ZvTZ8d9oPb+k18PKoYNYUe2stVEBPPwsln/qWzdbmaIvnhZ9v2P+CuecK+fpUfsV2mA==\",\"dev\":true},\"mime-types\":{\"version\":\"2.1.24\",\"resolved\":\"https://registry.npmjs.org/mime-types/-/mime-types-2.1.24.tgz\",\"integrity\":\"sha512-WaFHS3MCl5fapm3oLxU4eYDw77IQM2ACcxQ9RIxfaC3ooc6PFuBMGZZsYpvoXS5D5QTWPieo1jjLdAm3TBP3cQ==\",\"dev\":true,\"requires\":{\"mime-db\":\"1.40.0\"}},\"mimic-fn\":{\"version\":\"1.2.0\",\"resolved\":\"https://registry.npmjs.org/mimic-fn/-/mimic-fn-1.2.0.tgz\",\"integrity\":\"sha512-jf84uxzwiuiIVKiOLpfYk7N46TSy8ubTonmneY9vrpHNAnp0QBt2BxWV9dO3/j+BoVAb+a5G6YDPW3M5HOdMWQ==\",\"dev\":true},\"minimatch\":{\"version\":\"3.0.4\",\"resolved\":\"https://registry.npmjs.org/minimatch/-/minimatch-3.0.4.tgz\",\"integrity\":\"sha512-yJHVQEhyqPLUTgt9B83PXu6W3rx4MvvHvSUvToogpwoGDOUQ+yDrR0HRot+yOCdCO7u4hX3pWft6kWBBcqh0UA==\",\"dev\":true,\"requires\":{\"brace-expansion\":\"^1.1.7\"}},\"minimist\":{\"version\":\"1.2.0\",\"resolved\":\"https://registry.npmjs.org/minimist/-/minimist-1.2.0.tgz\",\"integrity\":\"sha1-o1AIsg9BOD7sH7kU9M1d95omQoQ=\",\"dev\":true},\"mkdirp\":{\"version\":\"0.5.1\",\"resolved\":\"https://registry.npmjs.org/mkdirp/-/mkdirp-0.5.1.tgz\",\"integrity\":\"sha1-MAV0OOrGz3+MR2fzhkjWaX11yQM=\",\"dev\":true,\"requires\":{\"minimist\":\"0.0.8\"},\"dependencies\":{\"minimist\":{\"version\":\"0.0.8\",\"resolved\":\"https://registry.npmjs.org/minimist/-/minimist-0.0.8.tgz\",\"integrity\":\"sha1-hX/Kv8M5fSYluCKCYuhqp6ARsF0=\",\"dev\":true}}},\"mocha\":{\"version\":\"5.0.5\",\"resolved\":\"https://registry.npmjs.org/mocha/-/mocha-5.0.5.tgz\",\"integrity\":\"sha512-3MM3UjZ5p8EJrYpG7s+29HAI9G7sTzKEe4+w37Dg0QP7qL4XGsV+Q2xet2cE37AqdgN1OtYQB6Vl98YiPV3PgA==\",\"dev\":true,\"requires\":{\"browser-stdout\":\"1.3.1\",\"commander\":\"2.11.0\",\"debug\":\"3.1.0\",\"diff\":\"3.5.0\",\"escape-string-regexp\":\"1.0.5\",\"glob\":\"7.1.2\",\"growl\":\"1.10.3\",\"he\":\"1.1.1\",\"mkdirp\":\"0.5.1\",\"supports-color\":\"4.4.0\"},\"dependencies\":{\"debug\":{\"version\":\"3.1.0\",\"resolved\":\"https://registry.npmjs.org/debug/-/debug-3.1.0.tgz\",\"integrity\":\"sha512-OX8XqP7/1a9cqkxYw2yXss15f26NKWBpDXQd0/uK/KPqdQhxbPa994hnzjcE2VqQpDslf55723cKPUOGSmMY3g==\",\"dev\":true,\"requires\":{\"ms\":\"2.0.0\"}},\"glob\":{\"version\":\"7.1.2\",\"resolved\":\"https://registry.npmjs.org/glob/-/glob-7.1.2.tgz\",\"integrity\":\"sha512-MJTUg1kjuLeQCJ+ccE4Vpa6kKVXkPYJ2mOCQyUuKLcLQsdrMCpBPUi8qVE6+YuaJkozeA9NusTAw3hLr8Xe5EQ==\",\"dev\":true,\"requires\":{\"fs.realpath\":\"^1.0.0\",\"inflight\":\"^1.0.4\",\"inherits\":\"2\",\"minimatch\":\"^3.0.4\",\"once\":\"^1.3.0\",\"path-is-absolute\":\"^1.0.0\"}},\"growl\":{\"version\":\"1.10.3\",\"resolved\":\"https://registry.npmjs.org/growl/-/growl-1.10.3.tgz\",\"integrity\":\"sha512-hKlsbA5Vu3xsh1Cg3J7jSmX/WaW6A5oBeqzM88oNbCRQFz+zUaXm6yxS4RVytp1scBoJzSYl4YAEOQIt6O8V1Q==\",\"dev\":true},\"has-flag\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/has-flag/-/has-flag-2.0.0.tgz\",\"integrity\":\"sha1-6CB68cx7MNRGzHC3NLXovhj4jVE=\",\"dev\":true},\"ms\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/ms/-/ms-2.0.0.tgz\",\"integrity\":\"sha1-VgiurfwAvmwpAd9fmGF4jeDVl8g=\",\"dev\":true},\"supports-color\":{\"version\":\"4.4.0\",\"resolved\":\"https://registry.npmjs.org/supports-color/-/supports-color-4.4.0.tgz\",\"integrity\":\"sha512-rKC3+DyXWgK0ZLKwmRsrkyHVZAjNkfzeehuFWdGGcqGDTZFH73+RH6S/RDAAxl9GusSjZSUWYLmT9N5pzXFOXQ==\",\"dev\":true,\"requires\":{\"has-flag\":\"^2.0.0\"}}}},\"ms\":{\"version\":\"2.1.2\",\"resolved\":\"https://registry.npmjs.org/ms/-/ms-2.1.2.tgz\",\"integrity\":\"sha512-sGkPx+VjMtmA6MX27oA4FBFELFCZZ4S4XqeGOXCv68tT+jb3vk/RyaKWP0PTKyWtmLSM0b+adUTEvbs1PEaH2w==\",\"dev\":true},\"mute-stream\":{\"version\":\"0.0.7\",\"resolved\":\"https://registry.npmjs.org/mute-stream/-/mute-stream-0.0.7.tgz\",\"integrity\":\"sha1-MHXOk7whuPq0PhvE2n6BFe0ee6s=\",\"dev\":true},\"natural-compare\":{\"version\":\"1.4.0\",\"resolved\":\"https://registry.npmjs.org/natural-compare/-/natural-compare-1.4.0.tgz\",\"integrity\":\"sha1-Sr6/7tdUHywnrPspvbvRXI1bpPc=\",\"dev\":true},\"neo-async\":{\"version\":\"2.6.1\",\"resolved\":\"https://registry.npmjs.org/neo-async/-/neo-async-2.6.1.tgz\",\"integrity\":\"sha512-iyam8fBuCUpWeKPGpaNMetEocMt364qkCsfL9JuhjXX6dRnguRVOfk2GZaDpPjcOKiiXCPINZC1GczQ7iTq3Zw==\",\"dev\":true},\"nested-error-stacks\":{\"version\":\"2.1.0\",\"resolved\":\"https://registry.npmjs.org/nested-error-stacks/-/nested-error-stacks-2.1.0.tgz\",\"integrity\":\"sha512-AO81vsIO1k1sM4Zrd6Hu7regmJN1NSiAja10gc4bX3F0wd+9rQmcuHQaHVQCYIEC8iFXnE+mavh23GOt7wBgug==\",\"dev\":true},\"nock\":{\"version\":\"9.6.1\",\"resolved\":\"https://registry.npmjs.org/nock/-/nock-9.6.1.tgz\",\"integrity\":\"sha512-EDgl/WgNQ0C1BZZlASOQkQdE6tAWXJi8QQlugqzN64JJkvZ7ILijZuG24r4vCC7yOfnm6HKpne5AGExLGCeBWg==\",\"dev\":true,\"requires\":{\"chai\":\"^4.1.2\",\"debug\":\"^3.1.0\",\"deep-equal\":\"^1.0.0\",\"json-stringify-safe\":\"^5.0.1\",\"lodash\":\"^4.17.5\",\"mkdirp\":\"^0.5.0\",\"propagate\":\"^1.0.0\",\"qs\":\"^6.5.1\",\"semver\":\"^5.5.0\"},\"dependencies\":{\"debug\":{\"version\":\"3.2.6\",\"resolved\":\"https://registry.npmjs.org/debug/-/debug-3.2.6.tgz\",\"integrity\":\"sha512-mel+jf7nrtEl5Pn1Qx46zARXKDpBbvzezse7p7LqINmdoIk8PYP5SySaxEmYv6TZ0JyEKA1hsCId6DIhgITtWQ==\",\"dev\":true,\"requires\":{\"ms\":\"^2.1.1\"}}}},\"normalize-package-data\":{\"version\":\"2.5.0\",\"resolved\":\"https://registry.npmjs.org/normalize-package-data/-/normalize-package-data-2.5.0.tgz\",\"integrity\":\"sha512-/5CMN3T0R4XTj4DcGaexo+roZSdSFW/0AOOTROrjxzCG1wrWXEsGbRKevjlIL+ZDE4sZlJr5ED4YW0yqmkK+eA==\",\"dev\":true,\"requires\":{\"hosted-git-info\":\"^2.1.4\",\"resolve\":\"^1.10.0\",\"semver\":\"2 || 3 || 4 || 5\",\"validate-npm-package-license\":\"^3.0.1\"}},\"nyc\":{\"version\":\"14.1.1\",\"resolved\":\"https://registry.npmjs.org/nyc/-/nyc-14.1.1.tgz\",\"integrity\":\"sha512-OI0vm6ZGUnoGZv/tLdZ2esSVzDwUC88SNs+6JoSOMVxA+gKMB8Tk7jBwgemLx4O40lhhvZCVw1C+OYLOBOPXWw==\",\"dev\":true,\"requires\":{\"archy\":\"^1.0.0\",\"caching-transform\":\"^3.0.2\",\"convert-source-map\":\"^1.6.0\",\"cp-file\":\"^6.2.0\",\"find-cache-dir\":\"^2.1.0\",\"find-up\":\"^3.0.0\",\"foreground-child\":\"^1.5.6\",\"glob\":\"^7.1.3\",\"istanbul-lib-coverage\":\"^2.0.5\",\"istanbul-lib-hook\":\"^2.0.7\",\"istanbul-lib-instrument\":\"^3.3.0\",\"istanbul-lib-report\":\"^2.0.8\",\"istanbul-lib-source-maps\":\"^3.0.6\",\"istanbul-reports\":\"^2.2.4\",\"js-yaml\":\"^3.13.1\",\"make-dir\":\"^2.1.0\",\"merge-source-map\":\"^1.1.0\",\"resolve-from\":\"^4.0.0\",\"rimraf\":\"^2.6.3\",\"signal-exit\":\"^3.0.2\",\"spawn-wrap\":\"^1.4.2\",\"test-exclude\":\"^5.2.3\",\"uuid\":\"^3.3.2\",\"yargs\":\"^13.2.2\",\"yargs-parser\":\"^13.0.0\"},\"dependencies\":{\"resolve-from\":{\"version\":\"4.0.0\",\"resolved\":\"https://registry.npmjs.org/resolve-from/-/resolve-from-4.0.0.tgz\",\"integrity\":\"sha512-pb/MYmXstAkysRFx8piNI1tGFNQIFA3vkE3Gq4EuA1dF6gHp/+vgZqsCGJapvy8N3Q+4o7FwvquPJcnZ7RYy4g==\",\"dev\":true}}},\"oauth-sign\":{\"version\":\"0.9.0\",\"resolved\":\"https://registry.npmjs.org/oauth-sign/-/oauth-sign-0.9.0.tgz\",\"integrity\":\"sha512-fexhUFFPTGV8ybAtSIGbV6gOkSv8UtRbDBnAyLQw4QPKkgNlsH2ByPGtMUqdWkos6YCRmAqViwgZrJc/mRDzZQ==\",\"dev\":true},\"object-assign\":{\"version\":\"4.1.1\",\"resolved\":\"https://registry.npmjs.org/object-assign/-/object-assign-4.1.1.tgz\",\"integrity\":\"sha1-IQmtx5ZYh8/AXLvUQsrIv7s2CGM=\",\"dev\":true},\"once\":{\"version\":\"1.4.0\",\"resolved\":\"https://registry.npmjs.org/once/-/once-1.4.0.tgz\",\"integrity\":\"sha1-WDsap3WWHUsROsF9nFC6753Xa9E=\",\"dev\":true,\"requires\":{\"wrappy\":\"1\"}},\"onetime\":{\"version\":\"2.0.1\",\"resolved\":\"https://registry.npmjs.org/onetime/-/onetime-2.0.1.tgz\",\"integrity\":\"sha1-BnQoIw/WdEOyeUsiu6UotoZ5YtQ=\",\"dev\":true,\"requires\":{\"mimic-fn\":\"^1.0.0\"}},\"optimist\":{\"version\":\"0.6.1\",\"resolved\":\"https://registry.npmjs.org/optimist/-/optimist-0.6.1.tgz\",\"integrity\":\"sha1-2j6nRob6IaGaERwybpDrFaAZZoY=\",\"dev\":true,\"requires\":{\"minimist\":\"~0.0.1\",\"wordwrap\":\"~0.0.2\"},\"dependencies\":{\"minimist\":{\"version\":\"0.0.10\",\"resolved\":\"https://registry.npmjs.org/minimist/-/minimist-0.0.10.tgz\",\"integrity\":\"sha1-3j+YVD2/lggr5IrRoMfNqDYwHc8=\",\"dev\":true},\"wordwrap\":{\"version\":\"0.0.3\",\"resolved\":\"https://registry.npmjs.org/wordwrap/-/wordwrap-0.0.3.tgz\",\"integrity\":\"sha1-o9XabNXAvAAI03I0u68b7WMFkQc=\",\"dev\":true}}},\"optionator\":{\"version\":\"0.8.2\",\"resolved\":\"https://registry.npmjs.org/optionator/-/optionator-0.8.2.tgz\",\"integrity\":\"sha1-NkxeQJ0/TWMB1sC0wFu6UBgK62Q=\",\"dev\":true,\"requires\":{\"deep-is\":\"~0.1.3\",\"fast-levenshtein\":\"~2.0.4\",\"levn\":\"~0.3.0\",\"prelude-ls\":\"~1.1.2\",\"type-check\":\"~0.3.2\",\"wordwrap\":\"~1.0.0\"}},\"os-homedir\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/os-homedir/-/os-homedir-1.0.2.tgz\",\"integrity\":\"sha1-/7xJiDNuDoM94MFox+8VISGqf7M=\",\"dev\":true},\"os-tmpdir\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/os-tmpdir/-/os-tmpdir-1.0.2.tgz\",\"integrity\":\"sha1-u+Z0BseaqFxc/sdm/lc0VV36EnQ=\",\"dev\":true},\"p-limit\":{\"version\":\"2.2.0\",\"resolved\":\"https://registry.npmjs.org/p-limit/-/p-limit-2.2.0.tgz\",\"integrity\":\"sha512-pZbTJpoUsCzV48Mc9Nh51VbwO0X9cuPFE8gYwx9BTCt9SF8/b7Zljd2fVgOxhIF/HDTKgpVzs+GPhyKfjLLFRQ==\",\"dev\":true,\"requires\":{\"p-try\":\"^2.0.0\"}},\"p-locate\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/p-locate/-/p-locate-3.0.0.tgz\",\"integrity\":\"sha512-x+12w/To+4GFfgJhBEpiDcLozRJGegY+Ei7/z0tSLkMmxGZNybVMSfWj9aJn8Z5Fc7dBUNJOOVgPv2H7IwulSQ==\",\"dev\":true,\"requires\":{\"p-limit\":\"^2.0.0\"}},\"p-try\":{\"version\":\"2.2.0\",\"resolved\":\"https://registry.npmjs.org/p-try/-/p-try-2.2.0.tgz\",\"integrity\":\"sha512-R4nPAVTAU0B9D35/Gk3uJf/7XYbQcyohSKdvAxIRSNghFl4e71hVoGnBNQz9cWaXxO2I10KTC+3jMdvvoKw6dQ==\",\"dev\":true},\"package-hash\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/package-hash/-/package-hash-3.0.0.tgz\",\"integrity\":\"sha512-lOtmukMDVvtkL84rJHI7dpTYq+0rli8N2wlnqUcBuDWCfVhRUfOmnR9SsoHFMLpACvEV60dX7rd0rFaYDZI+FA==\",\"dev\":true,\"requires\":{\"graceful-fs\":\"^4.1.15\",\"hasha\":\"^3.0.0\",\"lodash.flattendeep\":\"^4.4.0\",\"release-zalgo\":\"^1.0.0\"}},\"parse-json\":{\"version\":\"4.0.0\",\"resolved\":\"https://registry.npmjs.org/parse-json/-/parse-json-4.0.0.tgz\",\"integrity\":\"sha1-vjX1Qlvh9/bHRxhPmKeIy5lHfuA=\",\"dev\":true,\"requires\":{\"error-ex\":\"^1.3.1\",\"json-parse-better-errors\":\"^1.0.1\"}},\"path-exists\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/path-exists/-/path-exists-3.0.0.tgz\",\"integrity\":\"sha1-zg6+ql94yxiSXqfYENe1mwEP1RU=\",\"dev\":true},\"path-is-absolute\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/path-is-absolute/-/path-is-absolute-1.0.1.tgz\",\"integrity\":\"sha1-F0uSaHNVNP+8es5r9TpanhtcX18=\",\"dev\":true},\"path-is-inside\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/path-is-inside/-/path-is-inside-1.0.2.tgz\",\"integrity\":\"sha1-NlQX3t5EQw0cEa9hAn+s8HS9/FM=\",\"dev\":true},\"path-parse\":{\"version\":\"1.0.6\",\"resolved\":\"https://registry.npmjs.org/path-parse/-/path-parse-1.0.6.tgz\",\"integrity\":\"sha512-GSmOT2EbHrINBf9SR7CDELwlJ8AENk3Qn7OikK4nFYAu3Ote2+JYNVvkpAEQm3/TLNEJFD/xZJjzyxg3KBWOzw==\",\"dev\":true},\"path-type\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/path-type/-/path-type-3.0.0.tgz\",\"integrity\":\"sha512-T2ZUsdZFHgA3u4e5PfPbjd7HDDpxPnQb5jN0SrDsjNSuVXHJqtwTnWqG0B1jZrgmJ/7lj1EmVIByWt1gxGkWvg==\",\"dev\":true,\"requires\":{\"pify\":\"^3.0.0\"},\"dependencies\":{\"pify\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/pify/-/pify-3.0.0.tgz\",\"integrity\":\"sha1-5aSs0sEB/fPZpNB/DbxNtJ3SgXY=\",\"dev\":true}}},\"pathval\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/pathval/-/pathval-1.1.0.tgz\",\"integrity\":\"sha1-uULm1L3mUwBe9rcTYd74cn0GReA=\",\"dev\":true},\"performance-now\":{\"version\":\"2.1.0\",\"resolved\":\"https://registry.npmjs.org/performance-now/-/performance-now-2.1.0.tgz\",\"integrity\":\"sha1-Ywn04OX6kT7BxpMHrjZLSzd8nns=\",\"dev\":true},\"pify\":{\"version\":\"4.0.1\",\"resolved\":\"https://registry.npmjs.org/pify/-/pify-4.0.1.tgz\",\"integrity\":\"sha512-uB80kBFb/tfd68bVleG9T5GGsGPjJrLAUpR5PZIrhBnIaRTQRjqdJSsIKkOP6OAIFbj7GOrcudc5pNjZ+geV2g==\",\"dev\":true},\"pkg-dir\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/pkg-dir/-/pkg-dir-3.0.0.tgz\",\"integrity\":\"sha512-/E57AYkoeQ25qkxMj5PBOVgF8Kiu/h7cYS30Z5+R7WaiCCBfLq58ZI/dSeaEKb9WVJV5n/03QwrN3IeWIFllvw==\",\"dev\":true,\"requires\":{\"find-up\":\"^3.0.0\"}},\"pluralize\":{\"version\":\"7.0.0\",\"resolved\":\"https://registry.npmjs.org/pluralize/-/pluralize-7.0.0.tgz\",\"integrity\":\"sha512-ARhBOdzS3e41FbkW/XWrTEtukqqLoK5+Z/4UeDaLuSW+39JPeFgs4gCGqsrJHVZX0fUrx//4OF0K1CUGwlIFow==\",\"dev\":true},\"prelude-ls\":{\"version\":\"1.1.2\",\"resolved\":\"https://registry.npmjs.org/prelude-ls/-/prelude-ls-1.1.2.tgz\",\"integrity\":\"sha1-IZMqVJ9eUv/ZqCf1cOBL5iqX2lQ=\",\"dev\":true},\"process-nextick-args\":{\"version\":\"2.0.1\",\"resolved\":\"https://registry.npmjs.org/process-nextick-args/-/process-nextick-args-2.0.1.tgz\",\"integrity\":\"sha512-3ouUOpQhtgrbOa17J7+uxOTpITYWaGP7/AhoR3+A+/1e9skrzelGi/dXzEYyvbxubEF6Wn2ypscTKiKJFFn1ag==\",\"dev\":true},\"progress\":{\"version\":\"2.0.3\",\"resolved\":\"https://registry.npmjs.org/progress/-/progress-2.0.3.tgz\",\"integrity\":\"sha512-7PiHtLll5LdnKIMw100I+8xJXR5gW2QwWYkT6iJva0bXitZKa/XMrSbdmg3r2Xnaidz9Qumd0VPaMrZlF9V9sA==\",\"dev\":true},\"propagate\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/propagate/-/propagate-1.0.0.tgz\",\"integrity\":\"sha1-AMLa7t2iDofjeCs0Stuhzd1q1wk=\",\"dev\":true},\"pseudomap\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/pseudomap/-/pseudomap-1.0.2.tgz\",\"integrity\":\"sha1-8FKijacOYYkX7wqKw0wa5aaChrM=\",\"dev\":true},\"psl\":{\"version\":\"1.2.0\",\"resolved\":\"https://registry.npmjs.org/psl/-/psl-1.2.0.tgz\",\"integrity\":\"sha512-GEn74ZffufCmkDDLNcl3uuyF/aSD6exEyh1v/ZSdAomB82t6G9hzJVRx0jBmLDW+VfZqks3aScmMw9DszwUalA==\",\"dev\":true},\"punycode\":{\"version\":\"2.1.1\",\"resolved\":\"https://registry.npmjs.org/punycode/-/punycode-2.1.1.tgz\",\"integrity\":\"sha512-XRsRjdf+j5ml+y/6GKHPZbrF/8p2Yga0JPtdqTIY2Xe5ohJPD9saDJJLPvp9+NSBprVvevdXZybnj2cv8OEd0A==\",\"dev\":true},\"qs\":{\"version\":\"6.7.0\",\"resolved\":\"https://registry.npmjs.org/qs/-/qs-6.7.0.tgz\",\"integrity\":\"sha512-VCdBRNFTX1fyE7Nb6FYoURo/SPe62QCaAyzJvUjwRaIsc+NePBEniHlvxFmmX56+HZphIGtV0XeCirBtpDrTyQ==\"},\"read-pkg\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/read-pkg/-/read-pkg-3.0.0.tgz\",\"integrity\":\"sha1-nLxoaXj+5l0WwA4rGcI3/Pbjg4k=\",\"dev\":true,\"requires\":{\"load-json-file\":\"^4.0.0\",\"normalize-package-data\":\"^2.3.2\",\"path-type\":\"^3.0.0\"}},\"read-pkg-up\":{\"version\":\"4.0.0\",\"resolved\":\"https://registry.npmjs.org/read-pkg-up/-/read-pkg-up-4.0.0.tgz\",\"integrity\":\"sha512-6etQSH7nJGsK0RbG/2TeDzZFa8shjQ1um+SwQQ5cwKy0dhSXdOncEhb1CPpvQG4h7FyOV6EB6YlV0yJvZQNAkA==\",\"dev\":true,\"requires\":{\"find-up\":\"^3.0.0\",\"read-pkg\":\"^3.0.0\"}},\"readable-stream\":{\"version\":\"2.3.6\",\"resolved\":\"https://registry.npmjs.org/readable-stream/-/readable-stream-2.3.6.tgz\",\"integrity\":\"sha512-tQtKA9WIAhBF3+VLAseyMqZeBjW0AHJoxOtYqSUZNJxauErmLbVm2FW1y+J/YA9dUrAC39ITejlZWhVIwawkKw==\",\"dev\":true,\"requires\":{\"core-util-is\":\"~1.0.0\",\"inherits\":\"~2.0.3\",\"isarray\":\"~1.0.0\",\"process-nextick-args\":\"~2.0.0\",\"safe-buffer\":\"~5.1.1\",\"string_decoder\":\"~1.1.1\",\"util-deprecate\":\"~1.0.1\"},\"dependencies\":{\"safe-buffer\":{\"version\":\"5.1.2\",\"resolved\":\"https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.1.2.tgz\",\"integrity\":\"sha512-Gd2UZBJDkXlY7GbJxfsE8/nvKkUEU1G38c1siN6QP6a9PT9MmHB8GnpscSmMJSoF8LOIrt8ud/wPtojys4G6+g==\",\"dev\":true}}},\"regexpp\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/regexpp/-/regexpp-1.1.0.tgz\",\"integrity\":\"sha512-LOPw8FpgdQF9etWMaAfG/WRthIdXJGYp4mJ2Jgn/2lpkbod9jPn0t9UqN7AxBOKNfzRbYyVfgc7Vk4t/MpnXgw==\",\"dev\":true},\"release-zalgo\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/release-zalgo/-/release-zalgo-1.0.0.tgz\",\"integrity\":\"sha1-CXALflB0Mpc5Mw5TXFqQ+2eFFzA=\",\"dev\":true,\"requires\":{\"es6-error\":\"^4.0.1\"}},\"request\":{\"version\":\"2.88.0\",\"resolved\":\"https://registry.npmjs.org/request/-/request-2.88.0.tgz\",\"integrity\":\"sha512-NAqBSrijGLZdM0WZNsInLJpkJokL72XYjUpnB0iwsRgxh7dB6COrHnTBNwN0E+lHDAJzu7kLAkDeY08z2/A0hg==\",\"dev\":true,\"requires\":{\"aws-sign2\":\"~0.7.0\",\"aws4\":\"^1.8.0\",\"caseless\":\"~0.12.0\",\"combined-stream\":\"~1.0.6\",\"extend\":\"~3.0.2\",\"forever-agent\":\"~0.6.1\",\"form-data\":\"~2.3.2\",\"har-validator\":\"~5.1.0\",\"http-signature\":\"~1.2.0\",\"is-typedarray\":\"~1.0.0\",\"isstream\":\"~0.1.2\",\"json-stringify-safe\":\"~5.0.1\",\"mime-types\":\"~2.1.19\",\"oauth-sign\":\"~0.9.0\",\"performance-now\":\"^2.1.0\",\"qs\":\"~6.5.2\",\"safe-buffer\":\"^5.1.2\",\"tough-cookie\":\"~2.4.3\",\"tunnel-agent\":\"^0.6.0\",\"uuid\":\"^3.3.2\"},\"dependencies\":{\"qs\":{\"version\":\"6.5.2\",\"resolved\":\"https://registry.npmjs.org/qs/-/qs-6.5.2.tgz\",\"integrity\":\"sha512-N5ZAX4/LxJmF+7wN74pUD6qAh9/wnvdQcjq9TZjevvXzSUo7bfmw91saqMjzGS2xq91/odN2dW/WOl7qQHNDGA==\",\"dev\":true}}},\"require-directory\":{\"version\":\"2.1.1\",\"resolved\":\"https://registry.npmjs.org/require-directory/-/require-directory-2.1.1.tgz\",\"integrity\":\"sha1-jGStX9MNqxyXbiNE/+f3kqam30I=\",\"dev\":true},\"require-main-filename\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/require-main-filename/-/require-main-filename-2.0.0.tgz\",\"integrity\":\"sha512-NKN5kMDylKuldxYLSUfrbo5Tuzh4hd+2E8NPPX02mZtn1VuREQToYe/ZdlJy+J3uCpfaiGF05e7B8W0iXbQHmg==\",\"dev\":true},\"require-uncached\":{\"version\":\"1.0.3\",\"resolved\":\"https://registry.npmjs.org/require-uncached/-/require-uncached-1.0.3.tgz\",\"integrity\":\"sha1-Tg1W1slmL9MeQwEcS5WqSZVUIdM=\",\"dev\":true,\"requires\":{\"caller-path\":\"^0.1.0\",\"resolve-from\":\"^1.0.0\"}},\"resolve\":{\"version\":\"1.11.1\",\"resolved\":\"https://registry.npmjs.org/resolve/-/resolve-1.11.1.tgz\",\"integrity\":\"sha512-vIpgF6wfuJOZI7KKKSP+HmiKggadPQAdsp5HiC1mvqnfp0gF1vdwgBWZIdrVft9pgqoMFQN+R7BSWZiBxx+BBw==\",\"dev\":true,\"requires\":{\"path-parse\":\"^1.0.6\"}},\"resolve-from\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/resolve-from/-/resolve-from-1.0.1.tgz\",\"integrity\":\"sha1-Jsv+k10a7uq7Kbw/5a6wHpPUQiY=\",\"dev\":true},\"restore-cursor\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/restore-cursor/-/restore-cursor-2.0.0.tgz\",\"integrity\":\"sha1-n37ih/gv0ybU/RYpI9YhKe7g368=\",\"dev\":true,\"requires\":{\"onetime\":\"^2.0.0\",\"signal-exit\":\"^3.0.2\"}},\"rimraf\":{\"version\":\"2.6.3\",\"resolved\":\"https://registry.npmjs.org/rimraf/-/rimraf-2.6.3.tgz\",\"integrity\":\"sha512-mwqeW5XsA2qAejG46gYdENaxXjx9onRNCfn7L0duuP4hCuTIi/QO7PDK07KJfp1d+izWPrzEJDcSqBa0OZQriA==\",\"dev\":true,\"requires\":{\"glob\":\"^7.1.3\"}},\"run-async\":{\"version\":\"2.3.0\",\"resolved\":\"https://registry.npmjs.org/run-async/-/run-async-2.3.0.tgz\",\"integrity\":\"sha1-A3GrSuC91yDUFm19/aZP96RFpsA=\",\"dev\":true,\"requires\":{\"is-promise\":\"^2.1.0\"}},\"rx-lite\":{\"version\":\"4.0.8\",\"resolved\":\"https://registry.npmjs.org/rx-lite/-/rx-lite-4.0.8.tgz\",\"integrity\":\"sha1-Cx4Rr4vESDbwSmQH6S2kJGe3lEQ=\",\"dev\":true},\"rx-lite-aggregates\":{\"version\":\"4.0.8\",\"resolved\":\"https://registry.npmjs.org/rx-lite-aggregates/-/rx-lite-aggregates-4.0.8.tgz\",\"integrity\":\"sha1-dTuHqJoRyVRnxKwWJsTvxOBcZ74=\",\"dev\":true,\"requires\":{\"rx-lite\":\"*\"}},\"safe-buffer\":{\"version\":\"5.2.0\",\"resolved\":\"https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.2.0.tgz\",\"integrity\":\"sha512-fZEwUGbVl7kouZs1jCdMLdt95hdIv0ZeHg6L7qPeciMZhZ+/gdesW4wgTARkrFWEpspjEATAzUGPG8N2jJiwbg==\"},\"safer-buffer\":{\"version\":\"2.1.2\",\"resolved\":\"https://registry.npmjs.org/safer-buffer/-/safer-buffer-2.1.2.tgz\",\"integrity\":\"sha512-YZo3K82SD7Riyi0E1EQPojLz7kpepnSQI9IyPbHHg1XXXevb5dJI7tpyN2ADxGcQbHG7vcyRHk0cbwqcQriUtg==\",\"dev\":true},\"semver\":{\"version\":\"5.7.0\",\"resolved\":\"https://registry.npmjs.org/semver/-/semver-5.7.0.tgz\",\"integrity\":\"sha512-Ya52jSX2u7QKghxeoFGpLwCtGlt7j0oY9DYb5apt9nPlJ42ID+ulTXESnt/qAQcoSERyZ5sl3LDIOw0nAn/5DA==\",\"dev\":true},\"set-blocking\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/set-blocking/-/set-blocking-2.0.0.tgz\",\"integrity\":\"sha1-BF+XgtARrppoA93TgrJDkrPYkPc=\",\"dev\":true},\"shebang-command\":{\"version\":\"1.2.0\",\"resolved\":\"https://registry.npmjs.org/shebang-command/-/shebang-command-1.2.0.tgz\",\"integrity\":\"sha1-RKrGW2lbAzmJaMOfNj/uXer98eo=\",\"dev\":true,\"requires\":{\"shebang-regex\":\"^1.0.0\"}},\"shebang-regex\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/shebang-regex/-/shebang-regex-1.0.0.tgz\",\"integrity\":\"sha1-2kL0l0DAtC2yypcoVxyxkMmO/qM=\",\"dev\":true},\"signal-exit\":{\"version\":\"3.0.2\",\"resolved\":\"https://registry.npmjs.org/signal-exit/-/signal-exit-3.0.2.tgz\",\"integrity\":\"sha1-tf3AjxKH6hF4Yo5BXiUTK3NkbG0=\",\"dev\":true},\"slice-ansi\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/slice-ansi/-/slice-ansi-1.0.0.tgz\",\"integrity\":\"sha512-POqxBK6Lb3q6s047D/XsDVNPnF9Dl8JSaqe9h9lURl0OdNqy/ujDrOiIHtsqXMGbWWTIomRzAMaTyawAU//Reg==\",\"dev\":true,\"requires\":{\"is-fullwidth-code-point\":\"^2.0.0\"}},\"source-map\":{\"version\":\"0.5.7\",\"resolved\":\"https://registry.npmjs.org/source-map/-/source-map-0.5.7.tgz\",\"integrity\":\"sha1-igOdLRAh0i0eoUyA2OpGi6LvP8w=\",\"dev\":true},\"spawn-wrap\":{\"version\":\"1.4.2\",\"resolved\":\"https://registry.npmjs.org/spawn-wrap/-/spawn-wrap-1.4.2.tgz\",\"integrity\":\"sha512-vMwR3OmmDhnxCVxM8M+xO/FtIp6Ju/mNaDfCMMW7FDcLRTPFWUswec4LXJHTJE2hwTI9O0YBfygu4DalFl7Ylg==\",\"dev\":true,\"requires\":{\"foreground-child\":\"^1.5.6\",\"mkdirp\":\"^0.5.0\",\"os-homedir\":\"^1.0.1\",\"rimraf\":\"^2.6.2\",\"signal-exit\":\"^3.0.2\",\"which\":\"^1.3.0\"}},\"spdx-correct\":{\"version\":\"3.1.0\",\"resolved\":\"https://registry.npmjs.org/spdx-correct/-/spdx-correct-3.1.0.tgz\",\"integrity\":\"sha512-lr2EZCctC2BNR7j7WzJ2FpDznxky1sjfxvvYEyzxNyb6lZXHODmEoJeFu4JupYlkfha1KZpJyoqiJ7pgA1qq8Q==\",\"dev\":true,\"requires\":{\"spdx-expression-parse\":\"^3.0.0\",\"spdx-license-ids\":\"^3.0.0\"}},\"spdx-exceptions\":{\"version\":\"2.2.0\",\"resolved\":\"https://registry.npmjs.org/spdx-exceptions/-/spdx-exceptions-2.2.0.tgz\",\"integrity\":\"sha512-2XQACfElKi9SlVb1CYadKDXvoajPgBVPn/gOQLrTvHdElaVhr7ZEbqJaRnJLVNeaI4cMEAgVCeBMKF6MWRDCRA==\",\"dev\":true},\"spdx-expression-parse\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/spdx-expression-parse/-/spdx-expression-parse-3.0.0.tgz\",\"integrity\":\"sha512-Yg6D3XpRD4kkOmTpdgbUiEJFKghJH03fiC1OPll5h/0sO6neh2jqRDVHOQ4o/LMea0tgCkbMgea5ip/e+MkWyg==\",\"dev\":true,\"requires\":{\"spdx-exceptions\":\"^2.1.0\",\"spdx-license-ids\":\"^3.0.0\"}},\"spdx-license-ids\":{\"version\":\"3.0.5\",\"resolved\":\"https://registry.npmjs.org/spdx-license-ids/-/spdx-license-ids-3.0.5.tgz\",\"integrity\":\"sha512-J+FWzZoynJEXGphVIS+XEh3kFSjZX/1i9gFBaWQcB+/tmpe2qUsSBABpcxqxnAxFdiUFEgAX1bjYGQvIZmoz9Q==\",\"dev\":true},\"sprintf-js\":{\"version\":\"1.0.3\",\"resolved\":\"https://registry.npmjs.org/sprintf-js/-/sprintf-js-1.0.3.tgz\",\"integrity\":\"sha1-BOaSb2YolTVPPdAVIDYzuFcpfiw=\",\"dev\":true},\"sshpk\":{\"version\":\"1.16.1\",\"resolved\":\"https://registry.npmjs.org/sshpk/-/sshpk-1.16.1.tgz\",\"integrity\":\"sha512-HXXqVUq7+pcKeLqqZj6mHFUMvXtOJt1uoUx09pFW6011inTMxqI8BA8PM95myrIyyKwdnzjdFjLiE6KBPVtJIg==\",\"dev\":true,\"requires\":{\"asn1\":\"~0.2.3\",\"assert-plus\":\"^1.0.0\",\"bcrypt-pbkdf\":\"^1.0.0\",\"dashdash\":\"^1.12.0\",\"ecc-jsbn\":\"~0.1.1\",\"getpass\":\"^0.1.1\",\"jsbn\":\"~0.1.0\",\"safer-buffer\":\"^2.0.2\",\"tweetnacl\":\"~0.14.0\"},\"dependencies\":{\"tweetnacl\":{\"version\":\"0.14.5\",\"resolved\":\"https://registry.npmjs.org/tweetnacl/-/tweetnacl-0.14.5.tgz\",\"integrity\":\"sha1-WuaBd/GS1EViadEIr6k/+HQ/T2Q=\",\"dev\":true}}},\"string-width\":{\"version\":\"2.1.1\",\"resolved\":\"https://registry.npmjs.org/string-width/-/string-width-2.1.1.tgz\",\"integrity\":\"sha512-nOqH59deCq9SRHlxq1Aw85Jnt4w6KvLKqWVik6oA9ZklXLNIOlqg4F2yrT1MVaTjAqvVwdfeZ7w7aCvJD7ugkw==\",\"dev\":true,\"requires\":{\"is-fullwidth-code-point\":\"^2.0.0\",\"strip-ansi\":\"^4.0.0\"}},\"string_decoder\":{\"version\":\"1.1.1\",\"resolved\":\"https://registry.npmjs.org/string_decoder/-/string_decoder-1.1.1.tgz\",\"integrity\":\"sha512-n/ShnvDi6FHbbVfviro+WojiFzv+s8MPMHBczVePfUpDJLwoLT0ht1l4YwBCbi8pJAveEEdnkHyPyTP/mzRfwg==\",\"dev\":true,\"requires\":{\"safe-buffer\":\"~5.1.0\"},\"dependencies\":{\"safe-buffer\":{\"version\":\"5.1.2\",\"resolved\":\"https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.1.2.tgz\",\"integrity\":\"sha512-Gd2UZBJDkXlY7GbJxfsE8/nvKkUEU1G38c1siN6QP6a9PT9MmHB8GnpscSmMJSoF8LOIrt8ud/wPtojys4G6+g==\",\"dev\":true}}},\"strip-ansi\":{\"version\":\"4.0.0\",\"resolved\":\"https://registry.npmjs.org/strip-ansi/-/strip-ansi-4.0.0.tgz\",\"integrity\":\"sha1-qEeQIusaw2iocTibY1JixQXuNo8=\",\"dev\":true,\"requires\":{\"ansi-regex\":\"^3.0.0\"},\"dependencies\":{\"ansi-regex\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/ansi-regex/-/ansi-regex-3.0.0.tgz\",\"integrity\":\"sha1-7QMXwyIGT3lGbAKWa922Bas32Zg=\",\"dev\":true}}},\"strip-bom\":{\"version\":\"3.0.0\",\"resolved\":\"https://registry.npmjs.org/strip-bom/-/strip-bom-3.0.0.tgz\",\"integrity\":\"sha1-IzTBjpx1n3vdVv3vfprj1YjmjtM=\",\"dev\":true},\"strip-json-comments\":{\"version\":\"2.0.1\",\"resolved\":\"https://registry.npmjs.org/strip-json-comments/-/strip-json-comments-2.0.1.tgz\",\"integrity\":\"sha1-PFMZQukIwml8DsNEhYwobHygpgo=\",\"dev\":true},\"supports-color\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/supports-color/-/supports-color-2.0.0.tgz\",\"integrity\":\"sha1-U10EXOa2Nj+kARcIRimZXp3zJMc=\",\"dev\":true},\"table\":{\"version\":\"4.0.2\",\"resolved\":\"https://registry.npmjs.org/table/-/table-4.0.2.tgz\",\"integrity\":\"sha512-UUkEAPdSGxtRpiV9ozJ5cMTtYiqz7Ni1OGqLXRCynrvzdtR1p+cfOWe2RJLwvUG8hNanaSRjecIqwOjqeatDsA==\",\"dev\":true,\"requires\":{\"ajv\":\"^5.2.3\",\"ajv-keywords\":\"^2.1.0\",\"chalk\":\"^2.1.0\",\"lodash\":\"^4.17.4\",\"slice-ansi\":\"1.0.0\",\"string-width\":\"^2.1.1\"},\"dependencies\":{\"ajv\":{\"version\":\"5.5.2\",\"resolved\":\"https://registry.npmjs.org/ajv/-/ajv-5.5.2.tgz\",\"integrity\":\"sha1-c7Xuyj+rZT49P5Qis0GtQiBdyWU=\",\"dev\":true,\"requires\":{\"co\":\"^4.6.0\",\"fast-deep-equal\":\"^1.0.0\",\"fast-json-stable-stringify\":\"^2.0.0\",\"json-schema-traverse\":\"^0.3.0\"}},\"fast-deep-equal\":{\"version\":\"1.1.0\",\"resolved\":\"https://registry.npmjs.org/fast-deep-equal/-/fast-deep-equal-1.1.0.tgz\",\"integrity\":\"sha1-wFNHeBfIa1HaqFPIHgWbcz0CNhQ=\",\"dev\":true},\"json-schema-traverse\":{\"version\":\"0.3.1\",\"resolved\":\"https://registry.npmjs.org/json-schema-traverse/-/json-schema-traverse-0.3.1.tgz\",\"integrity\":\"sha1-NJptRMU6Ud6JtAgFxdXlm0F9M0A=\",\"dev\":true}}},\"test-exclude\":{\"version\":\"5.2.3\",\"resolved\":\"https://registry.npmjs.org/test-exclude/-/test-exclude-5.2.3.tgz\",\"integrity\":\"sha512-M+oxtseCFO3EDtAaGH7iiej3CBkzXqFMbzqYAACdzKui4eZA+pq3tZEwChvOdNfa7xxy8BfbmgJSIr43cC/+2g==\",\"dev\":true,\"requires\":{\"glob\":\"^7.1.3\",\"minimatch\":\"^3.0.4\",\"read-pkg-up\":\"^4.0.0\",\"require-main-filename\":\"^2.0.0\"}},\"text-table\":{\"version\":\"0.2.0\",\"resolved\":\"https://registry.npmjs.org/text-table/-/text-table-0.2.0.tgz\",\"integrity\":\"sha1-f17oI66AUgfACvLfSoTsP8+lcLQ=\",\"dev\":true},\"through\":{\"version\":\"2.3.8\",\"resolved\":\"https://registry.npmjs.org/through/-/through-2.3.8.tgz\",\"integrity\":\"sha1-DdTJ/6q8NXlgsbckEV1+Doai4fU=\",\"dev\":true},\"tmp\":{\"version\":\"0.0.33\",\"resolved\":\"https://registry.npmjs.org/tmp/-/tmp-0.0.33.tgz\",\"integrity\":\"sha512-jRCJlojKnZ3addtTOjdIqoRuPEKBvNXcGYqzO6zWZX8KfKEpnGY5jfggJQ3EjKuu8D4bJRr0y+cYJFmYbImXGw==\",\"dev\":true,\"requires\":{\"os-tmpdir\":\"~1.0.2\"}},\"to-fast-properties\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/to-fast-properties/-/to-fast-properties-2.0.0.tgz\",\"integrity\":\"sha1-3F5pjL0HkmW8c+A3doGk5Og/YW4=\",\"dev\":true},\"tough-cookie\":{\"version\":\"2.4.3\",\"resolved\":\"https://registry.npmjs.org/tough-cookie/-/tough-cookie-2.4.3.tgz\",\"integrity\":\"sha512-Q5srk/4vDM54WJsJio3XNn6K2sCG+CQ8G5Wz6bZhRZoAe/+TxjWB/GlFAnYEbkYVlON9FMk/fE3h2RLpPXo4lQ==\",\"dev\":true,\"requires\":{\"psl\":\"^1.1.24\",\"punycode\":\"^1.4.1\"},\"dependencies\":{\"punycode\":{\"version\":\"1.4.1\",\"resolved\":\"https://registry.npmjs.org/punycode/-/punycode-1.4.1.tgz\",\"integrity\":\"sha1-wNWmOycYgArY4esPpSachN1BhF4=\",\"dev\":true}}},\"trim-right\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/trim-right/-/trim-right-1.0.1.tgz\",\"integrity\":\"sha1-yy4SAwZ+DI3h9hQJS5/kVwTqYAM=\",\"dev\":true},\"tunnel-agent\":{\"version\":\"0.6.0\",\"resolved\":\"https://registry.npmjs.org/tunnel-agent/-/tunnel-agent-0.6.0.tgz\",\"integrity\":\"sha1-J6XeoGs2sEoKmWZ3SykIaPD8QP0=\",\"dev\":true,\"requires\":{\"safe-buffer\":\"^5.0.1\"}},\"tweetnacl\":{\"version\":\"1.0.1\",\"resolved\":\"https://registry.npmjs.org/tweetnacl/-/tweetnacl-1.0.1.tgz\",\"integrity\":\"sha512-kcoMoKTPYnoeS50tzoqjPY3Uv9axeuuFAZY9M/9zFnhoVvRfxz9K29IMPD7jGmt2c8SW7i3gT9WqDl2+nV7p4A==\"},\"type-check\":{\"version\":\"0.3.2\",\"resolved\":\"https://registry.npmjs.org/type-check/-/type-check-0.3.2.tgz\",\"integrity\":\"sha1-WITKtRLPHTVeP7eE8wgEsrUg23I=\",\"dev\":true,\"requires\":{\"prelude-ls\":\"~1.1.2\"}},\"type-detect\":{\"version\":\"4.0.8\",\"resolved\":\"https://registry.npmjs.org/type-detect/-/type-detect-4.0.8.tgz\",\"integrity\":\"sha512-0fr/mIH1dlO+x7TlcMy+bIDqKPsw/70tVyeHW787goQjhmqaZe10uwLujubK9q9Lg6Fiho1KUKDYz0Z7k7g5/g==\",\"dev\":true},\"typedarray\":{\"version\":\"0.0.6\",\"resolved\":\"https://registry.npmjs.org/typedarray/-/typedarray-0.0.6.tgz\",\"integrity\":\"sha1-hnrHTjhkGHsdPUfZlqeOxciDB3c=\",\"dev\":true},\"uglify-js\":{\"version\":\"3.6.0\",\"resolved\":\"https://registry.npmjs.org/uglify-js/-/uglify-js-3.6.0.tgz\",\"integrity\":\"sha512-W+jrUHJr3DXKhrsS7NUVxn3zqMOFn0hL/Ei6v0anCIMoKC93TjcflTagwIHLW7SfMFfiQuktQyFVCFHGUE0+yg==\",\"dev\":true,\"optional\":true,\"requires\":{\"commander\":\"~2.20.0\",\"source-map\":\"~0.6.1\"},\"dependencies\":{\"commander\":{\"version\":\"2.20.0\",\"resolved\":\"https://registry.npmjs.org/commander/-/commander-2.20.0.tgz\",\"integrity\":\"sha512-7j2y+40w61zy6YC2iRNpUe/NwhNyoXrYpHMrSunaMG64nRnaf96zO/KMQR4OyN/UnE5KLyEBnKHd4aG3rskjpQ==\",\"dev\":true,\"optional\":true},\"source-map\":{\"version\":\"0.6.1\",\"resolved\":\"https://registry.npmjs.org/source-map/-/source-map-0.6.1.tgz\",\"integrity\":\"sha512-UjgapumWlbMhkBgzT7Ykc5YXUT46F0iKu8SGXq0bcwP5dz/h0Plj6enJqjz1Zbq2l5WaqYnrVbwWOWMyF3F47g==\",\"dev\":true,\"optional\":true}}},\"uri-js\":{\"version\":\"4.2.2\",\"resolved\":\"https://registry.npmjs.org/uri-js/-/uri-js-4.2.2.tgz\",\"integrity\":\"sha512-KY9Frmirql91X2Qgjry0Wd4Y+YTdrdZheS8TFwvkbLWf/G5KNJDCh6pKL5OZctEW4+0Baa5idK2ZQuELRwPznQ==\",\"dev\":true,\"requires\":{\"punycode\":\"^2.1.0\"}},\"util-deprecate\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/util-deprecate/-/util-deprecate-1.0.2.tgz\",\"integrity\":\"sha1-RQ1Nyfpw3nMnYvvS1KKJgUGaDM8=\",\"dev\":true},\"uuid\":{\"version\":\"3.3.2\",\"resolved\":\"https://registry.npmjs.org/uuid/-/uuid-3.3.2.tgz\",\"integrity\":\"sha512-yXJmeNaw3DnnKAOKJE51sL/ZaYfWJRl1pK9dr19YFCu0ObS231AB1/LbqTKRAQ5kw8A90rA6fr4riOUpTZvQZA==\"},\"validate-npm-package-license\":{\"version\":\"3.0.4\",\"resolved\":\"https://registry.npmjs.org/validate-npm-package-license/-/validate-npm-package-license-3.0.4.tgz\",\"integrity\":\"sha512-DpKm2Ui/xN7/HQKCtpZxoRWBhZ9Z0kqtygG8XCgNQ8ZlDnxuQmWhj566j8fN4Cu3/JmbhsDo7fcAJq4s9h27Ew==\",\"dev\":true,\"requires\":{\"spdx-correct\":\"^3.0.0\",\"spdx-expression-parse\":\"^3.0.0\"}},\"verror\":{\"version\":\"1.10.0\",\"resolved\":\"https://registry.npmjs.org/verror/-/verror-1.10.0.tgz\",\"integrity\":\"sha1-OhBcoXBTr1XW4nDB+CiGguGNpAA=\",\"dev\":true,\"requires\":{\"assert-plus\":\"^1.0.0\",\"core-util-is\":\"1.0.2\",\"extsprintf\":\"^1.2.0\"}},\"which\":{\"version\":\"1.3.1\",\"resolved\":\"https://registry.npmjs.org/which/-/which-1.3.1.tgz\",\"integrity\":\"sha512-HxJdYWq1MTIQbJ3nw0cqssHoTNU267KlrDuGZ1WYlxDStUtKUhOaJmh112/TZmHxxUfuJqPXSOm7tDyas0OSIQ==\",\"dev\":true,\"requires\":{\"isexe\":\"^2.0.0\"}},\"which-module\":{\"version\":\"2.0.0\",\"resolved\":\"https://registry.npmjs.org/which-module/-/which-module-2.0.0.tgz\",\"integrity\":\"sha1-2e8H3Od7mQK4o6j6SzHD4/fm6Ho=\",\"dev\":true},\"wordwrap\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/wordwrap/-/wordwrap-1.0.0.tgz\",\"integrity\":\"sha1-J1hIEIkUVqQXHI0CJkQa3pDLyus=\",\"dev\":true},\"wrap-ansi\":{\"version\":\"5.1.0\",\"resolved\":\"https://registry.npmjs.org/wrap-ansi/-/wrap-ansi-5.1.0.tgz\",\"integrity\":\"sha512-QC1/iN/2/RPVJ5jYK8BGttj5z83LmSKmvbvrXPNCLZSEb32KKVDJDl/MOt2N01qU2H/FkzEa9PKto1BqDjtd7Q==\",\"dev\":true,\"requires\":{\"ansi-styles\":\"^3.2.0\",\"string-width\":\"^3.0.0\",\"strip-ansi\":\"^5.0.0\"},\"dependencies\":{\"ansi-regex\":{\"version\":\"4.1.0\",\"resolved\":\"https://registry.npmjs.org/ansi-regex/-/ansi-regex-4.1.0.tgz\",\"integrity\":\"sha512-1apePfXM1UOSqw0o9IiFAovVz9M5S1Dg+4TrDwfMewQ6p/rmMueb7tWZjQ1rx4Loy1ArBggoqGpfqqdI4rondg==\",\"dev\":true},\"ansi-styles\":{\"version\":\"3.2.1\",\"resolved\":\"https://registry.npmjs.org/ansi-styles/-/ansi-styles-3.2.1.tgz\",\"integrity\":\"sha512-VT0ZI6kZRdTh8YyJw3SMbYm/u+NqfsAxEpWO0Pf9sq8/e94WxxOpPKx9FR1FlyCtOVDNOQ+8ntlqFxiRc+r5qA==\",\"dev\":true,\"requires\":{\"color-convert\":\"^1.9.0\"}},\"string-width\":{\"version\":\"3.1.0\",\"resolved\":\"https://registry.npmjs.org/string-width/-/string-width-3.1.0.tgz\",\"integrity\":\"sha512-vafcv6KjVZKSgz06oM/H6GDBrAtz8vdhQakGjFIvNrHA6y3HCF1CInLy+QLq8dTJPQ1b+KDUqDFctkdRW44e1w==\",\"dev\":true,\"requires\":{\"emoji-regex\":\"^7.0.1\",\"is-fullwidth-code-point\":\"^2.0.0\",\"strip-ansi\":\"^5.1.0\"}},\"strip-ansi\":{\"version\":\"5.2.0\",\"resolved\":\"https://registry.npmjs.org/strip-ansi/-/strip-ansi-5.2.0.tgz\",\"integrity\":\"sha512-DuRs1gKbBqsMKIZlrffwlug8MHkcnpjs5VPmL1PAh+mA30U0DTotfDZ0d2UUsXpPmPmMMJ6W773MaA3J+lbiWA==\",\"dev\":true,\"requires\":{\"ansi-regex\":\"^4.1.0\"}}}},\"wrappy\":{\"version\":\"1.0.2\",\"resolved\":\"https://registry.npmjs.org/wrappy/-/wrappy-1.0.2.tgz\",\"integrity\":\"sha1-tSQ9jz7BqjXxNkYFvA0QNuMKtp8=\",\"dev\":true},\"write\":{\"version\":\"0.2.1\",\"resolved\":\"https://registry.npmjs.org/write/-/write-0.2.1.tgz\",\"integrity\":\"sha1-X8A4KOJkzqP+kUVUdvejxWbLB1c=\",\"dev\":true,\"requires\":{\"mkdirp\":\"^0.5.1\"}},\"write-file-atomic\":{\"version\":\"2.4.3\",\"resolved\":\"https://registry.npmjs.org/write-file-atomic/-/write-file-atomic-2.4.3.tgz\",\"integrity\":\"sha512-GaETH5wwsX+GcnzhPgKcKjJ6M2Cq3/iZp1WyY/X1CSqrW+jVNM9Y7D8EC2sM4ZG/V8wZlSniJnCKWPmBYAucRQ==\",\"dev\":true,\"requires\":{\"graceful-fs\":\"^4.1.11\",\"imurmurhash\":\"^0.1.4\",\"signal-exit\":\"^3.0.2\"}},\"y18n\":{\"version\":\"4.0.0\",\"resolved\":\"https://registry.npmjs.org/y18n/-/y18n-4.0.0.tgz\",\"integrity\":\"sha512-r9S/ZyXu/Xu9q1tYlpsLIsa3EeLXXk0VwlxqTcFRfg9EhMW+17kbt9G0NrgCmhGb5vT2hyhJZLfDGx+7+5Uj/w==\",\"dev\":true},\"yallist\":{\"version\":\"2.1.2\",\"resolved\":\"https://registry.npmjs.org/yallist/-/yallist-2.1.2.tgz\",\"integrity\":\"sha1-HBH5IY8HYImkfdUS+TxmmaaoHVI=\",\"dev\":true},\"yargs\":{\"version\":\"13.3.0\",\"resolved\":\"https://registry.npmjs.org/yargs/-/yargs-13.3.0.tgz\",\"integrity\":\"sha512-2eehun/8ALW8TLoIl7MVaRUrg+yCnenu8B4kBlRxj3GJGDKU1Og7sMXPNm1BYyM1DOJmTZ4YeN/Nwxv+8XJsUA==\",\"dev\":true,\"requires\":{\"cliui\":\"^5.0.0\",\"find-up\":\"^3.0.0\",\"get-caller-file\":\"^2.0.1\",\"require-directory\":\"^2.1.1\",\"require-main-filename\":\"^2.0.0\",\"set-blocking\":\"^2.0.0\",\"string-width\":\"^3.0.0\",\"which-module\":\"^2.0.0\",\"y18n\":\"^4.0.0\",\"yargs-parser\":\"^13.1.1\"},\"dependencies\":{\"ansi-regex\":{\"version\":\"4.1.0\",\"resolved\":\"https://registry.npmjs.org/ansi-regex/-/ansi-regex-4.1.0.tgz\",\"integrity\":\"sha512-1apePfXM1UOSqw0o9IiFAovVz9M5S1Dg+4TrDwfMewQ6p/rmMueb7tWZjQ1rx4Loy1ArBggoqGpfqqdI4rondg==\",\"dev\":true},\"string-width\":{\"version\":\"3.1.0\",\"resolved\":\"https://registry.npmjs.org/string-width/-/string-width-3.1.0.tgz\",\"integrity\":\"sha512-vafcv6KjVZKSgz06oM/H6GDBrAtz8vdhQakGjFIvNrHA6y3HCF1CInLy+QLq8dTJPQ1b+KDUqDFctkdRW44e1w==\",\"dev\":true,\"requires\":{\"emoji-regex\":\"^7.0.1\",\"is-fullwidth-code-point\":\"^2.0.0\",\"strip-ansi\":\"^5.1.0\"}},\"strip-ansi\":{\"version\":\"5.2.0\",\"resolved\":\"https://registry.npmjs.org/strip-ansi/-/strip-ansi-5.2.0.tgz\",\"integrity\":\"sha512-DuRs1gKbBqsMKIZlrffwlug8MHkcnpjs5VPmL1PAh+mA30U0DTotfDZ0d2UUsXpPmPmMMJ6W773MaA3J+lbiWA==\",\"dev\":true,\"requires\":{\"ansi-regex\":\"^4.1.0\"}}}},\"yargs-parser\":{\"version\":\"13.1.1\",\"resolved\":\"https://registry.npmjs.org/yargs-parser/-/yargs-parser-13.1.1.tgz\",\"integrity\":\"sha512-oVAVsHz6uFrg3XQheFII8ESO2ssAf9luWuAd6Wexsu4F3OtIW0o8IribPXYrD4WC24LWtPrJlGy87y5udK+dxQ==\",\"dev\":true,\"requires\":{\"camelcase\":\"^5.0.0\",\"decamelize\":\"^1.2.0\"}}}},\"_spec\":\"telnyx\",\"_where\":\"C:\\\\Users\\\\Jack\\\\Desktop\\\\Telnyx\\\\telnyx-fitness-tutorial\\\\fitness-api\",\"author\":{\"name\":\"Telnyx\",\"email\":\"support@telnyx.com\",\"url\":\"https://www.telnyx.com/\"},\"bugs\":{\"url\":\"https://github.com/team-telnyx/telnyx-node/issues\"},\"bugs:\":\"https://github.com/team-telnyx/telnyx-node/issues\",\"bundleDependencies\":false,\"contributors\":[{\"name\":\"Gabriel Taylor Russ\",\"email\":\"gabriel@telnyx.com\",\"url\":\"http://www.telnyx.com/\"},{\"name\":\"Lucas Rosa\",\"email\":\"lucas@telnyx.com\",\"url\":\"http://www.telnyx.com/\"},{\"name\":\"Rômulo Garofalo\",\"email\":\"romulo@telnyx.com\",\"url\":\"http://www.telnyx.com/\"}],\"dependencies\":{\"lodash.isplainobject\":\"^4.0.6\",\"qs\":\"^6.6.0\",\"safe-buffer\":\"^5.1.1\",\"tweetnacl\":\"^1.0.1\",\"uuid\":\"^3.3.2\"},\"deprecated\":false,\"description\":\"Telnyx API Node SDK\",\"devDependencies\":{\"chai\":\"~4.1.2\",\"chai-as-promised\":\"~7.1.1\",\"coveralls\":\"^3.0.0\",\"debug\":\"^4.1.1\",\"eslint\":\"^4.19.1\",\"eslint-plugin-chai-friendly\":\"^0.4.0\",\"mocha\":\"~5.0.5\",\"nock\":\"^9.0.0\",\"nyc\":\"^14.1.1\"},\"engines\":{\"node\":\"^6 || >=8\"},\"homepage\":\"https://developers.telnyx.com\",\"keywords\":[\"telnyx\",\"sms\",\"sip trunking\",\"phone numbers\",\"api\",\"sdk\"],\"license\":\"MIT\",\"main\":\"lib/telnyx.js\",\"name\":\"telnyx\",\"nyc\":{\"exclude\":[\"testUtils/**/*\",\"test/**/*\",\"lib/TelnyxMethod.basic.js\"]},\"repository\":{\"type\":\"git\",\"url\":\"git://github.com/team-telnyx/telnyx-node.git\"},\"scripts\":{\"clean\":\"rm -rf ./.nyc_output ./node_modules/.cache ./coverage\",\"coveralls\":\"cat coverage/lcov.info | ./node_modules/coveralls/bin/coveralls.js\",\"lint\":\"eslint .\",\"mocha\":\"nyc mocha\",\"release\":\"telnyx-npm-release\",\"report\":\"nyc -r text -r lcov report\",\"test\":\"npm run lint && npm run mocha\"},\"version\":\"1.11.0\"}");

/***/ }),
/* 34 */
/***/ (function(module, exports) {

module.exports = require("child_process");

/***/ }),
/* 35 */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var stringify = __webpack_require__(37);
var parse = __webpack_require__(38);
var formats = __webpack_require__(13);

module.exports = {
    formats: formats,
    parse: parse,
    stringify: stringify
};


/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(12);
var formats = __webpack_require__(13);
var has = Object.prototype.hasOwnProperty;

var arrayPrefixGenerators = {
    brackets: function brackets(prefix) { // eslint-disable-line func-name-matching
        return prefix + '[]';
    },
    comma: 'comma',
    indices: function indices(prefix, key) { // eslint-disable-line func-name-matching
        return prefix + '[' + key + ']';
    },
    repeat: function repeat(prefix) { // eslint-disable-line func-name-matching
        return prefix;
    }
};

var isArray = Array.isArray;
var push = Array.prototype.push;
var pushToArray = function (arr, valueOrArray) {
    push.apply(arr, isArray(valueOrArray) ? valueOrArray : [valueOrArray]);
};

var toISO = Date.prototype.toISOString;

var defaults = {
    addQueryPrefix: false,
    allowDots: false,
    charset: 'utf-8',
    charsetSentinel: false,
    delimiter: '&',
    encode: true,
    encoder: utils.encode,
    encodeValuesOnly: false,
    formatter: formats.formatters[formats['default']],
    // deprecated
    indices: false,
    serializeDate: function serializeDate(date) { // eslint-disable-line func-name-matching
        return toISO.call(date);
    },
    skipNulls: false,
    strictNullHandling: false
};

var stringify = function stringify( // eslint-disable-line func-name-matching
    object,
    prefix,
    generateArrayPrefix,
    strictNullHandling,
    skipNulls,
    encoder,
    filter,
    sort,
    allowDots,
    serializeDate,
    formatter,
    encodeValuesOnly,
    charset
) {
    var obj = object;
    if (typeof filter === 'function') {
        obj = filter(prefix, obj);
    } else if (obj instanceof Date) {
        obj = serializeDate(obj);
    } else if (generateArrayPrefix === 'comma' && isArray(obj)) {
        obj = obj.join(',');
    }

    if (obj === null) {
        if (strictNullHandling) {
            return encoder && !encodeValuesOnly ? encoder(prefix, defaults.encoder, charset) : prefix;
        }

        obj = '';
    }

    if (typeof obj === 'string' || typeof obj === 'number' || typeof obj === 'boolean' || utils.isBuffer(obj)) {
        if (encoder) {
            var keyValue = encodeValuesOnly ? prefix : encoder(prefix, defaults.encoder, charset);
            return [formatter(keyValue) + '=' + formatter(encoder(obj, defaults.encoder, charset))];
        }
        return [formatter(prefix) + '=' + formatter(String(obj))];
    }

    var values = [];

    if (typeof obj === 'undefined') {
        return values;
    }

    var objKeys;
    if (isArray(filter)) {
        objKeys = filter;
    } else {
        var keys = Object.keys(obj);
        objKeys = sort ? keys.sort(sort) : keys;
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (skipNulls && obj[key] === null) {
            continue;
        }

        if (isArray(obj)) {
            pushToArray(values, stringify(
                obj[key],
                typeof generateArrayPrefix === 'function' ? generateArrayPrefix(prefix, key) : prefix,
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly,
                charset
            ));
        } else {
            pushToArray(values, stringify(
                obj[key],
                prefix + (allowDots ? '.' + key : '[' + key + ']'),
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly,
                charset
            ));
        }
    }

    return values;
};

var normalizeStringifyOptions = function normalizeStringifyOptions(opts) {
    if (!opts) {
        return defaults;
    }

    if (opts.encoder !== null && opts.encoder !== undefined && typeof opts.encoder !== 'function') {
        throw new TypeError('Encoder has to be a function.');
    }

    var charset = opts.charset || defaults.charset;
    if (typeof opts.charset !== 'undefined' && opts.charset !== 'utf-8' && opts.charset !== 'iso-8859-1') {
        throw new TypeError('The charset option must be either utf-8, iso-8859-1, or undefined');
    }

    var format = formats['default'];
    if (typeof opts.format !== 'undefined') {
        if (!has.call(formats.formatters, opts.format)) {
            throw new TypeError('Unknown format option provided.');
        }
        format = opts.format;
    }
    var formatter = formats.formatters[format];

    var filter = defaults.filter;
    if (typeof opts.filter === 'function' || isArray(opts.filter)) {
        filter = opts.filter;
    }

    return {
        addQueryPrefix: typeof opts.addQueryPrefix === 'boolean' ? opts.addQueryPrefix : defaults.addQueryPrefix,
        allowDots: typeof opts.allowDots === 'undefined' ? defaults.allowDots : !!opts.allowDots,
        charset: charset,
        charsetSentinel: typeof opts.charsetSentinel === 'boolean' ? opts.charsetSentinel : defaults.charsetSentinel,
        delimiter: typeof opts.delimiter === 'undefined' ? defaults.delimiter : opts.delimiter,
        encode: typeof opts.encode === 'boolean' ? opts.encode : defaults.encode,
        encoder: typeof opts.encoder === 'function' ? opts.encoder : defaults.encoder,
        encodeValuesOnly: typeof opts.encodeValuesOnly === 'boolean' ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
        filter: filter,
        formatter: formatter,
        serializeDate: typeof opts.serializeDate === 'function' ? opts.serializeDate : defaults.serializeDate,
        skipNulls: typeof opts.skipNulls === 'boolean' ? opts.skipNulls : defaults.skipNulls,
        sort: typeof opts.sort === 'function' ? opts.sort : null,
        strictNullHandling: typeof opts.strictNullHandling === 'boolean' ? opts.strictNullHandling : defaults.strictNullHandling
    };
};

module.exports = function (object, opts) {
    var obj = object;
    var options = normalizeStringifyOptions(opts);

    var objKeys;
    var filter;

    if (typeof options.filter === 'function') {
        filter = options.filter;
        obj = filter('', obj);
    } else if (isArray(options.filter)) {
        filter = options.filter;
        objKeys = filter;
    }

    var keys = [];

    if (typeof obj !== 'object' || obj === null) {
        return '';
    }

    var arrayFormat;
    if (opts && opts.arrayFormat in arrayPrefixGenerators) {
        arrayFormat = opts.arrayFormat;
    } else if (opts && 'indices' in opts) {
        arrayFormat = opts.indices ? 'indices' : 'repeat';
    } else {
        arrayFormat = 'indices';
    }

    var generateArrayPrefix = arrayPrefixGenerators[arrayFormat];

    if (!objKeys) {
        objKeys = Object.keys(obj);
    }

    if (options.sort) {
        objKeys.sort(options.sort);
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (options.skipNulls && obj[key] === null) {
            continue;
        }
        pushToArray(keys, stringify(
            obj[key],
            key,
            generateArrayPrefix,
            options.strictNullHandling,
            options.skipNulls,
            options.encode ? options.encoder : null,
            options.filter,
            options.sort,
            options.allowDots,
            options.serializeDate,
            options.formatter,
            options.encodeValuesOnly,
            options.charset
        ));
    }

    var joined = keys.join(options.delimiter);
    var prefix = options.addQueryPrefix === true ? '?' : '';

    if (options.charsetSentinel) {
        if (options.charset === 'iso-8859-1') {
            // encodeURIComponent('&#10003;'), the "numeric entity" representation of a checkmark
            prefix += 'utf8=%26%2310003%3B&';
        } else {
            // encodeURIComponent('✓')
            prefix += 'utf8=%E2%9C%93&';
        }
    }

    return joined.length > 0 ? prefix + joined : '';
};


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(12);

var has = Object.prototype.hasOwnProperty;

var defaults = {
    allowDots: false,
    allowPrototypes: false,
    arrayLimit: 20,
    charset: 'utf-8',
    charsetSentinel: false,
    comma: false,
    decoder: utils.decode,
    delimiter: '&',
    depth: 5,
    ignoreQueryPrefix: false,
    interpretNumericEntities: false,
    parameterLimit: 1000,
    parseArrays: true,
    plainObjects: false,
    strictNullHandling: false
};

var interpretNumericEntities = function (str) {
    return str.replace(/&#(\d+);/g, function ($0, numberStr) {
        return String.fromCharCode(parseInt(numberStr, 10));
    });
};

// This is what browsers will submit when the ✓ character occurs in an
// application/x-www-form-urlencoded body and the encoding of the page containing
// the form is iso-8859-1, or when the submitted form has an accept-charset
// attribute of iso-8859-1. Presumably also with other charsets that do not contain
// the ✓ character, such as us-ascii.
var isoSentinel = 'utf8=%26%2310003%3B'; // encodeURIComponent('&#10003;')

// These are the percent-encoded utf-8 octets representing a checkmark, indicating that the request actually is utf-8 encoded.
var charsetSentinel = 'utf8=%E2%9C%93'; // encodeURIComponent('✓')

var parseValues = function parseQueryStringValues(str, options) {
    var obj = {};
    var cleanStr = options.ignoreQueryPrefix ? str.replace(/^\?/, '') : str;
    var limit = options.parameterLimit === Infinity ? undefined : options.parameterLimit;
    var parts = cleanStr.split(options.delimiter, limit);
    var skipIndex = -1; // Keep track of where the utf8 sentinel was found
    var i;

    var charset = options.charset;
    if (options.charsetSentinel) {
        for (i = 0; i < parts.length; ++i) {
            if (parts[i].indexOf('utf8=') === 0) {
                if (parts[i] === charsetSentinel) {
                    charset = 'utf-8';
                } else if (parts[i] === isoSentinel) {
                    charset = 'iso-8859-1';
                }
                skipIndex = i;
                i = parts.length; // The eslint settings do not allow break;
            }
        }
    }

    for (i = 0; i < parts.length; ++i) {
        if (i === skipIndex) {
            continue;
        }
        var part = parts[i];

        var bracketEqualsPos = part.indexOf(']=');
        var pos = bracketEqualsPos === -1 ? part.indexOf('=') : bracketEqualsPos + 1;

        var key, val;
        if (pos === -1) {
            key = options.decoder(part, defaults.decoder, charset);
            val = options.strictNullHandling ? null : '';
        } else {
            key = options.decoder(part.slice(0, pos), defaults.decoder, charset);
            val = options.decoder(part.slice(pos + 1), defaults.decoder, charset);
        }

        if (val && options.interpretNumericEntities && charset === 'iso-8859-1') {
            val = interpretNumericEntities(val);
        }

        if (val && options.comma && val.indexOf(',') > -1) {
            val = val.split(',');
        }

        if (has.call(obj, key)) {
            obj[key] = utils.combine(obj[key], val);
        } else {
            obj[key] = val;
        }
    }

    return obj;
};

var parseObject = function (chain, val, options) {
    var leaf = val;

    for (var i = chain.length - 1; i >= 0; --i) {
        var obj;
        var root = chain[i];

        if (root === '[]' && options.parseArrays) {
            obj = [].concat(leaf);
        } else {
            obj = options.plainObjects ? Object.create(null) : {};
            var cleanRoot = root.charAt(0) === '[' && root.charAt(root.length - 1) === ']' ? root.slice(1, -1) : root;
            var index = parseInt(cleanRoot, 10);
            if (!options.parseArrays && cleanRoot === '') {
                obj = { 0: leaf };
            } else if (
                !isNaN(index)
                && root !== cleanRoot
                && String(index) === cleanRoot
                && index >= 0
                && (options.parseArrays && index <= options.arrayLimit)
            ) {
                obj = [];
                obj[index] = leaf;
            } else {
                obj[cleanRoot] = leaf;
            }
        }

        leaf = obj;
    }

    return leaf;
};

var parseKeys = function parseQueryStringKeys(givenKey, val, options) {
    if (!givenKey) {
        return;
    }

    // Transform dot notation to bracket notation
    var key = options.allowDots ? givenKey.replace(/\.([^.[]+)/g, '[$1]') : givenKey;

    // The regex chunks

    var brackets = /(\[[^[\]]*])/;
    var child = /(\[[^[\]]*])/g;

    // Get the parent

    var segment = brackets.exec(key);
    var parent = segment ? key.slice(0, segment.index) : key;

    // Stash the parent if it exists

    var keys = [];
    if (parent) {
        // If we aren't using plain objects, optionally prefix keys that would overwrite object prototype properties
        if (!options.plainObjects && has.call(Object.prototype, parent)) {
            if (!options.allowPrototypes) {
                return;
            }
        }

        keys.push(parent);
    }

    // Loop through children appending to the array until we hit depth

    var i = 0;
    while ((segment = child.exec(key)) !== null && i < options.depth) {
        i += 1;
        if (!options.plainObjects && has.call(Object.prototype, segment[1].slice(1, -1))) {
            if (!options.allowPrototypes) {
                return;
            }
        }
        keys.push(segment[1]);
    }

    // If there's a remainder, just add whatever is left

    if (segment) {
        keys.push('[' + key.slice(segment.index) + ']');
    }

    return parseObject(keys, val, options);
};

var normalizeParseOptions = function normalizeParseOptions(opts) {
    if (!opts) {
        return defaults;
    }

    if (opts.decoder !== null && opts.decoder !== undefined && typeof opts.decoder !== 'function') {
        throw new TypeError('Decoder has to be a function.');
    }

    if (typeof opts.charset !== 'undefined' && opts.charset !== 'utf-8' && opts.charset !== 'iso-8859-1') {
        throw new Error('The charset option must be either utf-8, iso-8859-1, or undefined');
    }
    var charset = typeof opts.charset === 'undefined' ? defaults.charset : opts.charset;

    return {
        allowDots: typeof opts.allowDots === 'undefined' ? defaults.allowDots : !!opts.allowDots,
        allowPrototypes: typeof opts.allowPrototypes === 'boolean' ? opts.allowPrototypes : defaults.allowPrototypes,
        arrayLimit: typeof opts.arrayLimit === 'number' ? opts.arrayLimit : defaults.arrayLimit,
        charset: charset,
        charsetSentinel: typeof opts.charsetSentinel === 'boolean' ? opts.charsetSentinel : defaults.charsetSentinel,
        comma: typeof opts.comma === 'boolean' ? opts.comma : defaults.comma,
        decoder: typeof opts.decoder === 'function' ? opts.decoder : defaults.decoder,
        delimiter: typeof opts.delimiter === 'string' || utils.isRegExp(opts.delimiter) ? opts.delimiter : defaults.delimiter,
        depth: typeof opts.depth === 'number' ? opts.depth : defaults.depth,
        ignoreQueryPrefix: opts.ignoreQueryPrefix === true,
        interpretNumericEntities: typeof opts.interpretNumericEntities === 'boolean' ? opts.interpretNumericEntities : defaults.interpretNumericEntities,
        parameterLimit: typeof opts.parameterLimit === 'number' ? opts.parameterLimit : defaults.parameterLimit,
        parseArrays: opts.parseArrays !== false,
        plainObjects: typeof opts.plainObjects === 'boolean' ? opts.plainObjects : defaults.plainObjects,
        strictNullHandling: typeof opts.strictNullHandling === 'boolean' ? opts.strictNullHandling : defaults.strictNullHandling
    };
};

module.exports = function (str, opts) {
    var options = normalizeParseOptions(opts);

    if (str === '' || str === null || typeof str === 'undefined') {
        return options.plainObjects ? Object.create(null) : {};
    }

    var tempObj = typeof str === 'string' ? parseValues(str, options) : str;
    var obj = options.plainObjects ? Object.create(null) : {};

    // Iterate over the keys and setup the new object

    var keys = Object.keys(tempObj);
    for (var i = 0; i < keys.length; ++i) {
        var key = keys[i];
        var newObj = parseKeys(key, tempObj[key], options);
        obj = utils.merge(obj, newObj, options);
    }

    return utils.compact(obj);
};


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'available_phone_numbers',
  includeBasic: ['list', 'retrieve'],
});



/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var makeRequest = __webpack_require__(17);
var utils = __webpack_require__(1);

function makeAutoPaginationMethods(self, requestArgs, spec, firstPagePromise) {
  var promiseCache = {currentPromise: null};
  var listPromise = firstPagePromise;
  var i = 0;

  function iterate(listResult) {
    if (!(listResult && listResult.data && typeof listResult.data.length === 'number')) {
      throw Error('Unexpected: Telnyx API response does not have a well-formed `data` array.');
    }

    if (i < listResult.data.length) {
      var value = listResult.data[i];
      i += 1;
      return {value: value, done: false};
    } else if (hasMore(listResult)) {
      // Reset counter, request next page, and recurse.
      i = 0;
      var nextPageNumber = getNextPageNumber(listResult);
      var pageSize = getPageSize(listResult);
      listPromise = makeRequest(self, requestArgs, spec, {page: {number: nextPageNumber, size: pageSize}});
      return listPromise.then(iterate);
    }
    return {value: undefined, done: true};
  }

  function hasMore(listResult) {
    return listResult.data.length && listResult.meta.page_number && listResult.meta.total_pages && listResult.meta.total_pages > listResult.meta.page_number;
  }

  function getNextPageNumber(listResult) {
    return listResult.meta.page_number + 1;
  }

  function getPageSize(listResult) {
    return listResult.meta.page_size;
  }

  // function getNextPageToken(listResult) {
  //   return listResult.meta.next_page_token;
  // }

  function asyncIteratorNext() {
    return memoizedPromise(promiseCache, function(resolve, reject) {
      return listPromise
        .then(iterate)
        .then(resolve)
        .catch(reject);
    });
  }

  var autoPagingEach = makeAutoPagingEach(asyncIteratorNext);
  var autoPagingToArray = makeAutoPagingToArray(autoPagingEach);

  var autoPaginationMethods = {
    autoPagingEach: autoPagingEach,
    autoPagingToArray: autoPagingToArray,

    // Async iterator functions:
    next: asyncIteratorNext,
    return: function() {
      // This is required for `break`.
      return {};
    },
    [getAsyncIteratorSymbol()]: function() {
      return autoPaginationMethods;
    }
  };
  return autoPaginationMethods;
}

module.exports.makeAutoPaginationMethods = makeAutoPaginationMethods;

/**
 * ----------------
 * Private Helpers:
 * ----------------
 */

function getAsyncIteratorSymbol() {
  if (typeof Symbol !== 'undefined' && Symbol.asyncIterator) {
    return Symbol.asyncIterator;
  }
  // Follow the convention from libraries like iterall: https://github.com/leebyron/iterall#asynciterator-1
  return '@@asyncIterator';
}

function getDoneCallback(args) {
  if (args.length < 2) {
    return undefined;
  }
  var onDone = args[1];
  if (typeof onDone !== 'function') {
    throw Error('The second argument to autoPagingEach, if present, must be a callback function; receieved ' + typeof onDone);
  }
  return onDone;
}

/**
 * We allow four forms of the `onItem` callback (the middle two being equivalent),
 *
 *   1. `.autoPagingEach((item) => { doSomething(item); return false; });`
 *   2. `.autoPagingEach(async (item) => { await doSomething(item); return false; });`
 *   3. `.autoPagingEach((item) => doSomething(item).then(() => false));`
 *   4. `.autoPagingEach((item, next) => { doSomething(item); next(false); });`
 *
 * In addition to standard validation, this helper
 * coalesces the former forms into the latter form.
 */
function getItemCallback(args) {
  if (args.length === 0) {
    return undefined;
  }
  var onItem = args[0];
  if (typeof onItem !== 'function') {
    throw Error('The first argument to autoPagingEach, if present, must be a callback function; receieved ' + typeof onItem);
  }

  // 4. `.autoPagingEach((item, next) => { doSomething(item); next(false); });`
  if (onItem.length === 2) {
    return onItem;
  }

  if (onItem.length > 2) {
    throw Error('The `onItem` callback function passed to autoPagingEach must accept at most two arguments; got ' + onItem);
  }

  // This magically handles all three of these usecases (the latter two being functionally identical):
  // 1. `.autoPagingEach((item) => { doSomething(item); return false; });`
  // 2. `.autoPagingEach(async (item) => { await doSomething(item); return false; });`
  // 3. `.autoPagingEach((item) => doSomething(item).then(() => false));`
  return function _onItem(item, next) {
    var shouldContinue = onItem(item);
    next(shouldContinue);
  };
}

// function getLastId(listResult) {
//   var lastIdx = listResult.data.length - 1;
//   var lastItem = listResult.data[lastIdx];
//   var lastId = lastItem && lastItem.id;
//   if (!lastId) {
//     throw Error('Unexpected: No `id` found on the last item while auto-paging a list.');
//   }
//   return lastId;
// }

/**
 * If a user calls `.next()` multiple times in parallel,
 * return the same result until something has resolved
 * to prevent page-turning race conditions.
 */
function memoizedPromise(promiseCache, cb) {
  if (promiseCache.currentPromise) {
    return promiseCache.currentPromise;
  }
  promiseCache.currentPromise = new Promise(cb).then(function(ret) {
    promiseCache.currentPromise = undefined;
    return ret;
  });
  return promiseCache.currentPromise;
}

function makeAutoPagingEach(asyncIteratorNext) {
  return function autoPagingEach(/* onItem?, onDone? */) {
    var args = [].slice.call(arguments);
    var onItem = getItemCallback(args);
    var onDone = getDoneCallback(args);
    if (args.length > 2) {
      throw Error('autoPagingEach takes up to two arguments; received:', args);
    }

    var autoPagePromise = wrapAsyncIteratorWithCallback(asyncIteratorNext, onItem);
    return utils.callbackifyPromiseWithTimeout(autoPagePromise, onDone);
  }
}

function makeAutoPagingToArray(autoPagingEach) {
  return function autoPagingToArray(opts, onDone) {
    var limit = opts && opts.limit;
    if (!limit) {
      throw Error('You must pass a `limit` option to autoPagingToArray, eg; `autoPagingToArray({limit: 1000});`.');
    }
    if (limit > 10000) {
      throw Error('You cannot specify a limit of more than 10,000 items to fetch in `autoPagingToArray`; use `autoPagingEach` to iterate through longer lists.');
    }
    var promise = new Promise(function(resolve, reject) {
      var items = [];
      autoPagingEach(function(item) {
        items.push(item);
        if (items.length >= limit) {
          return false;
        }
      }).then(function() {
        resolve(items);
      }).catch(reject);
    });
    return utils.callbackifyPromiseWithTimeout(promise, onDone);
  }
}

function wrapAsyncIteratorWithCallback(asyncIteratorNext, onItem) {
  return new Promise(function(resolve, reject) {
    function handleIteration(iterResult) {
      if (iterResult.done) {
        resolve();
        return;
      }

      var item = iterResult.value;
      return new Promise(function(next) {
        // Bit confusing, perhaps; we pass a `resolve` fn
        // to the user, so they can decide when and if to continue.
        // They can return false, or a promise which resolves to false, to break.
        onItem(item, next);
      }).then(function(shouldContinue) {
        if (shouldContinue === false) {
          return handleIteration({done: true});
        } else {
          return asyncIteratorNext().then(handleIteration);
        }
      });
    }

    asyncIteratorNext().then(handleIteration).catch(reject);
  });
}


/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isPlainObject = __webpack_require__(15);
var telnyxMethod = __webpack_require__(16);
var utils = __webpack_require__(1);

module.exports = {

  create: telnyxMethod({
    method: 'POST',
  }),

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],
  }),

  update: telnyxMethod({
    method: 'PATCH',
    path: '{id}',
    urlParams: ['id'],
  }),

  // Avoid 'delete' keyword in JS
  del: telnyxMethod({
    method: 'DELETE',
    path: '{id}',
    urlParams: ['id'],
  }),

  setMetadata: function(id, key, value, auth, cb) {
    var self = this;
    var data = key;
    var isObject = isPlainObject(key);
    // We assume null for an empty object
    var isNull = data === null || (isObject && !Object.keys(data).length);

    // Allow optional passing of auth & cb:
    if ((isNull || isObject) && typeof value == 'string') {
      auth = value;
    } else if (typeof auth != 'string') {
      if (!cb && typeof auth == 'function') {
        cb = auth;
      }
      auth = null;
    }

    var urlData = this.createUrlData();
    var path = this.createFullPath('/' + id, urlData);

    return utils.callbackifyPromiseWithTimeout(new Promise((function(resolve, reject) {
      if (isNull) {
        // Reset metadata:
        sendMetadata(null, auth);
      } else if (!isObject) {
        // Set individual metadata property:
        var metadata = {};
        metadata[key] = value;
        sendMetadata(metadata, auth);
      } else {
        // Set entire metadata object after resetting it:
        this._request('POST', null, path, {
          metadata: null,
        }, auth, {}, function(err, response) {
          if (err) {
            return reject(err);
          }
          sendMetadata(data, auth);
        });
      }

      function sendMetadata(metadata, auth) {
        self._request('POST', null, path, {
          metadata: metadata,
        }, auth, {}, function(err, response) {
          if (err) {
            reject(err);
          } else {
            resolve(response.metadata);
          }
        });
      }
    }).bind(this)), cb);
  },

  getMetadata: function(id, auth, cb) {
    if (!cb && typeof auth == 'function') {
      cb = auth;
      auth = null;
    }

    var urlData = this.createUrlData();
    var path = this.createFullPath('/' + id, urlData);

    return utils.callbackifyPromiseWithTimeout(new Promise((function(resolve, reject) {
      this._request('GET', null, path, {}, auth, {}, function(err, response) {
        if (err) {
          reject(err);
        } else {
          resolve(response.metadata);
        }
      });
    }).bind(this)), cb);
  },

};


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'events',
  includeBasic: ['list', 'retrieve'],
});



/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'messages',
  includeBasic: ['create', 'retrieve'],

  nestedResources: {
    AlphanumericSenderId: __webpack_require__(44)
  },
});


/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'messages/alphanumeric_sender_id',
  includeBasic: ['create'],
});


/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'messaging_phone_numbers',
  includeBasic: ['list', 'retrieve', 'update'],
});



/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

var ACTIONS = [
  'phone_numbers',
  'alphanumeric_sender_ids',
  'short_codes',
  'metrics'
];

function getSpec(messagingProfileId) {
  return function(methodName) {
    return {
      method: 'GET',
      path: `/{messagingProfileId}/${methodName}`,
      urlParams: ['messagingProfileId'],
      paramsValues: [messagingProfileId],
      paramsNames: ['id'],
      methodType: 'list',
    }
  }
}

function transformResponseData(response, telnyx) {
  const methods = utils.createNestedMethods(telnyxMethod, ACTIONS, getSpec(response.data.id));

  methods.del = telnyxMethod({
    method: 'DELETE',
    path: '/{messagingProfileId}',
    urlParams: ['messagingProfileId'],
    paramsValues: [response.data.id],
    paramsNames: ['id'],
  });

  return utils.addResourceToResponseData(
    response,
    telnyx,
    'messagingProfiles',
    methods
  );
}

module.exports = __webpack_require__(0).extend({
  path: 'messaging_profiles',
  includeBasic: ['list', 'del', 'update'],

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),

  listPhoneNumbers: telnyxMethod({
    method: 'GET',
    path: '/{messagingProfileId}/phone_numbers',
    urlParams: ['messagingProfileId'],
    methodType: 'list',
  }),

  phoneNumbers: telnyxMethod({
    method: 'GET',
    path: '/{messagingProfileId}/phone_numbers',
    urlParams: ['messagingProfileId'],
  }),

  listShortCodes: telnyxMethod({
    method: 'GET',
    path: '/{messagingProfileId}/short_codes',
    urlParams: ['messagingProfileId'],
    methodType: 'list',
  }),

  shortCodes: telnyxMethod({
    method: 'GET',
    path: '/{messagingProfileId}/short_codes',
    urlParams: ['messagingProfileId'],
  }),

  listSenderIds: telnyxMethod({
    method: 'GET',
    path: '/{messagingProfileId}/alphanumeric_sender_ids',
    urlParams: ['messagingProfileId'],
    methodType: 'list',
  }),

  senderIds: telnyxMethod({
    method: 'GET',
    path: '/{messagingProfileId}/alphanumeric_sender_ids',
    urlParams: ['messagingProfileId'],
  }),

  retrieveMetrics: telnyxMethod({
    method: 'GET',
    path: '/{messagingProfileId}/metrics',
    urlParams: ['messagingProfileId'],
    methodType: 'retrieve',
  }),
});



/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'alphanumeric_sender_ids', // THIS URL DOES NOT EXISTS ON DOCS
  includeBasic: ['list', 'retrieve', 'create','del'],
});



/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'short_codes',
  includeBasic: ['list', 'retrieve', 'update'],
});



/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'number_orders',
  includeBasic: ['list', 'retrieve', 'create', 'update'],
});



/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

module.exports = __webpack_require__(0).extend({
  path: 'number_reservations',
  includeBasic: ['list', 'retrieve'],

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: function(response, telnyx) {
      return utils.addResourceToResponseData(
        response,
        telnyx,
        'numberReservations',
        {
          extend: telnyxMethod({
            method: 'POST',
            path: '/{numberReservationId}/actions/extend',
            urlParams: ['numberReservationId'],
            paramsValues: [response.data.id],
            paramsNames: ['id'],
            methodType: 'create',
          }),
        }
      );
    },
  })
});



/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var telnyxMethod = TelnyxResource.method;

module.exports = __webpack_require__(0).extend({
  path: 'phone_numbers',
  includeBasic: ['list', 'retrieve', 'update', 'del'],

  nestedResources: {
    Messaging: __webpack_require__(52),
    Voice: __webpack_require__(53),
    Inbound: __webpack_require__(18),
  },

  retrieveVoiceSettings: telnyxMethod({
    method: 'GET',
    path: '/{id}/voice',
    urlParams: ['id'],
    methodType: 'retrieve',
  }),

  updateVoiceSettings: telnyxMethod({
    method: 'PATCH',
    path: '/{id}/voice',
    urlParams: ['id'],
  }),

  retrieveMessagingSettings: telnyxMethod({
    method: 'GET',
    path: '/{id}/messaging',
    urlParams: ['id'],
    methodType: 'retrieve',
  }),

  updateMessagingSettings: telnyxMethod({
    method: 'PATCH',
    path: '/{id}/messaging',
    urlParams: ['id'],
  }),
});


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'phone_numbers/messaging',
  includeBasic: ['list'],
});


/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'phone_numbers/voice',
  includeBasic: ['list'],
});


/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

var CALL_COMMANDS = [
  'answer',
  'reject',
  'hangup',
  'bridge',
  'speak',
  'fork_start',
  'fork_stop',
  'gather_using_audio',
  'gather_using_speak',
  'playback_start',
  'playback_stop',
  'record_start',
  'record_stop',
  'send_dtmf',
  'transfer'
];

function getSpec(callControlId) {
  return function(methodName) {
    return {
      method: 'POST',
      path: `/{call_control_id}/actions/${methodName}`,
      urlParams: ['call_control_id'],
      paramsValues: [callControlId],
      paramsNames: ['call_control_id'],
      methodType: 'create',
    }
  }
}

module.exports = __webpack_require__(0).extend({
  path: 'calls',
  includeBasic: ['retrieve'], // status method

  create: telnyxMethod({ // dial method
    method: 'POST',

    transformResponseData: function(response, telnyx) {
      return utils.addResourceToResponseData(
        response,
        telnyx,
        'calls',
        utils.createNestedMethods(
          telnyxMethod,
          CALL_COMMANDS,
          getSpec(response.data.call_control_id)
        )
      );
    },
  }),

  instanceMethods: utils.createNestedMethods(telnyxMethod, CALL_COMMANDS, getSpec())
});


/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

var CONFERENCES = [
  'join',
  'mute',
  'unmute',
  'hold',
  'unhold',
];

function getSpec(conferenceId) {
  return function(methodName) {
    return {
      method: 'POST',
      path: `/{conferenceId}/actions/${methodName}`,
      urlParams: ['conferenceId'],
      paramsValues: [conferenceId],
      paramsNames: ['id'],
      methodType: 'create',
    }
  }
}

module.exports = __webpack_require__(0).extend({
  path: 'conferences',
  includeBasic: ['list'],

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: function(response, telnyx) {
      return utils.addResourceToResponseData(
        response,
        telnyx,
        'conferences',
        utils.createNestedMethods(telnyxMethod, CONFERENCES, getSpec(response.data.id))
      );
    },
  }),

  instanceMethods: utils.createNestedMethods(telnyxMethod, CONFERENCES, getSpec())
});


/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'call_events',
  includeBasic: ['list'],
});



/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var telnyxMethod = TelnyxResource.method;

module.exports = TelnyxResource.extend({

  path: 'public_key',

  retrieve: telnyxMethod({
    method: 'GET',
  })
});


/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'simCards',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{sim_card_id}',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      save: telnyxMethod({
        method: 'PATCH',
        path: '/{sim_card_id}',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      activate: telnyxMethod({
        method: 'POST',
        path: '/{sim_card_id}/actions/enable',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      deactivate: telnyxMethod({
        method: 'POST',
        path: '/{sim_card_id}/actions/disable',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      enable: telnyxMethod({
        method: 'POST',
        path: '/{sim_card_id}/actions/enable',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      disable: telnyxMethod({
        method: 'POST',
        path: '/{sim_card_id}/actions/disable',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      retrieveNetworkPreferences: telnyxMethod({
        method: 'GET',
        path: '/{sim_card_id}/network_preferences',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      setNetworkPreferences: telnyxMethod({
        method: 'PUT',
        path: '/{sim_card_id}/network_preferences',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      deleteNetworkPreferences: telnyxMethod({
        method: 'DELETE',
        path: '/{sim_card_id}/network_preferences',
        urlParams: ['sim_card_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'sim_cards',
  includeBasic: ['update'],

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'billingGroups',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{billingGroupsId}',
        urlParams: ['billingGroupsId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{billingGroupsId}',
        urlParams: ['billingGroupsId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'billing_groups',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'ips',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{ipId}',
        urlParams: ['ipId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{ipId}',
        urlParams: ['ipId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'ips',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'fqdns',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{fqdnId}',
        urlParams: ['fqdnId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{fqdnId}',
        urlParams: ['fqdnId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'fqdns',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'connections',
  includeBasic: ['list', 'retrieve'],
});


/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'ipConnections',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{ipConnectionId}',
        urlParams: ['ipConnectionId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{ipConnectionId}',
        urlParams: ['ipConnectionId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'ip_connections',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'fqdnConnections',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{fqdnConnectionId}',
        urlParams: ['fqdnConnectionId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{fqdnConnectionId}',
        urlParams: ['fqdnConnectionId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'fqdn_connections',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";



var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'credentialConnections',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{credentialConnectionId}',
        urlParams: ['credentialConnectionId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{credentialConnectionId}',
        urlParams: ['credentialConnectionId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'credential_connections',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'regulatory_requirements',

  includeBasic: ['list', 'retrieve'],
});


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'phone_number_regulatory_requirements',

  includeBasic: ['list'],
});


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var telnyxMethod = TelnyxResource.method;

module.exports = TelnyxResource.extend({
  path: 'number_order_documents',
  includeBasic: ['list', 'retrieve', 'update'],

  upload: telnyxMethod({
    method: 'POST',
    methodType: 'create',
  }),
});



/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'actions',

  nestedResources: {
    SimCards: __webpack_require__(70)
  },
});


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var telnyxMethod = TelnyxResource.method;

module.exports = TelnyxResource.extend({
  path: 'actions',

  register: telnyxMethod({
    method: 'POST',
    path: '/register/sim_cards',
  }),

  bulkNetworkPreferences: telnyxMethod({
    method: 'PUT',
    path: '/network_preferences/sim_cards',
  }),
});


/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'outboundVoiceProfiles',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{outboundId}',
        urlParams: ['outboundId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{outboundId}',
        urlParams: ['outboundId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = __webpack_require__(0).extend({
  path: 'outbound_voice_profiles',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'callControlApplications',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{callControlId}',
        urlParams: ['callControlId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{callControlId}',
        urlParams: ['callControlId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = __webpack_require__(0).extend({
  path: 'call_control_applications',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',
    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 73 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'ota_updates',

  includeBasic: ['list', 'retrieve'],
});


/***/ }),
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'mobile_operator_networks',
  includeBasic: ['list'],
});


/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'simCardGroups',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{simCardGroupId}',
        urlParams: ['simCardGroupId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{simCardGroupId}',
        urlParams: ['simCardGroupId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'sim_card_groups',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'number_lookup',
  includeBasic: ['retrieve'],
});


/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'balance',

  retrieve: TelnyxResource.method({
    method: 'GET',
  })
});


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'addresses',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{addressId}',
        urlParams: ['addressId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'addresses',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'faxes',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{faxId}',
        urlParams: ['faxId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'faxes',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  send: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'shortCodes',
    {
      update: telnyxMethod({
        method: 'PATCH',
        path: '/{shortCodeId}',
        urlParams: ['shortCodeId'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = TelnyxResource.extend({
  path: 'short_codes',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{id}',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(0).extend({
  path: 'messaging_profile_metrics',
  includeBasic: ['list'],
});



/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'telephonyCredentials'
  );
}

module.exports = TelnyxResource.extend({
  path: 'telephony_credentials',

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'POST',
    path: '/{id}/token',
    urlParams: ['id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);
var utils = __webpack_require__(1);
var telnyxMethod = TelnyxResource.method;

function transformResponseData(response, telnyx) {
  return utils.addResourceToResponseData(
    response,
    telnyx,
    'verifyProfiles',
    {
      del: telnyxMethod({
        method: 'DELETE',
        path: '/{verify_profile_id}',
        urlParams: ['verify_profile_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),

      update: telnyxMethod({
        method: 'PATCH',
        path: '/{verify_profile_id}',
        urlParams: ['verify_profile_id'],
        paramsValues: [response.data.id],
        paramsNames: ['id'],
      }),
    }
  );
}

module.exports = __webpack_require__(0).extend({
  path: 'verify_profiles',

  list: telnyxMethod({
    method: 'GET',
    methodType: 'list',

    transformResponseData: transformResponseData,
  }),

  create: telnyxMethod({
    method: 'POST',

    transformResponseData: transformResponseData,
  }),

  retrieve: telnyxMethod({
    method: 'GET',
    path: '/{verify_profile_id}',
    urlParams: ['verify_profile_id'],

    transformResponseData: transformResponseData,
  }),
});


/***/ }),
/* 84 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'verifications',

  nestedResources: {
    ByPhoneNumber: __webpack_require__(85),
  },

  create: TelnyxResource.method({
    method: 'POST',
  }),

  retrieve: TelnyxResource.method({
    method: 'GET',
    path: '/{verification_id}',
    urlParams: ['verification_id'],
  }),
});


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var TelnyxResource = __webpack_require__(0);

module.exports = TelnyxResource.extend({
  path: 'verifications/by_phone_number',

  submit: TelnyxResource.method({
    method: 'POST',
    path: '/{phone_number}/actions/verify',
    urlParams: ['phone_number'],
  }),

  create: TelnyxResource.method({
    method: 'POST',
    path: '/{phone_number}/actions/verify',
    urlParams: ['phone_number'],
  }),

  verify: TelnyxResource.method({
    method: 'POST',
    path: '/{phone_number}/actions/verify',
    urlParams: ['phone_number'],
  }),

  list: TelnyxResource.method({
    method: 'GET',
    path: '/{phone_number}',
    urlParams: ['phone_number'],
  }),
});


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

(function(nacl) {
'use strict';

// Ported in 2014 by Dmitry Chestnykh and Devi Mandiri.
// Public domain.
//
// Implementation derived from TweetNaCl version 20140427.
// See for details: http://tweetnacl.cr.yp.to/

var gf = function(init) {
  var i, r = new Float64Array(16);
  if (init) for (i = 0; i < init.length; i++) r[i] = init[i];
  return r;
};

//  Pluggable, initialized in high-level API below.
var randombytes = function(/* x, n */) { throw new Error('no PRNG'); };

var _0 = new Uint8Array(16);
var _9 = new Uint8Array(32); _9[0] = 9;

var gf0 = gf(),
    gf1 = gf([1]),
    _121665 = gf([0xdb41, 1]),
    D = gf([0x78a3, 0x1359, 0x4dca, 0x75eb, 0xd8ab, 0x4141, 0x0a4d, 0x0070, 0xe898, 0x7779, 0x4079, 0x8cc7, 0xfe73, 0x2b6f, 0x6cee, 0x5203]),
    D2 = gf([0xf159, 0x26b2, 0x9b94, 0xebd6, 0xb156, 0x8283, 0x149a, 0x00e0, 0xd130, 0xeef3, 0x80f2, 0x198e, 0xfce7, 0x56df, 0xd9dc, 0x2406]),
    X = gf([0xd51a, 0x8f25, 0x2d60, 0xc956, 0xa7b2, 0x9525, 0xc760, 0x692c, 0xdc5c, 0xfdd6, 0xe231, 0xc0a4, 0x53fe, 0xcd6e, 0x36d3, 0x2169]),
    Y = gf([0x6658, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666]),
    I = gf([0xa0b0, 0x4a0e, 0x1b27, 0xc4ee, 0xe478, 0xad2f, 0x1806, 0x2f43, 0xd7a7, 0x3dfb, 0x0099, 0x2b4d, 0xdf0b, 0x4fc1, 0x2480, 0x2b83]);

function ts64(x, i, h, l) {
  x[i]   = (h >> 24) & 0xff;
  x[i+1] = (h >> 16) & 0xff;
  x[i+2] = (h >>  8) & 0xff;
  x[i+3] = h & 0xff;
  x[i+4] = (l >> 24)  & 0xff;
  x[i+5] = (l >> 16)  & 0xff;
  x[i+6] = (l >>  8)  & 0xff;
  x[i+7] = l & 0xff;
}

function vn(x, xi, y, yi, n) {
  var i,d = 0;
  for (i = 0; i < n; i++) d |= x[xi+i]^y[yi+i];
  return (1 & ((d - 1) >>> 8)) - 1;
}

function crypto_verify_16(x, xi, y, yi) {
  return vn(x,xi,y,yi,16);
}

function crypto_verify_32(x, xi, y, yi) {
  return vn(x,xi,y,yi,32);
}

function core_salsa20(o, p, k, c) {
  var j0  = c[ 0] & 0xff | (c[ 1] & 0xff)<<8 | (c[ 2] & 0xff)<<16 | (c[ 3] & 0xff)<<24,
      j1  = k[ 0] & 0xff | (k[ 1] & 0xff)<<8 | (k[ 2] & 0xff)<<16 | (k[ 3] & 0xff)<<24,
      j2  = k[ 4] & 0xff | (k[ 5] & 0xff)<<8 | (k[ 6] & 0xff)<<16 | (k[ 7] & 0xff)<<24,
      j3  = k[ 8] & 0xff | (k[ 9] & 0xff)<<8 | (k[10] & 0xff)<<16 | (k[11] & 0xff)<<24,
      j4  = k[12] & 0xff | (k[13] & 0xff)<<8 | (k[14] & 0xff)<<16 | (k[15] & 0xff)<<24,
      j5  = c[ 4] & 0xff | (c[ 5] & 0xff)<<8 | (c[ 6] & 0xff)<<16 | (c[ 7] & 0xff)<<24,
      j6  = p[ 0] & 0xff | (p[ 1] & 0xff)<<8 | (p[ 2] & 0xff)<<16 | (p[ 3] & 0xff)<<24,
      j7  = p[ 4] & 0xff | (p[ 5] & 0xff)<<8 | (p[ 6] & 0xff)<<16 | (p[ 7] & 0xff)<<24,
      j8  = p[ 8] & 0xff | (p[ 9] & 0xff)<<8 | (p[10] & 0xff)<<16 | (p[11] & 0xff)<<24,
      j9  = p[12] & 0xff | (p[13] & 0xff)<<8 | (p[14] & 0xff)<<16 | (p[15] & 0xff)<<24,
      j10 = c[ 8] & 0xff | (c[ 9] & 0xff)<<8 | (c[10] & 0xff)<<16 | (c[11] & 0xff)<<24,
      j11 = k[16] & 0xff | (k[17] & 0xff)<<8 | (k[18] & 0xff)<<16 | (k[19] & 0xff)<<24,
      j12 = k[20] & 0xff | (k[21] & 0xff)<<8 | (k[22] & 0xff)<<16 | (k[23] & 0xff)<<24,
      j13 = k[24] & 0xff | (k[25] & 0xff)<<8 | (k[26] & 0xff)<<16 | (k[27] & 0xff)<<24,
      j14 = k[28] & 0xff | (k[29] & 0xff)<<8 | (k[30] & 0xff)<<16 | (k[31] & 0xff)<<24,
      j15 = c[12] & 0xff | (c[13] & 0xff)<<8 | (c[14] & 0xff)<<16 | (c[15] & 0xff)<<24;

  var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7,
      x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14,
      x15 = j15, u;

  for (var i = 0; i < 20; i += 2) {
    u = x0 + x12 | 0;
    x4 ^= u<<7 | u>>>(32-7);
    u = x4 + x0 | 0;
    x8 ^= u<<9 | u>>>(32-9);
    u = x8 + x4 | 0;
    x12 ^= u<<13 | u>>>(32-13);
    u = x12 + x8 | 0;
    x0 ^= u<<18 | u>>>(32-18);

    u = x5 + x1 | 0;
    x9 ^= u<<7 | u>>>(32-7);
    u = x9 + x5 | 0;
    x13 ^= u<<9 | u>>>(32-9);
    u = x13 + x9 | 0;
    x1 ^= u<<13 | u>>>(32-13);
    u = x1 + x13 | 0;
    x5 ^= u<<18 | u>>>(32-18);

    u = x10 + x6 | 0;
    x14 ^= u<<7 | u>>>(32-7);
    u = x14 + x10 | 0;
    x2 ^= u<<9 | u>>>(32-9);
    u = x2 + x14 | 0;
    x6 ^= u<<13 | u>>>(32-13);
    u = x6 + x2 | 0;
    x10 ^= u<<18 | u>>>(32-18);

    u = x15 + x11 | 0;
    x3 ^= u<<7 | u>>>(32-7);
    u = x3 + x15 | 0;
    x7 ^= u<<9 | u>>>(32-9);
    u = x7 + x3 | 0;
    x11 ^= u<<13 | u>>>(32-13);
    u = x11 + x7 | 0;
    x15 ^= u<<18 | u>>>(32-18);

    u = x0 + x3 | 0;
    x1 ^= u<<7 | u>>>(32-7);
    u = x1 + x0 | 0;
    x2 ^= u<<9 | u>>>(32-9);
    u = x2 + x1 | 0;
    x3 ^= u<<13 | u>>>(32-13);
    u = x3 + x2 | 0;
    x0 ^= u<<18 | u>>>(32-18);

    u = x5 + x4 | 0;
    x6 ^= u<<7 | u>>>(32-7);
    u = x6 + x5 | 0;
    x7 ^= u<<9 | u>>>(32-9);
    u = x7 + x6 | 0;
    x4 ^= u<<13 | u>>>(32-13);
    u = x4 + x7 | 0;
    x5 ^= u<<18 | u>>>(32-18);

    u = x10 + x9 | 0;
    x11 ^= u<<7 | u>>>(32-7);
    u = x11 + x10 | 0;
    x8 ^= u<<9 | u>>>(32-9);
    u = x8 + x11 | 0;
    x9 ^= u<<13 | u>>>(32-13);
    u = x9 + x8 | 0;
    x10 ^= u<<18 | u>>>(32-18);

    u = x15 + x14 | 0;
    x12 ^= u<<7 | u>>>(32-7);
    u = x12 + x15 | 0;
    x13 ^= u<<9 | u>>>(32-9);
    u = x13 + x12 | 0;
    x14 ^= u<<13 | u>>>(32-13);
    u = x14 + x13 | 0;
    x15 ^= u<<18 | u>>>(32-18);
  }
   x0 =  x0 +  j0 | 0;
   x1 =  x1 +  j1 | 0;
   x2 =  x2 +  j2 | 0;
   x3 =  x3 +  j3 | 0;
   x4 =  x4 +  j4 | 0;
   x5 =  x5 +  j5 | 0;
   x6 =  x6 +  j6 | 0;
   x7 =  x7 +  j7 | 0;
   x8 =  x8 +  j8 | 0;
   x9 =  x9 +  j9 | 0;
  x10 = x10 + j10 | 0;
  x11 = x11 + j11 | 0;
  x12 = x12 + j12 | 0;
  x13 = x13 + j13 | 0;
  x14 = x14 + j14 | 0;
  x15 = x15 + j15 | 0;

  o[ 0] = x0 >>>  0 & 0xff;
  o[ 1] = x0 >>>  8 & 0xff;
  o[ 2] = x0 >>> 16 & 0xff;
  o[ 3] = x0 >>> 24 & 0xff;

  o[ 4] = x1 >>>  0 & 0xff;
  o[ 5] = x1 >>>  8 & 0xff;
  o[ 6] = x1 >>> 16 & 0xff;
  o[ 7] = x1 >>> 24 & 0xff;

  o[ 8] = x2 >>>  0 & 0xff;
  o[ 9] = x2 >>>  8 & 0xff;
  o[10] = x2 >>> 16 & 0xff;
  o[11] = x2 >>> 24 & 0xff;

  o[12] = x3 >>>  0 & 0xff;
  o[13] = x3 >>>  8 & 0xff;
  o[14] = x3 >>> 16 & 0xff;
  o[15] = x3 >>> 24 & 0xff;

  o[16] = x4 >>>  0 & 0xff;
  o[17] = x4 >>>  8 & 0xff;
  o[18] = x4 >>> 16 & 0xff;
  o[19] = x4 >>> 24 & 0xff;

  o[20] = x5 >>>  0 & 0xff;
  o[21] = x5 >>>  8 & 0xff;
  o[22] = x5 >>> 16 & 0xff;
  o[23] = x5 >>> 24 & 0xff;

  o[24] = x6 >>>  0 & 0xff;
  o[25] = x6 >>>  8 & 0xff;
  o[26] = x6 >>> 16 & 0xff;
  o[27] = x6 >>> 24 & 0xff;

  o[28] = x7 >>>  0 & 0xff;
  o[29] = x7 >>>  8 & 0xff;
  o[30] = x7 >>> 16 & 0xff;
  o[31] = x7 >>> 24 & 0xff;

  o[32] = x8 >>>  0 & 0xff;
  o[33] = x8 >>>  8 & 0xff;
  o[34] = x8 >>> 16 & 0xff;
  o[35] = x8 >>> 24 & 0xff;

  o[36] = x9 >>>  0 & 0xff;
  o[37] = x9 >>>  8 & 0xff;
  o[38] = x9 >>> 16 & 0xff;
  o[39] = x9 >>> 24 & 0xff;

  o[40] = x10 >>>  0 & 0xff;
  o[41] = x10 >>>  8 & 0xff;
  o[42] = x10 >>> 16 & 0xff;
  o[43] = x10 >>> 24 & 0xff;

  o[44] = x11 >>>  0 & 0xff;
  o[45] = x11 >>>  8 & 0xff;
  o[46] = x11 >>> 16 & 0xff;
  o[47] = x11 >>> 24 & 0xff;

  o[48] = x12 >>>  0 & 0xff;
  o[49] = x12 >>>  8 & 0xff;
  o[50] = x12 >>> 16 & 0xff;
  o[51] = x12 >>> 24 & 0xff;

  o[52] = x13 >>>  0 & 0xff;
  o[53] = x13 >>>  8 & 0xff;
  o[54] = x13 >>> 16 & 0xff;
  o[55] = x13 >>> 24 & 0xff;

  o[56] = x14 >>>  0 & 0xff;
  o[57] = x14 >>>  8 & 0xff;
  o[58] = x14 >>> 16 & 0xff;
  o[59] = x14 >>> 24 & 0xff;

  o[60] = x15 >>>  0 & 0xff;
  o[61] = x15 >>>  8 & 0xff;
  o[62] = x15 >>> 16 & 0xff;
  o[63] = x15 >>> 24 & 0xff;
}

function core_hsalsa20(o,p,k,c) {
  var j0  = c[ 0] & 0xff | (c[ 1] & 0xff)<<8 | (c[ 2] & 0xff)<<16 | (c[ 3] & 0xff)<<24,
      j1  = k[ 0] & 0xff | (k[ 1] & 0xff)<<8 | (k[ 2] & 0xff)<<16 | (k[ 3] & 0xff)<<24,
      j2  = k[ 4] & 0xff | (k[ 5] & 0xff)<<8 | (k[ 6] & 0xff)<<16 | (k[ 7] & 0xff)<<24,
      j3  = k[ 8] & 0xff | (k[ 9] & 0xff)<<8 | (k[10] & 0xff)<<16 | (k[11] & 0xff)<<24,
      j4  = k[12] & 0xff | (k[13] & 0xff)<<8 | (k[14] & 0xff)<<16 | (k[15] & 0xff)<<24,
      j5  = c[ 4] & 0xff | (c[ 5] & 0xff)<<8 | (c[ 6] & 0xff)<<16 | (c[ 7] & 0xff)<<24,
      j6  = p[ 0] & 0xff | (p[ 1] & 0xff)<<8 | (p[ 2] & 0xff)<<16 | (p[ 3] & 0xff)<<24,
      j7  = p[ 4] & 0xff | (p[ 5] & 0xff)<<8 | (p[ 6] & 0xff)<<16 | (p[ 7] & 0xff)<<24,
      j8  = p[ 8] & 0xff | (p[ 9] & 0xff)<<8 | (p[10] & 0xff)<<16 | (p[11] & 0xff)<<24,
      j9  = p[12] & 0xff | (p[13] & 0xff)<<8 | (p[14] & 0xff)<<16 | (p[15] & 0xff)<<24,
      j10 = c[ 8] & 0xff | (c[ 9] & 0xff)<<8 | (c[10] & 0xff)<<16 | (c[11] & 0xff)<<24,
      j11 = k[16] & 0xff | (k[17] & 0xff)<<8 | (k[18] & 0xff)<<16 | (k[19] & 0xff)<<24,
      j12 = k[20] & 0xff | (k[21] & 0xff)<<8 | (k[22] & 0xff)<<16 | (k[23] & 0xff)<<24,
      j13 = k[24] & 0xff | (k[25] & 0xff)<<8 | (k[26] & 0xff)<<16 | (k[27] & 0xff)<<24,
      j14 = k[28] & 0xff | (k[29] & 0xff)<<8 | (k[30] & 0xff)<<16 | (k[31] & 0xff)<<24,
      j15 = c[12] & 0xff | (c[13] & 0xff)<<8 | (c[14] & 0xff)<<16 | (c[15] & 0xff)<<24;

  var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7,
      x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14,
      x15 = j15, u;

  for (var i = 0; i < 20; i += 2) {
    u = x0 + x12 | 0;
    x4 ^= u<<7 | u>>>(32-7);
    u = x4 + x0 | 0;
    x8 ^= u<<9 | u>>>(32-9);
    u = x8 + x4 | 0;
    x12 ^= u<<13 | u>>>(32-13);
    u = x12 + x8 | 0;
    x0 ^= u<<18 | u>>>(32-18);

    u = x5 + x1 | 0;
    x9 ^= u<<7 | u>>>(32-7);
    u = x9 + x5 | 0;
    x13 ^= u<<9 | u>>>(32-9);
    u = x13 + x9 | 0;
    x1 ^= u<<13 | u>>>(32-13);
    u = x1 + x13 | 0;
    x5 ^= u<<18 | u>>>(32-18);

    u = x10 + x6 | 0;
    x14 ^= u<<7 | u>>>(32-7);
    u = x14 + x10 | 0;
    x2 ^= u<<9 | u>>>(32-9);
    u = x2 + x14 | 0;
    x6 ^= u<<13 | u>>>(32-13);
    u = x6 + x2 | 0;
    x10 ^= u<<18 | u>>>(32-18);

    u = x15 + x11 | 0;
    x3 ^= u<<7 | u>>>(32-7);
    u = x3 + x15 | 0;
    x7 ^= u<<9 | u>>>(32-9);
    u = x7 + x3 | 0;
    x11 ^= u<<13 | u>>>(32-13);
    u = x11 + x7 | 0;
    x15 ^= u<<18 | u>>>(32-18);

    u = x0 + x3 | 0;
    x1 ^= u<<7 | u>>>(32-7);
    u = x1 + x0 | 0;
    x2 ^= u<<9 | u>>>(32-9);
    u = x2 + x1 | 0;
    x3 ^= u<<13 | u>>>(32-13);
    u = x3 + x2 | 0;
    x0 ^= u<<18 | u>>>(32-18);

    u = x5 + x4 | 0;
    x6 ^= u<<7 | u>>>(32-7);
    u = x6 + x5 | 0;
    x7 ^= u<<9 | u>>>(32-9);
    u = x7 + x6 | 0;
    x4 ^= u<<13 | u>>>(32-13);
    u = x4 + x7 | 0;
    x5 ^= u<<18 | u>>>(32-18);

    u = x10 + x9 | 0;
    x11 ^= u<<7 | u>>>(32-7);
    u = x11 + x10 | 0;
    x8 ^= u<<9 | u>>>(32-9);
    u = x8 + x11 | 0;
    x9 ^= u<<13 | u>>>(32-13);
    u = x9 + x8 | 0;
    x10 ^= u<<18 | u>>>(32-18);

    u = x15 + x14 | 0;
    x12 ^= u<<7 | u>>>(32-7);
    u = x12 + x15 | 0;
    x13 ^= u<<9 | u>>>(32-9);
    u = x13 + x12 | 0;
    x14 ^= u<<13 | u>>>(32-13);
    u = x14 + x13 | 0;
    x15 ^= u<<18 | u>>>(32-18);
  }

  o[ 0] = x0 >>>  0 & 0xff;
  o[ 1] = x0 >>>  8 & 0xff;
  o[ 2] = x0 >>> 16 & 0xff;
  o[ 3] = x0 >>> 24 & 0xff;

  o[ 4] = x5 >>>  0 & 0xff;
  o[ 5] = x5 >>>  8 & 0xff;
  o[ 6] = x5 >>> 16 & 0xff;
  o[ 7] = x5 >>> 24 & 0xff;

  o[ 8] = x10 >>>  0 & 0xff;
  o[ 9] = x10 >>>  8 & 0xff;
  o[10] = x10 >>> 16 & 0xff;
  o[11] = x10 >>> 24 & 0xff;

  o[12] = x15 >>>  0 & 0xff;
  o[13] = x15 >>>  8 & 0xff;
  o[14] = x15 >>> 16 & 0xff;
  o[15] = x15 >>> 24 & 0xff;

  o[16] = x6 >>>  0 & 0xff;
  o[17] = x6 >>>  8 & 0xff;
  o[18] = x6 >>> 16 & 0xff;
  o[19] = x6 >>> 24 & 0xff;

  o[20] = x7 >>>  0 & 0xff;
  o[21] = x7 >>>  8 & 0xff;
  o[22] = x7 >>> 16 & 0xff;
  o[23] = x7 >>> 24 & 0xff;

  o[24] = x8 >>>  0 & 0xff;
  o[25] = x8 >>>  8 & 0xff;
  o[26] = x8 >>> 16 & 0xff;
  o[27] = x8 >>> 24 & 0xff;

  o[28] = x9 >>>  0 & 0xff;
  o[29] = x9 >>>  8 & 0xff;
  o[30] = x9 >>> 16 & 0xff;
  o[31] = x9 >>> 24 & 0xff;
}

function crypto_core_salsa20(out,inp,k,c) {
  core_salsa20(out,inp,k,c);
}

function crypto_core_hsalsa20(out,inp,k,c) {
  core_hsalsa20(out,inp,k,c);
}

var sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
            // "expand 32-byte k"

function crypto_stream_salsa20_xor(c,cpos,m,mpos,b,n,k) {
  var z = new Uint8Array(16), x = new Uint8Array(64);
  var u, i;
  for (i = 0; i < 16; i++) z[i] = 0;
  for (i = 0; i < 8; i++) z[i] = n[i];
  while (b >= 64) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < 64; i++) c[cpos+i] = m[mpos+i] ^ x[i];
    u = 1;
    for (i = 8; i < 16; i++) {
      u = u + (z[i] & 0xff) | 0;
      z[i] = u & 0xff;
      u >>>= 8;
    }
    b -= 64;
    cpos += 64;
    mpos += 64;
  }
  if (b > 0) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < b; i++) c[cpos+i] = m[mpos+i] ^ x[i];
  }
  return 0;
}

function crypto_stream_salsa20(c,cpos,b,n,k) {
  var z = new Uint8Array(16), x = new Uint8Array(64);
  var u, i;
  for (i = 0; i < 16; i++) z[i] = 0;
  for (i = 0; i < 8; i++) z[i] = n[i];
  while (b >= 64) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < 64; i++) c[cpos+i] = x[i];
    u = 1;
    for (i = 8; i < 16; i++) {
      u = u + (z[i] & 0xff) | 0;
      z[i] = u & 0xff;
      u >>>= 8;
    }
    b -= 64;
    cpos += 64;
  }
  if (b > 0) {
    crypto_core_salsa20(x,z,k,sigma);
    for (i = 0; i < b; i++) c[cpos+i] = x[i];
  }
  return 0;
}

function crypto_stream(c,cpos,d,n,k) {
  var s = new Uint8Array(32);
  crypto_core_hsalsa20(s,n,k,sigma);
  var sn = new Uint8Array(8);
  for (var i = 0; i < 8; i++) sn[i] = n[i+16];
  return crypto_stream_salsa20(c,cpos,d,sn,s);
}

function crypto_stream_xor(c,cpos,m,mpos,d,n,k) {
  var s = new Uint8Array(32);
  crypto_core_hsalsa20(s,n,k,sigma);
  var sn = new Uint8Array(8);
  for (var i = 0; i < 8; i++) sn[i] = n[i+16];
  return crypto_stream_salsa20_xor(c,cpos,m,mpos,d,sn,s);
}

/*
* Port of Andrew Moon's Poly1305-donna-16. Public domain.
* https://github.com/floodyberry/poly1305-donna
*/

var poly1305 = function(key) {
  this.buffer = new Uint8Array(16);
  this.r = new Uint16Array(10);
  this.h = new Uint16Array(10);
  this.pad = new Uint16Array(8);
  this.leftover = 0;
  this.fin = 0;

  var t0, t1, t2, t3, t4, t5, t6, t7;

  t0 = key[ 0] & 0xff | (key[ 1] & 0xff) << 8; this.r[0] = ( t0                     ) & 0x1fff;
  t1 = key[ 2] & 0xff | (key[ 3] & 0xff) << 8; this.r[1] = ((t0 >>> 13) | (t1 <<  3)) & 0x1fff;
  t2 = key[ 4] & 0xff | (key[ 5] & 0xff) << 8; this.r[2] = ((t1 >>> 10) | (t2 <<  6)) & 0x1f03;
  t3 = key[ 6] & 0xff | (key[ 7] & 0xff) << 8; this.r[3] = ((t2 >>>  7) | (t3 <<  9)) & 0x1fff;
  t4 = key[ 8] & 0xff | (key[ 9] & 0xff) << 8; this.r[4] = ((t3 >>>  4) | (t4 << 12)) & 0x00ff;
  this.r[5] = ((t4 >>>  1)) & 0x1ffe;
  t5 = key[10] & 0xff | (key[11] & 0xff) << 8; this.r[6] = ((t4 >>> 14) | (t5 <<  2)) & 0x1fff;
  t6 = key[12] & 0xff | (key[13] & 0xff) << 8; this.r[7] = ((t5 >>> 11) | (t6 <<  5)) & 0x1f81;
  t7 = key[14] & 0xff | (key[15] & 0xff) << 8; this.r[8] = ((t6 >>>  8) | (t7 <<  8)) & 0x1fff;
  this.r[9] = ((t7 >>>  5)) & 0x007f;

  this.pad[0] = key[16] & 0xff | (key[17] & 0xff) << 8;
  this.pad[1] = key[18] & 0xff | (key[19] & 0xff) << 8;
  this.pad[2] = key[20] & 0xff | (key[21] & 0xff) << 8;
  this.pad[3] = key[22] & 0xff | (key[23] & 0xff) << 8;
  this.pad[4] = key[24] & 0xff | (key[25] & 0xff) << 8;
  this.pad[5] = key[26] & 0xff | (key[27] & 0xff) << 8;
  this.pad[6] = key[28] & 0xff | (key[29] & 0xff) << 8;
  this.pad[7] = key[30] & 0xff | (key[31] & 0xff) << 8;
};

poly1305.prototype.blocks = function(m, mpos, bytes) {
  var hibit = this.fin ? 0 : (1 << 11);
  var t0, t1, t2, t3, t4, t5, t6, t7, c;
  var d0, d1, d2, d3, d4, d5, d6, d7, d8, d9;

  var h0 = this.h[0],
      h1 = this.h[1],
      h2 = this.h[2],
      h3 = this.h[3],
      h4 = this.h[4],
      h5 = this.h[5],
      h6 = this.h[6],
      h7 = this.h[7],
      h8 = this.h[8],
      h9 = this.h[9];

  var r0 = this.r[0],
      r1 = this.r[1],
      r2 = this.r[2],
      r3 = this.r[3],
      r4 = this.r[4],
      r5 = this.r[5],
      r6 = this.r[6],
      r7 = this.r[7],
      r8 = this.r[8],
      r9 = this.r[9];

  while (bytes >= 16) {
    t0 = m[mpos+ 0] & 0xff | (m[mpos+ 1] & 0xff) << 8; h0 += ( t0                     ) & 0x1fff;
    t1 = m[mpos+ 2] & 0xff | (m[mpos+ 3] & 0xff) << 8; h1 += ((t0 >>> 13) | (t1 <<  3)) & 0x1fff;
    t2 = m[mpos+ 4] & 0xff | (m[mpos+ 5] & 0xff) << 8; h2 += ((t1 >>> 10) | (t2 <<  6)) & 0x1fff;
    t3 = m[mpos+ 6] & 0xff | (m[mpos+ 7] & 0xff) << 8; h3 += ((t2 >>>  7) | (t3 <<  9)) & 0x1fff;
    t4 = m[mpos+ 8] & 0xff | (m[mpos+ 9] & 0xff) << 8; h4 += ((t3 >>>  4) | (t4 << 12)) & 0x1fff;
    h5 += ((t4 >>>  1)) & 0x1fff;
    t5 = m[mpos+10] & 0xff | (m[mpos+11] & 0xff) << 8; h6 += ((t4 >>> 14) | (t5 <<  2)) & 0x1fff;
    t6 = m[mpos+12] & 0xff | (m[mpos+13] & 0xff) << 8; h7 += ((t5 >>> 11) | (t6 <<  5)) & 0x1fff;
    t7 = m[mpos+14] & 0xff | (m[mpos+15] & 0xff) << 8; h8 += ((t6 >>>  8) | (t7 <<  8)) & 0x1fff;
    h9 += ((t7 >>> 5)) | hibit;

    c = 0;

    d0 = c;
    d0 += h0 * r0;
    d0 += h1 * (5 * r9);
    d0 += h2 * (5 * r8);
    d0 += h3 * (5 * r7);
    d0 += h4 * (5 * r6);
    c = (d0 >>> 13); d0 &= 0x1fff;
    d0 += h5 * (5 * r5);
    d0 += h6 * (5 * r4);
    d0 += h7 * (5 * r3);
    d0 += h8 * (5 * r2);
    d0 += h9 * (5 * r1);
    c += (d0 >>> 13); d0 &= 0x1fff;

    d1 = c;
    d1 += h0 * r1;
    d1 += h1 * r0;
    d1 += h2 * (5 * r9);
    d1 += h3 * (5 * r8);
    d1 += h4 * (5 * r7);
    c = (d1 >>> 13); d1 &= 0x1fff;
    d1 += h5 * (5 * r6);
    d1 += h6 * (5 * r5);
    d1 += h7 * (5 * r4);
    d1 += h8 * (5 * r3);
    d1 += h9 * (5 * r2);
    c += (d1 >>> 13); d1 &= 0x1fff;

    d2 = c;
    d2 += h0 * r2;
    d2 += h1 * r1;
    d2 += h2 * r0;
    d2 += h3 * (5 * r9);
    d2 += h4 * (5 * r8);
    c = (d2 >>> 13); d2 &= 0x1fff;
    d2 += h5 * (5 * r7);
    d2 += h6 * (5 * r6);
    d2 += h7 * (5 * r5);
    d2 += h8 * (5 * r4);
    d2 += h9 * (5 * r3);
    c += (d2 >>> 13); d2 &= 0x1fff;

    d3 = c;
    d3 += h0 * r3;
    d3 += h1 * r2;
    d3 += h2 * r1;
    d3 += h3 * r0;
    d3 += h4 * (5 * r9);
    c = (d3 >>> 13); d3 &= 0x1fff;
    d3 += h5 * (5 * r8);
    d3 += h6 * (5 * r7);
    d3 += h7 * (5 * r6);
    d3 += h8 * (5 * r5);
    d3 += h9 * (5 * r4);
    c += (d3 >>> 13); d3 &= 0x1fff;

    d4 = c;
    d4 += h0 * r4;
    d4 += h1 * r3;
    d4 += h2 * r2;
    d4 += h3 * r1;
    d4 += h4 * r0;
    c = (d4 >>> 13); d4 &= 0x1fff;
    d4 += h5 * (5 * r9);
    d4 += h6 * (5 * r8);
    d4 += h7 * (5 * r7);
    d4 += h8 * (5 * r6);
    d4 += h9 * (5 * r5);
    c += (d4 >>> 13); d4 &= 0x1fff;

    d5 = c;
    d5 += h0 * r5;
    d5 += h1 * r4;
    d5 += h2 * r3;
    d5 += h3 * r2;
    d5 += h4 * r1;
    c = (d5 >>> 13); d5 &= 0x1fff;
    d5 += h5 * r0;
    d5 += h6 * (5 * r9);
    d5 += h7 * (5 * r8);
    d5 += h8 * (5 * r7);
    d5 += h9 * (5 * r6);
    c += (d5 >>> 13); d5 &= 0x1fff;

    d6 = c;
    d6 += h0 * r6;
    d6 += h1 * r5;
    d6 += h2 * r4;
    d6 += h3 * r3;
    d6 += h4 * r2;
    c = (d6 >>> 13); d6 &= 0x1fff;
    d6 += h5 * r1;
    d6 += h6 * r0;
    d6 += h7 * (5 * r9);
    d6 += h8 * (5 * r8);
    d6 += h9 * (5 * r7);
    c += (d6 >>> 13); d6 &= 0x1fff;

    d7 = c;
    d7 += h0 * r7;
    d7 += h1 * r6;
    d7 += h2 * r5;
    d7 += h3 * r4;
    d7 += h4 * r3;
    c = (d7 >>> 13); d7 &= 0x1fff;
    d7 += h5 * r2;
    d7 += h6 * r1;
    d7 += h7 * r0;
    d7 += h8 * (5 * r9);
    d7 += h9 * (5 * r8);
    c += (d7 >>> 13); d7 &= 0x1fff;

    d8 = c;
    d8 += h0 * r8;
    d8 += h1 * r7;
    d8 += h2 * r6;
    d8 += h3 * r5;
    d8 += h4 * r4;
    c = (d8 >>> 13); d8 &= 0x1fff;
    d8 += h5 * r3;
    d8 += h6 * r2;
    d8 += h7 * r1;
    d8 += h8 * r0;
    d8 += h9 * (5 * r9);
    c += (d8 >>> 13); d8 &= 0x1fff;

    d9 = c;
    d9 += h0 * r9;
    d9 += h1 * r8;
    d9 += h2 * r7;
    d9 += h3 * r6;
    d9 += h4 * r5;
    c = (d9 >>> 13); d9 &= 0x1fff;
    d9 += h5 * r4;
    d9 += h6 * r3;
    d9 += h7 * r2;
    d9 += h8 * r1;
    d9 += h9 * r0;
    c += (d9 >>> 13); d9 &= 0x1fff;

    c = (((c << 2) + c)) | 0;
    c = (c + d0) | 0;
    d0 = c & 0x1fff;
    c = (c >>> 13);
    d1 += c;

    h0 = d0;
    h1 = d1;
    h2 = d2;
    h3 = d3;
    h4 = d4;
    h5 = d5;
    h6 = d6;
    h7 = d7;
    h8 = d8;
    h9 = d9;

    mpos += 16;
    bytes -= 16;
  }
  this.h[0] = h0;
  this.h[1] = h1;
  this.h[2] = h2;
  this.h[3] = h3;
  this.h[4] = h4;
  this.h[5] = h5;
  this.h[6] = h6;
  this.h[7] = h7;
  this.h[8] = h8;
  this.h[9] = h9;
};

poly1305.prototype.finish = function(mac, macpos) {
  var g = new Uint16Array(10);
  var c, mask, f, i;

  if (this.leftover) {
    i = this.leftover;
    this.buffer[i++] = 1;
    for (; i < 16; i++) this.buffer[i] = 0;
    this.fin = 1;
    this.blocks(this.buffer, 0, 16);
  }

  c = this.h[1] >>> 13;
  this.h[1] &= 0x1fff;
  for (i = 2; i < 10; i++) {
    this.h[i] += c;
    c = this.h[i] >>> 13;
    this.h[i] &= 0x1fff;
  }
  this.h[0] += (c * 5);
  c = this.h[0] >>> 13;
  this.h[0] &= 0x1fff;
  this.h[1] += c;
  c = this.h[1] >>> 13;
  this.h[1] &= 0x1fff;
  this.h[2] += c;

  g[0] = this.h[0] + 5;
  c = g[0] >>> 13;
  g[0] &= 0x1fff;
  for (i = 1; i < 10; i++) {
    g[i] = this.h[i] + c;
    c = g[i] >>> 13;
    g[i] &= 0x1fff;
  }
  g[9] -= (1 << 13);

  mask = (c ^ 1) - 1;
  for (i = 0; i < 10; i++) g[i] &= mask;
  mask = ~mask;
  for (i = 0; i < 10; i++) this.h[i] = (this.h[i] & mask) | g[i];

  this.h[0] = ((this.h[0]       ) | (this.h[1] << 13)                    ) & 0xffff;
  this.h[1] = ((this.h[1] >>>  3) | (this.h[2] << 10)                    ) & 0xffff;
  this.h[2] = ((this.h[2] >>>  6) | (this.h[3] <<  7)                    ) & 0xffff;
  this.h[3] = ((this.h[3] >>>  9) | (this.h[4] <<  4)                    ) & 0xffff;
  this.h[4] = ((this.h[4] >>> 12) | (this.h[5] <<  1) | (this.h[6] << 14)) & 0xffff;
  this.h[5] = ((this.h[6] >>>  2) | (this.h[7] << 11)                    ) & 0xffff;
  this.h[6] = ((this.h[7] >>>  5) | (this.h[8] <<  8)                    ) & 0xffff;
  this.h[7] = ((this.h[8] >>>  8) | (this.h[9] <<  5)                    ) & 0xffff;

  f = this.h[0] + this.pad[0];
  this.h[0] = f & 0xffff;
  for (i = 1; i < 8; i++) {
    f = (((this.h[i] + this.pad[i]) | 0) + (f >>> 16)) | 0;
    this.h[i] = f & 0xffff;
  }

  mac[macpos+ 0] = (this.h[0] >>> 0) & 0xff;
  mac[macpos+ 1] = (this.h[0] >>> 8) & 0xff;
  mac[macpos+ 2] = (this.h[1] >>> 0) & 0xff;
  mac[macpos+ 3] = (this.h[1] >>> 8) & 0xff;
  mac[macpos+ 4] = (this.h[2] >>> 0) & 0xff;
  mac[macpos+ 5] = (this.h[2] >>> 8) & 0xff;
  mac[macpos+ 6] = (this.h[3] >>> 0) & 0xff;
  mac[macpos+ 7] = (this.h[3] >>> 8) & 0xff;
  mac[macpos+ 8] = (this.h[4] >>> 0) & 0xff;
  mac[macpos+ 9] = (this.h[4] >>> 8) & 0xff;
  mac[macpos+10] = (this.h[5] >>> 0) & 0xff;
  mac[macpos+11] = (this.h[5] >>> 8) & 0xff;
  mac[macpos+12] = (this.h[6] >>> 0) & 0xff;
  mac[macpos+13] = (this.h[6] >>> 8) & 0xff;
  mac[macpos+14] = (this.h[7] >>> 0) & 0xff;
  mac[macpos+15] = (this.h[7] >>> 8) & 0xff;
};

poly1305.prototype.update = function(m, mpos, bytes) {
  var i, want;

  if (this.leftover) {
    want = (16 - this.leftover);
    if (want > bytes)
      want = bytes;
    for (i = 0; i < want; i++)
      this.buffer[this.leftover + i] = m[mpos+i];
    bytes -= want;
    mpos += want;
    this.leftover += want;
    if (this.leftover < 16)
      return;
    this.blocks(this.buffer, 0, 16);
    this.leftover = 0;
  }

  if (bytes >= 16) {
    want = bytes - (bytes % 16);
    this.blocks(m, mpos, want);
    mpos += want;
    bytes -= want;
  }

  if (bytes) {
    for (i = 0; i < bytes; i++)
      this.buffer[this.leftover + i] = m[mpos+i];
    this.leftover += bytes;
  }
};

function crypto_onetimeauth(out, outpos, m, mpos, n, k) {
  var s = new poly1305(k);
  s.update(m, mpos, n);
  s.finish(out, outpos);
  return 0;
}

function crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {
  var x = new Uint8Array(16);
  crypto_onetimeauth(x,0,m,mpos,n,k);
  return crypto_verify_16(h,hpos,x,0);
}

function crypto_secretbox(c,m,d,n,k) {
  var i;
  if (d < 32) return -1;
  crypto_stream_xor(c,0,m,0,d,n,k);
  crypto_onetimeauth(c, 16, c, 32, d - 32, c);
  for (i = 0; i < 16; i++) c[i] = 0;
  return 0;
}

function crypto_secretbox_open(m,c,d,n,k) {
  var i;
  var x = new Uint8Array(32);
  if (d < 32) return -1;
  crypto_stream(x,0,32,n,k);
  if (crypto_onetimeauth_verify(c, 16,c, 32,d - 32,x) !== 0) return -1;
  crypto_stream_xor(m,0,c,0,d,n,k);
  for (i = 0; i < 32; i++) m[i] = 0;
  return 0;
}

function set25519(r, a) {
  var i;
  for (i = 0; i < 16; i++) r[i] = a[i]|0;
}

function car25519(o) {
  var i, v, c = 1;
  for (i = 0; i < 16; i++) {
    v = o[i] + c + 65535;
    c = Math.floor(v / 65536);
    o[i] = v - c * 65536;
  }
  o[0] += c-1 + 37 * (c-1);
}

function sel25519(p, q, b) {
  var t, c = ~(b-1);
  for (var i = 0; i < 16; i++) {
    t = c & (p[i] ^ q[i]);
    p[i] ^= t;
    q[i] ^= t;
  }
}

function pack25519(o, n) {
  var i, j, b;
  var m = gf(), t = gf();
  for (i = 0; i < 16; i++) t[i] = n[i];
  car25519(t);
  car25519(t);
  car25519(t);
  for (j = 0; j < 2; j++) {
    m[0] = t[0] - 0xffed;
    for (i = 1; i < 15; i++) {
      m[i] = t[i] - 0xffff - ((m[i-1]>>16) & 1);
      m[i-1] &= 0xffff;
    }
    m[15] = t[15] - 0x7fff - ((m[14]>>16) & 1);
    b = (m[15]>>16) & 1;
    m[14] &= 0xffff;
    sel25519(t, m, 1-b);
  }
  for (i = 0; i < 16; i++) {
    o[2*i] = t[i] & 0xff;
    o[2*i+1] = t[i]>>8;
  }
}

function neq25519(a, b) {
  var c = new Uint8Array(32), d = new Uint8Array(32);
  pack25519(c, a);
  pack25519(d, b);
  return crypto_verify_32(c, 0, d, 0);
}

function par25519(a) {
  var d = new Uint8Array(32);
  pack25519(d, a);
  return d[0] & 1;
}

function unpack25519(o, n) {
  var i;
  for (i = 0; i < 16; i++) o[i] = n[2*i] + (n[2*i+1] << 8);
  o[15] &= 0x7fff;
}

function A(o, a, b) {
  for (var i = 0; i < 16; i++) o[i] = a[i] + b[i];
}

function Z(o, a, b) {
  for (var i = 0; i < 16; i++) o[i] = a[i] - b[i];
}

function M(o, a, b) {
  var v, c,
     t0 = 0,  t1 = 0,  t2 = 0,  t3 = 0,  t4 = 0,  t5 = 0,  t6 = 0,  t7 = 0,
     t8 = 0,  t9 = 0, t10 = 0, t11 = 0, t12 = 0, t13 = 0, t14 = 0, t15 = 0,
    t16 = 0, t17 = 0, t18 = 0, t19 = 0, t20 = 0, t21 = 0, t22 = 0, t23 = 0,
    t24 = 0, t25 = 0, t26 = 0, t27 = 0, t28 = 0, t29 = 0, t30 = 0,
    b0 = b[0],
    b1 = b[1],
    b2 = b[2],
    b3 = b[3],
    b4 = b[4],
    b5 = b[5],
    b6 = b[6],
    b7 = b[7],
    b8 = b[8],
    b9 = b[9],
    b10 = b[10],
    b11 = b[11],
    b12 = b[12],
    b13 = b[13],
    b14 = b[14],
    b15 = b[15];

  v = a[0];
  t0 += v * b0;
  t1 += v * b1;
  t2 += v * b2;
  t3 += v * b3;
  t4 += v * b4;
  t5 += v * b5;
  t6 += v * b6;
  t7 += v * b7;
  t8 += v * b8;
  t9 += v * b9;
  t10 += v * b10;
  t11 += v * b11;
  t12 += v * b12;
  t13 += v * b13;
  t14 += v * b14;
  t15 += v * b15;
  v = a[1];
  t1 += v * b0;
  t2 += v * b1;
  t3 += v * b2;
  t4 += v * b3;
  t5 += v * b4;
  t6 += v * b5;
  t7 += v * b6;
  t8 += v * b7;
  t9 += v * b8;
  t10 += v * b9;
  t11 += v * b10;
  t12 += v * b11;
  t13 += v * b12;
  t14 += v * b13;
  t15 += v * b14;
  t16 += v * b15;
  v = a[2];
  t2 += v * b0;
  t3 += v * b1;
  t4 += v * b2;
  t5 += v * b3;
  t6 += v * b4;
  t7 += v * b5;
  t8 += v * b6;
  t9 += v * b7;
  t10 += v * b8;
  t11 += v * b9;
  t12 += v * b10;
  t13 += v * b11;
  t14 += v * b12;
  t15 += v * b13;
  t16 += v * b14;
  t17 += v * b15;
  v = a[3];
  t3 += v * b0;
  t4 += v * b1;
  t5 += v * b2;
  t6 += v * b3;
  t7 += v * b4;
  t8 += v * b5;
  t9 += v * b6;
  t10 += v * b7;
  t11 += v * b8;
  t12 += v * b9;
  t13 += v * b10;
  t14 += v * b11;
  t15 += v * b12;
  t16 += v * b13;
  t17 += v * b14;
  t18 += v * b15;
  v = a[4];
  t4 += v * b0;
  t5 += v * b1;
  t6 += v * b2;
  t7 += v * b3;
  t8 += v * b4;
  t9 += v * b5;
  t10 += v * b6;
  t11 += v * b7;
  t12 += v * b8;
  t13 += v * b9;
  t14 += v * b10;
  t15 += v * b11;
  t16 += v * b12;
  t17 += v * b13;
  t18 += v * b14;
  t19 += v * b15;
  v = a[5];
  t5 += v * b0;
  t6 += v * b1;
  t7 += v * b2;
  t8 += v * b3;
  t9 += v * b4;
  t10 += v * b5;
  t11 += v * b6;
  t12 += v * b7;
  t13 += v * b8;
  t14 += v * b9;
  t15 += v * b10;
  t16 += v * b11;
  t17 += v * b12;
  t18 += v * b13;
  t19 += v * b14;
  t20 += v * b15;
  v = a[6];
  t6 += v * b0;
  t7 += v * b1;
  t8 += v * b2;
  t9 += v * b3;
  t10 += v * b4;
  t11 += v * b5;
  t12 += v * b6;
  t13 += v * b7;
  t14 += v * b8;
  t15 += v * b9;
  t16 += v * b10;
  t17 += v * b11;
  t18 += v * b12;
  t19 += v * b13;
  t20 += v * b14;
  t21 += v * b15;
  v = a[7];
  t7 += v * b0;
  t8 += v * b1;
  t9 += v * b2;
  t10 += v * b3;
  t11 += v * b4;
  t12 += v * b5;
  t13 += v * b6;
  t14 += v * b7;
  t15 += v * b8;
  t16 += v * b9;
  t17 += v * b10;
  t18 += v * b11;
  t19 += v * b12;
  t20 += v * b13;
  t21 += v * b14;
  t22 += v * b15;
  v = a[8];
  t8 += v * b0;
  t9 += v * b1;
  t10 += v * b2;
  t11 += v * b3;
  t12 += v * b4;
  t13 += v * b5;
  t14 += v * b6;
  t15 += v * b7;
  t16 += v * b8;
  t17 += v * b9;
  t18 += v * b10;
  t19 += v * b11;
  t20 += v * b12;
  t21 += v * b13;
  t22 += v * b14;
  t23 += v * b15;
  v = a[9];
  t9 += v * b0;
  t10 += v * b1;
  t11 += v * b2;
  t12 += v * b3;
  t13 += v * b4;
  t14 += v * b5;
  t15 += v * b6;
  t16 += v * b7;
  t17 += v * b8;
  t18 += v * b9;
  t19 += v * b10;
  t20 += v * b11;
  t21 += v * b12;
  t22 += v * b13;
  t23 += v * b14;
  t24 += v * b15;
  v = a[10];
  t10 += v * b0;
  t11 += v * b1;
  t12 += v * b2;
  t13 += v * b3;
  t14 += v * b4;
  t15 += v * b5;
  t16 += v * b6;
  t17 += v * b7;
  t18 += v * b8;
  t19 += v * b9;
  t20 += v * b10;
  t21 += v * b11;
  t22 += v * b12;
  t23 += v * b13;
  t24 += v * b14;
  t25 += v * b15;
  v = a[11];
  t11 += v * b0;
  t12 += v * b1;
  t13 += v * b2;
  t14 += v * b3;
  t15 += v * b4;
  t16 += v * b5;
  t17 += v * b6;
  t18 += v * b7;
  t19 += v * b8;
  t20 += v * b9;
  t21 += v * b10;
  t22 += v * b11;
  t23 += v * b12;
  t24 += v * b13;
  t25 += v * b14;
  t26 += v * b15;
  v = a[12];
  t12 += v * b0;
  t13 += v * b1;
  t14 += v * b2;
  t15 += v * b3;
  t16 += v * b4;
  t17 += v * b5;
  t18 += v * b6;
  t19 += v * b7;
  t20 += v * b8;
  t21 += v * b9;
  t22 += v * b10;
  t23 += v * b11;
  t24 += v * b12;
  t25 += v * b13;
  t26 += v * b14;
  t27 += v * b15;
  v = a[13];
  t13 += v * b0;
  t14 += v * b1;
  t15 += v * b2;
  t16 += v * b3;
  t17 += v * b4;
  t18 += v * b5;
  t19 += v * b6;
  t20 += v * b7;
  t21 += v * b8;
  t22 += v * b9;
  t23 += v * b10;
  t24 += v * b11;
  t25 += v * b12;
  t26 += v * b13;
  t27 += v * b14;
  t28 += v * b15;
  v = a[14];
  t14 += v * b0;
  t15 += v * b1;
  t16 += v * b2;
  t17 += v * b3;
  t18 += v * b4;
  t19 += v * b5;
  t20 += v * b6;
  t21 += v * b7;
  t22 += v * b8;
  t23 += v * b9;
  t24 += v * b10;
  t25 += v * b11;
  t26 += v * b12;
  t27 += v * b13;
  t28 += v * b14;
  t29 += v * b15;
  v = a[15];
  t15 += v * b0;
  t16 += v * b1;
  t17 += v * b2;
  t18 += v * b3;
  t19 += v * b4;
  t20 += v * b5;
  t21 += v * b6;
  t22 += v * b7;
  t23 += v * b8;
  t24 += v * b9;
  t25 += v * b10;
  t26 += v * b11;
  t27 += v * b12;
  t28 += v * b13;
  t29 += v * b14;
  t30 += v * b15;

  t0  += 38 * t16;
  t1  += 38 * t17;
  t2  += 38 * t18;
  t3  += 38 * t19;
  t4  += 38 * t20;
  t5  += 38 * t21;
  t6  += 38 * t22;
  t7  += 38 * t23;
  t8  += 38 * t24;
  t9  += 38 * t25;
  t10 += 38 * t26;
  t11 += 38 * t27;
  t12 += 38 * t28;
  t13 += 38 * t29;
  t14 += 38 * t30;
  // t15 left as is

  // first car
  c = 1;
  v =  t0 + c + 65535; c = Math.floor(v / 65536);  t0 = v - c * 65536;
  v =  t1 + c + 65535; c = Math.floor(v / 65536);  t1 = v - c * 65536;
  v =  t2 + c + 65535; c = Math.floor(v / 65536);  t2 = v - c * 65536;
  v =  t3 + c + 65535; c = Math.floor(v / 65536);  t3 = v - c * 65536;
  v =  t4 + c + 65535; c = Math.floor(v / 65536);  t4 = v - c * 65536;
  v =  t5 + c + 65535; c = Math.floor(v / 65536);  t5 = v - c * 65536;
  v =  t6 + c + 65535; c = Math.floor(v / 65536);  t6 = v - c * 65536;
  v =  t7 + c + 65535; c = Math.floor(v / 65536);  t7 = v - c * 65536;
  v =  t8 + c + 65535; c = Math.floor(v / 65536);  t8 = v - c * 65536;
  v =  t9 + c + 65535; c = Math.floor(v / 65536);  t9 = v - c * 65536;
  v = t10 + c + 65535; c = Math.floor(v / 65536); t10 = v - c * 65536;
  v = t11 + c + 65535; c = Math.floor(v / 65536); t11 = v - c * 65536;
  v = t12 + c + 65535; c = Math.floor(v / 65536); t12 = v - c * 65536;
  v = t13 + c + 65535; c = Math.floor(v / 65536); t13 = v - c * 65536;
  v = t14 + c + 65535; c = Math.floor(v / 65536); t14 = v - c * 65536;
  v = t15 + c + 65535; c = Math.floor(v / 65536); t15 = v - c * 65536;
  t0 += c-1 + 37 * (c-1);

  // second car
  c = 1;
  v =  t0 + c + 65535; c = Math.floor(v / 65536);  t0 = v - c * 65536;
  v =  t1 + c + 65535; c = Math.floor(v / 65536);  t1 = v - c * 65536;
  v =  t2 + c + 65535; c = Math.floor(v / 65536);  t2 = v - c * 65536;
  v =  t3 + c + 65535; c = Math.floor(v / 65536);  t3 = v - c * 65536;
  v =  t4 + c + 65535; c = Math.floor(v / 65536);  t4 = v - c * 65536;
  v =  t5 + c + 65535; c = Math.floor(v / 65536);  t5 = v - c * 65536;
  v =  t6 + c + 65535; c = Math.floor(v / 65536);  t6 = v - c * 65536;
  v =  t7 + c + 65535; c = Math.floor(v / 65536);  t7 = v - c * 65536;
  v =  t8 + c + 65535; c = Math.floor(v / 65536);  t8 = v - c * 65536;
  v =  t9 + c + 65535; c = Math.floor(v / 65536);  t9 = v - c * 65536;
  v = t10 + c + 65535; c = Math.floor(v / 65536); t10 = v - c * 65536;
  v = t11 + c + 65535; c = Math.floor(v / 65536); t11 = v - c * 65536;
  v = t12 + c + 65535; c = Math.floor(v / 65536); t12 = v - c * 65536;
  v = t13 + c + 65535; c = Math.floor(v / 65536); t13 = v - c * 65536;
  v = t14 + c + 65535; c = Math.floor(v / 65536); t14 = v - c * 65536;
  v = t15 + c + 65535; c = Math.floor(v / 65536); t15 = v - c * 65536;
  t0 += c-1 + 37 * (c-1);

  o[ 0] = t0;
  o[ 1] = t1;
  o[ 2] = t2;
  o[ 3] = t3;
  o[ 4] = t4;
  o[ 5] = t5;
  o[ 6] = t6;
  o[ 7] = t7;
  o[ 8] = t8;
  o[ 9] = t9;
  o[10] = t10;
  o[11] = t11;
  o[12] = t12;
  o[13] = t13;
  o[14] = t14;
  o[15] = t15;
}

function S(o, a) {
  M(o, a, a);
}

function inv25519(o, i) {
  var c = gf();
  var a;
  for (a = 0; a < 16; a++) c[a] = i[a];
  for (a = 253; a >= 0; a--) {
    S(c, c);
    if(a !== 2 && a !== 4) M(c, c, i);
  }
  for (a = 0; a < 16; a++) o[a] = c[a];
}

function pow2523(o, i) {
  var c = gf();
  var a;
  for (a = 0; a < 16; a++) c[a] = i[a];
  for (a = 250; a >= 0; a--) {
      S(c, c);
      if(a !== 1) M(c, c, i);
  }
  for (a = 0; a < 16; a++) o[a] = c[a];
}

function crypto_scalarmult(q, n, p) {
  var z = new Uint8Array(32);
  var x = new Float64Array(80), r, i;
  var a = gf(), b = gf(), c = gf(),
      d = gf(), e = gf(), f = gf();
  for (i = 0; i < 31; i++) z[i] = n[i];
  z[31]=(n[31]&127)|64;
  z[0]&=248;
  unpack25519(x,p);
  for (i = 0; i < 16; i++) {
    b[i]=x[i];
    d[i]=a[i]=c[i]=0;
  }
  a[0]=d[0]=1;
  for (i=254; i>=0; --i) {
    r=(z[i>>>3]>>>(i&7))&1;
    sel25519(a,b,r);
    sel25519(c,d,r);
    A(e,a,c);
    Z(a,a,c);
    A(c,b,d);
    Z(b,b,d);
    S(d,e);
    S(f,a);
    M(a,c,a);
    M(c,b,e);
    A(e,a,c);
    Z(a,a,c);
    S(b,a);
    Z(c,d,f);
    M(a,c,_121665);
    A(a,a,d);
    M(c,c,a);
    M(a,d,f);
    M(d,b,x);
    S(b,e);
    sel25519(a,b,r);
    sel25519(c,d,r);
  }
  for (i = 0; i < 16; i++) {
    x[i+16]=a[i];
    x[i+32]=c[i];
    x[i+48]=b[i];
    x[i+64]=d[i];
  }
  var x32 = x.subarray(32);
  var x16 = x.subarray(16);
  inv25519(x32,x32);
  M(x16,x16,x32);
  pack25519(q,x16);
  return 0;
}

function crypto_scalarmult_base(q, n) {
  return crypto_scalarmult(q, n, _9);
}

function crypto_box_keypair(y, x) {
  randombytes(x, 32);
  return crypto_scalarmult_base(y, x);
}

function crypto_box_beforenm(k, y, x) {
  var s = new Uint8Array(32);
  crypto_scalarmult(s, x, y);
  return crypto_core_hsalsa20(k, _0, s, sigma);
}

var crypto_box_afternm = crypto_secretbox;
var crypto_box_open_afternm = crypto_secretbox_open;

function crypto_box(c, m, d, n, y, x) {
  var k = new Uint8Array(32);
  crypto_box_beforenm(k, y, x);
  return crypto_box_afternm(c, m, d, n, k);
}

function crypto_box_open(m, c, d, n, y, x) {
  var k = new Uint8Array(32);
  crypto_box_beforenm(k, y, x);
  return crypto_box_open_afternm(m, c, d, n, k);
}

var K = [
  0x428a2f98, 0xd728ae22, 0x71374491, 0x23ef65cd,
  0xb5c0fbcf, 0xec4d3b2f, 0xe9b5dba5, 0x8189dbbc,
  0x3956c25b, 0xf348b538, 0x59f111f1, 0xb605d019,
  0x923f82a4, 0xaf194f9b, 0xab1c5ed5, 0xda6d8118,
  0xd807aa98, 0xa3030242, 0x12835b01, 0x45706fbe,
  0x243185be, 0x4ee4b28c, 0x550c7dc3, 0xd5ffb4e2,
  0x72be5d74, 0xf27b896f, 0x80deb1fe, 0x3b1696b1,
  0x9bdc06a7, 0x25c71235, 0xc19bf174, 0xcf692694,
  0xe49b69c1, 0x9ef14ad2, 0xefbe4786, 0x384f25e3,
  0x0fc19dc6, 0x8b8cd5b5, 0x240ca1cc, 0x77ac9c65,
  0x2de92c6f, 0x592b0275, 0x4a7484aa, 0x6ea6e483,
  0x5cb0a9dc, 0xbd41fbd4, 0x76f988da, 0x831153b5,
  0x983e5152, 0xee66dfab, 0xa831c66d, 0x2db43210,
  0xb00327c8, 0x98fb213f, 0xbf597fc7, 0xbeef0ee4,
  0xc6e00bf3, 0x3da88fc2, 0xd5a79147, 0x930aa725,
  0x06ca6351, 0xe003826f, 0x14292967, 0x0a0e6e70,
  0x27b70a85, 0x46d22ffc, 0x2e1b2138, 0x5c26c926,
  0x4d2c6dfc, 0x5ac42aed, 0x53380d13, 0x9d95b3df,
  0x650a7354, 0x8baf63de, 0x766a0abb, 0x3c77b2a8,
  0x81c2c92e, 0x47edaee6, 0x92722c85, 0x1482353b,
  0xa2bfe8a1, 0x4cf10364, 0xa81a664b, 0xbc423001,
  0xc24b8b70, 0xd0f89791, 0xc76c51a3, 0x0654be30,
  0xd192e819, 0xd6ef5218, 0xd6990624, 0x5565a910,
  0xf40e3585, 0x5771202a, 0x106aa070, 0x32bbd1b8,
  0x19a4c116, 0xb8d2d0c8, 0x1e376c08, 0x5141ab53,
  0x2748774c, 0xdf8eeb99, 0x34b0bcb5, 0xe19b48a8,
  0x391c0cb3, 0xc5c95a63, 0x4ed8aa4a, 0xe3418acb,
  0x5b9cca4f, 0x7763e373, 0x682e6ff3, 0xd6b2b8a3,
  0x748f82ee, 0x5defb2fc, 0x78a5636f, 0x43172f60,
  0x84c87814, 0xa1f0ab72, 0x8cc70208, 0x1a6439ec,
  0x90befffa, 0x23631e28, 0xa4506ceb, 0xde82bde9,
  0xbef9a3f7, 0xb2c67915, 0xc67178f2, 0xe372532b,
  0xca273ece, 0xea26619c, 0xd186b8c7, 0x21c0c207,
  0xeada7dd6, 0xcde0eb1e, 0xf57d4f7f, 0xee6ed178,
  0x06f067aa, 0x72176fba, 0x0a637dc5, 0xa2c898a6,
  0x113f9804, 0xbef90dae, 0x1b710b35, 0x131c471b,
  0x28db77f5, 0x23047d84, 0x32caab7b, 0x40c72493,
  0x3c9ebe0a, 0x15c9bebc, 0x431d67c4, 0x9c100d4c,
  0x4cc5d4be, 0xcb3e42b6, 0x597f299c, 0xfc657e2a,
  0x5fcb6fab, 0x3ad6faec, 0x6c44198c, 0x4a475817
];

function crypto_hashblocks_hl(hh, hl, m, n) {
  var wh = new Int32Array(16), wl = new Int32Array(16),
      bh0, bh1, bh2, bh3, bh4, bh5, bh6, bh7,
      bl0, bl1, bl2, bl3, bl4, bl5, bl6, bl7,
      th, tl, i, j, h, l, a, b, c, d;

  var ah0 = hh[0],
      ah1 = hh[1],
      ah2 = hh[2],
      ah3 = hh[3],
      ah4 = hh[4],
      ah5 = hh[5],
      ah6 = hh[6],
      ah7 = hh[7],

      al0 = hl[0],
      al1 = hl[1],
      al2 = hl[2],
      al3 = hl[3],
      al4 = hl[4],
      al5 = hl[5],
      al6 = hl[6],
      al7 = hl[7];

  var pos = 0;
  while (n >= 128) {
    for (i = 0; i < 16; i++) {
      j = 8 * i + pos;
      wh[i] = (m[j+0] << 24) | (m[j+1] << 16) | (m[j+2] << 8) | m[j+3];
      wl[i] = (m[j+4] << 24) | (m[j+5] << 16) | (m[j+6] << 8) | m[j+7];
    }
    for (i = 0; i < 80; i++) {
      bh0 = ah0;
      bh1 = ah1;
      bh2 = ah2;
      bh3 = ah3;
      bh4 = ah4;
      bh5 = ah5;
      bh6 = ah6;
      bh7 = ah7;

      bl0 = al0;
      bl1 = al1;
      bl2 = al2;
      bl3 = al3;
      bl4 = al4;
      bl5 = al5;
      bl6 = al6;
      bl7 = al7;

      // add
      h = ah7;
      l = al7;

      a = l & 0xffff; b = l >>> 16;
      c = h & 0xffff; d = h >>> 16;

      // Sigma1
      h = ((ah4 >>> 14) | (al4 << (32-14))) ^ ((ah4 >>> 18) | (al4 << (32-18))) ^ ((al4 >>> (41-32)) | (ah4 << (32-(41-32))));
      l = ((al4 >>> 14) | (ah4 << (32-14))) ^ ((al4 >>> 18) | (ah4 << (32-18))) ^ ((ah4 >>> (41-32)) | (al4 << (32-(41-32))));

      a += l & 0xffff; b += l >>> 16;
      c += h & 0xffff; d += h >>> 16;

      // Ch
      h = (ah4 & ah5) ^ (~ah4 & ah6);
      l = (al4 & al5) ^ (~al4 & al6);

      a += l & 0xffff; b += l >>> 16;
      c += h & 0xffff; d += h >>> 16;

      // K
      h = K[i*2];
      l = K[i*2+1];

      a += l & 0xffff; b += l >>> 16;
      c += h & 0xffff; d += h >>> 16;

      // w
      h = wh[i%16];
      l = wl[i%16];

      a += l & 0xffff; b += l >>> 16;
      c += h & 0xffff; d += h >>> 16;

      b += a >>> 16;
      c += b >>> 16;
      d += c >>> 16;

      th = c & 0xffff | d << 16;
      tl = a & 0xffff | b << 16;

      // add
      h = th;
      l = tl;

      a = l & 0xffff; b = l >>> 16;
      c = h & 0xffff; d = h >>> 16;

      // Sigma0
      h = ((ah0 >>> 28) | (al0 << (32-28))) ^ ((al0 >>> (34-32)) | (ah0 << (32-(34-32)))) ^ ((al0 >>> (39-32)) | (ah0 << (32-(39-32))));
      l = ((al0 >>> 28) | (ah0 << (32-28))) ^ ((ah0 >>> (34-32)) | (al0 << (32-(34-32)))) ^ ((ah0 >>> (39-32)) | (al0 << (32-(39-32))));

      a += l & 0xffff; b += l >>> 16;
      c += h & 0xffff; d += h >>> 16;

      // Maj
      h = (ah0 & ah1) ^ (ah0 & ah2) ^ (ah1 & ah2);
      l = (al0 & al1) ^ (al0 & al2) ^ (al1 & al2);

      a += l & 0xffff; b += l >>> 16;
      c += h & 0xffff; d += h >>> 16;

      b += a >>> 16;
      c += b >>> 16;
      d += c >>> 16;

      bh7 = (c & 0xffff) | (d << 16);
      bl7 = (a & 0xffff) | (b << 16);

      // add
      h = bh3;
      l = bl3;

      a = l & 0xffff; b = l >>> 16;
      c = h & 0xffff; d = h >>> 16;

      h = th;
      l = tl;

      a += l & 0xffff; b += l >>> 16;
      c += h & 0xffff; d += h >>> 16;

      b += a >>> 16;
      c += b >>> 16;
      d += c >>> 16;

      bh3 = (c & 0xffff) | (d << 16);
      bl3 = (a & 0xffff) | (b << 16);

      ah1 = bh0;
      ah2 = bh1;
      ah3 = bh2;
      ah4 = bh3;
      ah5 = bh4;
      ah6 = bh5;
      ah7 = bh6;
      ah0 = bh7;

      al1 = bl0;
      al2 = bl1;
      al3 = bl2;
      al4 = bl3;
      al5 = bl4;
      al6 = bl5;
      al7 = bl6;
      al0 = bl7;

      if (i%16 === 15) {
        for (j = 0; j < 16; j++) {
          // add
          h = wh[j];
          l = wl[j];

          a = l & 0xffff; b = l >>> 16;
          c = h & 0xffff; d = h >>> 16;

          h = wh[(j+9)%16];
          l = wl[(j+9)%16];

          a += l & 0xffff; b += l >>> 16;
          c += h & 0xffff; d += h >>> 16;

          // sigma0
          th = wh[(j+1)%16];
          tl = wl[(j+1)%16];
          h = ((th >>> 1) | (tl << (32-1))) ^ ((th >>> 8) | (tl << (32-8))) ^ (th >>> 7);
          l = ((tl >>> 1) | (th << (32-1))) ^ ((tl >>> 8) | (th << (32-8))) ^ ((tl >>> 7) | (th << (32-7)));

          a += l & 0xffff; b += l >>> 16;
          c += h & 0xffff; d += h >>> 16;

          // sigma1
          th = wh[(j+14)%16];
          tl = wl[(j+14)%16];
          h = ((th >>> 19) | (tl << (32-19))) ^ ((tl >>> (61-32)) | (th << (32-(61-32)))) ^ (th >>> 6);
          l = ((tl >>> 19) | (th << (32-19))) ^ ((th >>> (61-32)) | (tl << (32-(61-32)))) ^ ((tl >>> 6) | (th << (32-6)));

          a += l & 0xffff; b += l >>> 16;
          c += h & 0xffff; d += h >>> 16;

          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;

          wh[j] = (c & 0xffff) | (d << 16);
          wl[j] = (a & 0xffff) | (b << 16);
        }
      }
    }

    // add
    h = ah0;
    l = al0;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[0];
    l = hl[0];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[0] = ah0 = (c & 0xffff) | (d << 16);
    hl[0] = al0 = (a & 0xffff) | (b << 16);

    h = ah1;
    l = al1;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[1];
    l = hl[1];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[1] = ah1 = (c & 0xffff) | (d << 16);
    hl[1] = al1 = (a & 0xffff) | (b << 16);

    h = ah2;
    l = al2;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[2];
    l = hl[2];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[2] = ah2 = (c & 0xffff) | (d << 16);
    hl[2] = al2 = (a & 0xffff) | (b << 16);

    h = ah3;
    l = al3;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[3];
    l = hl[3];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[3] = ah3 = (c & 0xffff) | (d << 16);
    hl[3] = al3 = (a & 0xffff) | (b << 16);

    h = ah4;
    l = al4;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[4];
    l = hl[4];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[4] = ah4 = (c & 0xffff) | (d << 16);
    hl[4] = al4 = (a & 0xffff) | (b << 16);

    h = ah5;
    l = al5;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[5];
    l = hl[5];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[5] = ah5 = (c & 0xffff) | (d << 16);
    hl[5] = al5 = (a & 0xffff) | (b << 16);

    h = ah6;
    l = al6;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[6];
    l = hl[6];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[6] = ah6 = (c & 0xffff) | (d << 16);
    hl[6] = al6 = (a & 0xffff) | (b << 16);

    h = ah7;
    l = al7;

    a = l & 0xffff; b = l >>> 16;
    c = h & 0xffff; d = h >>> 16;

    h = hh[7];
    l = hl[7];

    a += l & 0xffff; b += l >>> 16;
    c += h & 0xffff; d += h >>> 16;

    b += a >>> 16;
    c += b >>> 16;
    d += c >>> 16;

    hh[7] = ah7 = (c & 0xffff) | (d << 16);
    hl[7] = al7 = (a & 0xffff) | (b << 16);

    pos += 128;
    n -= 128;
  }

  return n;
}

function crypto_hash(out, m, n) {
  var hh = new Int32Array(8),
      hl = new Int32Array(8),
      x = new Uint8Array(256),
      i, b = n;

  hh[0] = 0x6a09e667;
  hh[1] = 0xbb67ae85;
  hh[2] = 0x3c6ef372;
  hh[3] = 0xa54ff53a;
  hh[4] = 0x510e527f;
  hh[5] = 0x9b05688c;
  hh[6] = 0x1f83d9ab;
  hh[7] = 0x5be0cd19;

  hl[0] = 0xf3bcc908;
  hl[1] = 0x84caa73b;
  hl[2] = 0xfe94f82b;
  hl[3] = 0x5f1d36f1;
  hl[4] = 0xade682d1;
  hl[5] = 0x2b3e6c1f;
  hl[6] = 0xfb41bd6b;
  hl[7] = 0x137e2179;

  crypto_hashblocks_hl(hh, hl, m, n);
  n %= 128;

  for (i = 0; i < n; i++) x[i] = m[b-n+i];
  x[n] = 128;

  n = 256-128*(n<112?1:0);
  x[n-9] = 0;
  ts64(x, n-8,  (b / 0x20000000) | 0, b << 3);
  crypto_hashblocks_hl(hh, hl, x, n);

  for (i = 0; i < 8; i++) ts64(out, 8*i, hh[i], hl[i]);

  return 0;
}

function add(p, q) {
  var a = gf(), b = gf(), c = gf(),
      d = gf(), e = gf(), f = gf(),
      g = gf(), h = gf(), t = gf();

  Z(a, p[1], p[0]);
  Z(t, q[1], q[0]);
  M(a, a, t);
  A(b, p[0], p[1]);
  A(t, q[0], q[1]);
  M(b, b, t);
  M(c, p[3], q[3]);
  M(c, c, D2);
  M(d, p[2], q[2]);
  A(d, d, d);
  Z(e, b, a);
  Z(f, d, c);
  A(g, d, c);
  A(h, b, a);

  M(p[0], e, f);
  M(p[1], h, g);
  M(p[2], g, f);
  M(p[3], e, h);
}

function cswap(p, q, b) {
  var i;
  for (i = 0; i < 4; i++) {
    sel25519(p[i], q[i], b);
  }
}

function pack(r, p) {
  var tx = gf(), ty = gf(), zi = gf();
  inv25519(zi, p[2]);
  M(tx, p[0], zi);
  M(ty, p[1], zi);
  pack25519(r, ty);
  r[31] ^= par25519(tx) << 7;
}

function scalarmult(p, q, s) {
  var b, i;
  set25519(p[0], gf0);
  set25519(p[1], gf1);
  set25519(p[2], gf1);
  set25519(p[3], gf0);
  for (i = 255; i >= 0; --i) {
    b = (s[(i/8)|0] >> (i&7)) & 1;
    cswap(p, q, b);
    add(q, p);
    add(p, p);
    cswap(p, q, b);
  }
}

function scalarbase(p, s) {
  var q = [gf(), gf(), gf(), gf()];
  set25519(q[0], X);
  set25519(q[1], Y);
  set25519(q[2], gf1);
  M(q[3], X, Y);
  scalarmult(p, q, s);
}

function crypto_sign_keypair(pk, sk, seeded) {
  var d = new Uint8Array(64);
  var p = [gf(), gf(), gf(), gf()];
  var i;

  if (!seeded) randombytes(sk, 32);
  crypto_hash(d, sk, 32);
  d[0] &= 248;
  d[31] &= 127;
  d[31] |= 64;

  scalarbase(p, d);
  pack(pk, p);

  for (i = 0; i < 32; i++) sk[i+32] = pk[i];
  return 0;
}

var L = new Float64Array([0xed, 0xd3, 0xf5, 0x5c, 0x1a, 0x63, 0x12, 0x58, 0xd6, 0x9c, 0xf7, 0xa2, 0xde, 0xf9, 0xde, 0x14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x10]);

function modL(r, x) {
  var carry, i, j, k;
  for (i = 63; i >= 32; --i) {
    carry = 0;
    for (j = i - 32, k = i - 12; j < k; ++j) {
      x[j] += carry - 16 * x[i] * L[j - (i - 32)];
      carry = (x[j] + 128) >> 8;
      x[j] -= carry * 256;
    }
    x[j] += carry;
    x[i] = 0;
  }
  carry = 0;
  for (j = 0; j < 32; j++) {
    x[j] += carry - (x[31] >> 4) * L[j];
    carry = x[j] >> 8;
    x[j] &= 255;
  }
  for (j = 0; j < 32; j++) x[j] -= carry * L[j];
  for (i = 0; i < 32; i++) {
    x[i+1] += x[i] >> 8;
    r[i] = x[i] & 255;
  }
}

function reduce(r) {
  var x = new Float64Array(64), i;
  for (i = 0; i < 64; i++) x[i] = r[i];
  for (i = 0; i < 64; i++) r[i] = 0;
  modL(r, x);
}

// Note: difference from C - smlen returned, not passed as argument.
function crypto_sign(sm, m, n, sk) {
  var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);
  var i, j, x = new Float64Array(64);
  var p = [gf(), gf(), gf(), gf()];

  crypto_hash(d, sk, 32);
  d[0] &= 248;
  d[31] &= 127;
  d[31] |= 64;

  var smlen = n + 64;
  for (i = 0; i < n; i++) sm[64 + i] = m[i];
  for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];

  crypto_hash(r, sm.subarray(32), n+32);
  reduce(r);
  scalarbase(p, r);
  pack(sm, p);

  for (i = 32; i < 64; i++) sm[i] = sk[i];
  crypto_hash(h, sm, n + 64);
  reduce(h);

  for (i = 0; i < 64; i++) x[i] = 0;
  for (i = 0; i < 32; i++) x[i] = r[i];
  for (i = 0; i < 32; i++) {
    for (j = 0; j < 32; j++) {
      x[i+j] += h[i] * d[j];
    }
  }

  modL(sm.subarray(32), x);
  return smlen;
}

function unpackneg(r, p) {
  var t = gf(), chk = gf(), num = gf(),
      den = gf(), den2 = gf(), den4 = gf(),
      den6 = gf();

  set25519(r[2], gf1);
  unpack25519(r[1], p);
  S(num, r[1]);
  M(den, num, D);
  Z(num, num, r[2]);
  A(den, r[2], den);

  S(den2, den);
  S(den4, den2);
  M(den6, den4, den2);
  M(t, den6, num);
  M(t, t, den);

  pow2523(t, t);
  M(t, t, num);
  M(t, t, den);
  M(t, t, den);
  M(r[0], t, den);

  S(chk, r[0]);
  M(chk, chk, den);
  if (neq25519(chk, num)) M(r[0], r[0], I);

  S(chk, r[0]);
  M(chk, chk, den);
  if (neq25519(chk, num)) return -1;

  if (par25519(r[0]) === (p[31]>>7)) Z(r[0], gf0, r[0]);

  M(r[3], r[0], r[1]);
  return 0;
}

function crypto_sign_open(m, sm, n, pk) {
  var i, mlen;
  var t = new Uint8Array(32), h = new Uint8Array(64);
  var p = [gf(), gf(), gf(), gf()],
      q = [gf(), gf(), gf(), gf()];

  mlen = -1;
  if (n < 64) return -1;

  if (unpackneg(q, pk)) return -1;

  for (i = 0; i < n; i++) m[i] = sm[i];
  for (i = 0; i < 32; i++) m[i+32] = pk[i];
  crypto_hash(h, m, n);
  reduce(h);
  scalarmult(p, q, h);

  scalarbase(q, sm.subarray(32));
  add(p, q);
  pack(t, p);

  n -= 64;
  if (crypto_verify_32(sm, 0, t, 0)) {
    for (i = 0; i < n; i++) m[i] = 0;
    return -1;
  }

  for (i = 0; i < n; i++) m[i] = sm[i + 64];
  mlen = n;
  return mlen;
}

var crypto_secretbox_KEYBYTES = 32,
    crypto_secretbox_NONCEBYTES = 24,
    crypto_secretbox_ZEROBYTES = 32,
    crypto_secretbox_BOXZEROBYTES = 16,
    crypto_scalarmult_BYTES = 32,
    crypto_scalarmult_SCALARBYTES = 32,
    crypto_box_PUBLICKEYBYTES = 32,
    crypto_box_SECRETKEYBYTES = 32,
    crypto_box_BEFORENMBYTES = 32,
    crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES,
    crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES,
    crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES,
    crypto_sign_BYTES = 64,
    crypto_sign_PUBLICKEYBYTES = 32,
    crypto_sign_SECRETKEYBYTES = 64,
    crypto_sign_SEEDBYTES = 32,
    crypto_hash_BYTES = 64;

nacl.lowlevel = {
  crypto_core_hsalsa20: crypto_core_hsalsa20,
  crypto_stream_xor: crypto_stream_xor,
  crypto_stream: crypto_stream,
  crypto_stream_salsa20_xor: crypto_stream_salsa20_xor,
  crypto_stream_salsa20: crypto_stream_salsa20,
  crypto_onetimeauth: crypto_onetimeauth,
  crypto_onetimeauth_verify: crypto_onetimeauth_verify,
  crypto_verify_16: crypto_verify_16,
  crypto_verify_32: crypto_verify_32,
  crypto_secretbox: crypto_secretbox,
  crypto_secretbox_open: crypto_secretbox_open,
  crypto_scalarmult: crypto_scalarmult,
  crypto_scalarmult_base: crypto_scalarmult_base,
  crypto_box_beforenm: crypto_box_beforenm,
  crypto_box_afternm: crypto_box_afternm,
  crypto_box: crypto_box,
  crypto_box_open: crypto_box_open,
  crypto_box_keypair: crypto_box_keypair,
  crypto_hash: crypto_hash,
  crypto_sign: crypto_sign,
  crypto_sign_keypair: crypto_sign_keypair,
  crypto_sign_open: crypto_sign_open,

  crypto_secretbox_KEYBYTES: crypto_secretbox_KEYBYTES,
  crypto_secretbox_NONCEBYTES: crypto_secretbox_NONCEBYTES,
  crypto_secretbox_ZEROBYTES: crypto_secretbox_ZEROBYTES,
  crypto_secretbox_BOXZEROBYTES: crypto_secretbox_BOXZEROBYTES,
  crypto_scalarmult_BYTES: crypto_scalarmult_BYTES,
  crypto_scalarmult_SCALARBYTES: crypto_scalarmult_SCALARBYTES,
  crypto_box_PUBLICKEYBYTES: crypto_box_PUBLICKEYBYTES,
  crypto_box_SECRETKEYBYTES: crypto_box_SECRETKEYBYTES,
  crypto_box_BEFORENMBYTES: crypto_box_BEFORENMBYTES,
  crypto_box_NONCEBYTES: crypto_box_NONCEBYTES,
  crypto_box_ZEROBYTES: crypto_box_ZEROBYTES,
  crypto_box_BOXZEROBYTES: crypto_box_BOXZEROBYTES,
  crypto_sign_BYTES: crypto_sign_BYTES,
  crypto_sign_PUBLICKEYBYTES: crypto_sign_PUBLICKEYBYTES,
  crypto_sign_SECRETKEYBYTES: crypto_sign_SECRETKEYBYTES,
  crypto_sign_SEEDBYTES: crypto_sign_SEEDBYTES,
  crypto_hash_BYTES: crypto_hash_BYTES
};

/* High-level API */

function checkLengths(k, n) {
  if (k.length !== crypto_secretbox_KEYBYTES) throw new Error('bad key size');
  if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error('bad nonce size');
}

function checkBoxLengths(pk, sk) {
  if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error('bad public key size');
  if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error('bad secret key size');
}

function checkArrayTypes() {
  for (var i = 0; i < arguments.length; i++) {
    if (!(arguments[i] instanceof Uint8Array))
      throw new TypeError('unexpected type, use Uint8Array');
  }
}

function cleanup(arr) {
  for (var i = 0; i < arr.length; i++) arr[i] = 0;
}

nacl.randomBytes = function(n) {
  var b = new Uint8Array(n);
  randombytes(b, n);
  return b;
};

nacl.secretbox = function(msg, nonce, key) {
  checkArrayTypes(msg, nonce, key);
  checkLengths(key, nonce);
  var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);
  var c = new Uint8Array(m.length);
  for (var i = 0; i < msg.length; i++) m[i+crypto_secretbox_ZEROBYTES] = msg[i];
  crypto_secretbox(c, m, m.length, nonce, key);
  return c.subarray(crypto_secretbox_BOXZEROBYTES);
};

nacl.secretbox.open = function(box, nonce, key) {
  checkArrayTypes(box, nonce, key);
  checkLengths(key, nonce);
  var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);
  var m = new Uint8Array(c.length);
  for (var i = 0; i < box.length; i++) c[i+crypto_secretbox_BOXZEROBYTES] = box[i];
  if (c.length < 32) return null;
  if (crypto_secretbox_open(m, c, c.length, nonce, key) !== 0) return null;
  return m.subarray(crypto_secretbox_ZEROBYTES);
};

nacl.secretbox.keyLength = crypto_secretbox_KEYBYTES;
nacl.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;
nacl.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;

nacl.scalarMult = function(n, p) {
  checkArrayTypes(n, p);
  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');
  if (p.length !== crypto_scalarmult_BYTES) throw new Error('bad p size');
  var q = new Uint8Array(crypto_scalarmult_BYTES);
  crypto_scalarmult(q, n, p);
  return q;
};

nacl.scalarMult.base = function(n) {
  checkArrayTypes(n);
  if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error('bad n size');
  var q = new Uint8Array(crypto_scalarmult_BYTES);
  crypto_scalarmult_base(q, n);
  return q;
};

nacl.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;
nacl.scalarMult.groupElementLength = crypto_scalarmult_BYTES;

nacl.box = function(msg, nonce, publicKey, secretKey) {
  var k = nacl.box.before(publicKey, secretKey);
  return nacl.secretbox(msg, nonce, k);
};

nacl.box.before = function(publicKey, secretKey) {
  checkArrayTypes(publicKey, secretKey);
  checkBoxLengths(publicKey, secretKey);
  var k = new Uint8Array(crypto_box_BEFORENMBYTES);
  crypto_box_beforenm(k, publicKey, secretKey);
  return k;
};

nacl.box.after = nacl.secretbox;

nacl.box.open = function(msg, nonce, publicKey, secretKey) {
  var k = nacl.box.before(publicKey, secretKey);
  return nacl.secretbox.open(msg, nonce, k);
};

nacl.box.open.after = nacl.secretbox.open;

nacl.box.keyPair = function() {
  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);
  crypto_box_keypair(pk, sk);
  return {publicKey: pk, secretKey: sk};
};

nacl.box.keyPair.fromSecretKey = function(secretKey) {
  checkArrayTypes(secretKey);
  if (secretKey.length !== crypto_box_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
  crypto_scalarmult_base(pk, secretKey);
  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};
};

nacl.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;
nacl.box.secretKeyLength = crypto_box_SECRETKEYBYTES;
nacl.box.sharedKeyLength = crypto_box_BEFORENMBYTES;
nacl.box.nonceLength = crypto_box_NONCEBYTES;
nacl.box.overheadLength = nacl.secretbox.overheadLength;

nacl.sign = function(msg, secretKey) {
  checkArrayTypes(msg, secretKey);
  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var signedMsg = new Uint8Array(crypto_sign_BYTES+msg.length);
  crypto_sign(signedMsg, msg, msg.length, secretKey);
  return signedMsg;
};

nacl.sign.open = function(signedMsg, publicKey) {
  checkArrayTypes(signedMsg, publicKey);
  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
    throw new Error('bad public key size');
  var tmp = new Uint8Array(signedMsg.length);
  var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);
  if (mlen < 0) return null;
  var m = new Uint8Array(mlen);
  for (var i = 0; i < m.length; i++) m[i] = tmp[i];
  return m;
};

nacl.sign.detached = function(msg, secretKey) {
  var signedMsg = nacl.sign(msg, secretKey);
  var sig = new Uint8Array(crypto_sign_BYTES);
  for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];
  return sig;
};

nacl.sign.detached.verify = function(msg, sig, publicKey) {
  checkArrayTypes(msg, sig, publicKey);
  if (sig.length !== crypto_sign_BYTES)
    throw new Error('bad signature size');
  if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
    throw new Error('bad public key size');
  var sm = new Uint8Array(crypto_sign_BYTES + msg.length);
  var m = new Uint8Array(crypto_sign_BYTES + msg.length);
  var i;
  for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];
  for (i = 0; i < msg.length; i++) sm[i+crypto_sign_BYTES] = msg[i];
  return (crypto_sign_open(m, sm, sm.length, publicKey) >= 0);
};

nacl.sign.keyPair = function() {
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
  crypto_sign_keypair(pk, sk);
  return {publicKey: pk, secretKey: sk};
};

nacl.sign.keyPair.fromSecretKey = function(secretKey) {
  checkArrayTypes(secretKey);
  if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
    throw new Error('bad secret key size');
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32+i];
  return {publicKey: pk, secretKey: new Uint8Array(secretKey)};
};

nacl.sign.keyPair.fromSeed = function(seed) {
  checkArrayTypes(seed);
  if (seed.length !== crypto_sign_SEEDBYTES)
    throw new Error('bad seed size');
  var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
  var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
  for (var i = 0; i < 32; i++) sk[i] = seed[i];
  crypto_sign_keypair(pk, sk, true);
  return {publicKey: pk, secretKey: sk};
};

nacl.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;
nacl.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;
nacl.sign.seedLength = crypto_sign_SEEDBYTES;
nacl.sign.signatureLength = crypto_sign_BYTES;

nacl.hash = function(msg) {
  checkArrayTypes(msg);
  var h = new Uint8Array(crypto_hash_BYTES);
  crypto_hash(h, msg, msg.length);
  return h;
};

nacl.hash.hashLength = crypto_hash_BYTES;

nacl.verify = function(x, y) {
  checkArrayTypes(x, y);
  // Zero length arguments are considered not equal.
  if (x.length === 0 || y.length === 0) return false;
  if (x.length !== y.length) return false;
  return (vn(x, 0, y, 0, x.length) === 0) ? true : false;
};

nacl.setPRNG = function(fn) {
  randombytes = fn;
};

(function() {
  // Initialize PRNG if environment provides CSPRNG.
  // If not, methods calling randombytes will throw.
  var crypto = typeof self !== 'undefined' ? (self.crypto || self.msCrypto) : null;
  if (crypto && crypto.getRandomValues) {
    // Browsers.
    var QUOTA = 65536;
    nacl.setPRNG(function(x, n) {
      var i, v = new Uint8Array(n);
      for (i = 0; i < n; i += QUOTA) {
        crypto.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));
      }
      for (i = 0; i < n; i++) x[i] = v[i];
      cleanup(v);
    });
  } else if (true) {
    // Node.js.
    crypto = __webpack_require__(14);
    if (crypto && crypto.randomBytes) {
      nacl.setPRNG(function(x, n) {
        var i, v = crypto.randomBytes(n);
        for (i = 0; i < n; i++) x[i] = v[i];
        cleanup(v);
      });
    }
  }
})();

})( true && module.exports ? module.exports : (self.nacl = self.nacl || {}));


/***/ })
/******/ ])));
//# sourceMappingURL=send.js.map